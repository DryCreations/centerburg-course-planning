# Week 5 Materials: Mon Sep 14 to Fri Sep 18

**Full five day week.**

---

## Start here

`SLIDE-PROMPTS/` has one file per day, all five classes in each. One prompt per slide, for Google Slides AI.
`program/week-5-daily-log.md` is the week at a glance plus the decisions behind it.

| Class | Mon | Tue | Wed | Thu | Fri |
|-------|-----|-----|-----|-----|-----|
| Design Techniques | 6 | 4 | 3 | 3 | 3 |
| Video & Sound | 7 | 4 | 4 | 4 | 3 |
| Aviation UAS | 6 | 5 | 5 | 5 | 4 |
| Middle School CS | 7 | 6 | 5 | 4 | 3 |
| Yearbook | 1 | 1 | 1 | 1 | 1 |

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | Pick project, write ONE TASK. Lab: Back | **Camera setup for video** | METAR anatomy, decode together. **Assign ODOT Mod 1** | **`while` lesson**, then lab | Shutter speed lesson |
| **Tue** | Lab: Overlay. Wireframe all screens | Scene list, draft | Sky, temp, weather codes | **`for index` + modulo** | Rotation |
| **Wed** | Lab: State change. Build screen 1 | Table read, **lock script** | Weather hazards | `forever`, nested loops | Rotation |
| **Thu** | Lab: Scroll. Screens 2 and 3 | **FILMING STARTS** | TAFs, **Minimums Card** | **`while` for real** | Last rotation |
| **Fri** | Connect, first partner test | **QUIZ**, film | **QUIZ**, weather briefs | Finish, showcase | **Set + check-in due** |

---

## Prep before Friday

**Two quizzes**, both plain CSV, no images, nothing coupled.

- **Aviation:** `3-aviation-uas/quiz-bank.csv`, 40 questions, cut to 20. Meteorology.
- **Video & Sound:** `2-video-and-sound/quiz-bank.csv`, 44 questions, cut to 20. Pre-production, screenplay
  format, and camera setup.

**Monday also:** assign **ODOT Module 1** in Aviation, due Thu Sep 24.

---

## Notes per class

### Design Techniques: a TWO WEEK project

Runs through **Fri Sep 25.** Same app throughout, a little more each day.

**Every day opens with a ten minute interaction lab**, then work time. Week 5: Back, Overlay, State change,
Scroll. Week 6: Selection, Input, Transitions, Putting it together. All eight are in
`1-design-techniques/handouts/interaction-labs.md`, numbered and self-serve.

**Monday is ideation only.** The gate is that everyone leaves with **one task written in one sentence**.
"Order one coffee." If a screen does not serve that sentence, it does not exist. Ten small project ideas are
in `project.md` for anyone who does not have their own.

Scope control is the whole job Monday. They will try to design all of Instagram.

### Video & Sound: cameras, then film Thursday

**Monday teaches camera setup for video**, which is a different checklist than for photos. Do the camera half
first while attention is fresh, and **get bodies in hands** rather than just reading the handout.

**The bodies are not uniform:** T3, T4i, T5, T6. The **T3 only shoots 720p**; the others do 1080p; none do
1080p60. Groups pick a resolution and stay on it.

**The highest-value thing Monday is the 180 degree rule:** shutter at double the frame rate. Nobody arrives
knowing it, and it is why amateur video looks wrong.

**Script locks Wednesday. Filming starts Thursday.** If a group is not ready, send them anyway. A group that
films badly Thursday learns more than one that plans another week.

Enforce naming (`LastName_Project_Shot03_Take2`) and **room tone**, 30 seconds per location. Editing software
is still not installed, so footage will sit a while, which makes organizing the difference between an archive
and a folder of `MVI_4821.MOV`.

### Aviation: meteorology, plus ODOT Module 1

**Monday is group decoding on the board.** `3-aviation-uas/handouts/decode-together.md` has five rounds,
easiest to hardest, with answers: single fields, short strings, no-key strings, trap questions, and building
a METAR backwards from a scenario. Put one up, ninety seconds with a partner, take answers, reveal. **Start
with the key allowed and take it away by round 3.**

**Pull live METARs every day.** KCMH, KOSU, KTZR. When local weather is boring, go hunting.

The four things drilled daily: cloud height (**add two zeros**), wind direction is **FROM**, **the gust** not
the average, Zulu minus 4.

**The Personal Minimums Card is the real point of the week.** Every number needs a written reason and every
number should be stricter than Part 107.

**ODOT Module 1 assigned Monday, due Thu Sep 24**, ahead of next Friday's quiz. Chase LDAP problems early.

### Middle School CS: `while` first, then `for` and modulo

Monday and Tuesday are **content first, then lab**, roughly half and half.

**Monday teaches `while` even though they will not use it until Thursday.** That is deliberate: the concept
gets learned cold, with no game pressure, then sits for three days. Run it as: trace on the board, state the
one rule, **show an infinite loop and let it hang**, four example problems in pairs, then partners **read
loops out loud as English sentences**. That last step is also the question window.

Two trick problems: one counts down when it needs to count up (never ends), and one starts already false
(runs **zero** times, because `while` checks before the first pass).

Tuesday: `for index` earns its place because **the count is usable**. Then modulo as leftovers, and
`remainder of N ÷ 5 = 0` as the "every Nth" pattern. Common error is writing `= 5` instead of `= 0`.

**`for index from 0 to 4` runs FIVE times.** Trace it out loud before they build.

`4-middle-school-cs/handouts/star-catcher-lab.md` is numbered day by day with example problems and a bug
table, fully self-serve.

### Yearbook: the four shot set

Bigger than the aperture pair on purpose. Each shot has a target:

| # | Shot | Proves |
|---|------|--------|
| 1 | Frozen, 1/500+ | Stopping action |
| 2 | **Panning indoors**, ~1/60 | Controlling motion, not avoiding it |
| 3 | **Water frozen**, 1/1000+ | That fast enough changes what a thing IS |
| 4 | **Subject blurred, background sharp**, 1/30 or slower, braced | Blur comes from movement, not bad focus |

**Panning fails far more than it works.** Ten tries for one keeper is normal. Pair students so one shoots
while the other walks, then swap.

**Water is the one that surprises them.** It looks like a stream to the eye and is a line of separate drops
at 1/1000.

**The paragraph defending which belongs in the book is the assessment**, not the photos. All four are
technically correct.

Missing one? Take what they have plus an honest account of which beat them. Three good shots beats four
half-attempts.

---

## Folders

```
INDEX.md                     this file
SLIDE-PROMPTS/               one file per day, all five classes
1-design-techniques/         interaction-labs.md (all 8), teardown-sheet.md
2-video-and-sound/           camera-video-settings.md, screenplay-format.md, format-drill.md, quiz-bank.csv
3-aviation-uas/              metar-decoder.md, decode-together.md, personal-minimums.md, quiz-bank.csv
4-middle-school-cs/          star-catcher-lab.md
5-yearbook/                  shutter-speed.md
program/week-5-daily-log.md
grading-and-categories.md
```

`outline.md`, `project.md`, `vocab.md`, and `handouts/` are **student-facing.** `teacher-notes.md`,
`quiz.md`, and `decode-together.md` are **teacher-only.**

---

## Flagged

- **ODOT Module 1 due date** is set to **Thu Sep 24**, reading "next Friday" as Sep 25. If you meant Sep 18,
  it is a one line change in three files.
- **Confirm the camera mix on the cart.** The T3 is 720p only, which changes what a group can shoot.
- **DT course map** schedules Unit 1.4 for weeks 8 to 9 and it is being taught now.
- **MS CS year map is stale**; digital citizenship skipped entirely.
- **Aviation has no unit outlines**, only labs and quizzes.
