# Week 5 Materials: Mon Sep 14 to Fri Sep 18

**Full five day week.**

---

## Start here

`SLIDE-PROMPTS/` has one file per day, all five classes in each. Every block is one prompt for one slide,
written to paste into Google Slides AI. `program/week-5-daily-log.md` is the week at a glance plus the
decisions behind it.

| Class | Mon | Tue | Wed | Thu | Fri |
|-------|-----|-----|-----|-----|-----|
| Design Techniques | 6 | 5 | 4 | 4 | 4 |
| Video & Sound | 6 | 4 | 3 | 4 | 3 |
| Aviation UAS | 6 | 5 | 5 | 5 | 4 |
| Middle School CS | 5 | 5 | 5 | 5 | 3 |
| Yearbook | 1 | 1 | 1 | 1 | 1 |

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | Pick a screen, tear it down | Screenplay format | METAR anatomy | **New:** Star Catcher, `repeat` | Shutter speed lesson |
| **Tue** | Journey, paper wireframe | Scene breakdown | Sky, temp, weather codes | `for index` | Rotation, spread work |
| **Wed** | Build frame 1 in Figma | Draft day | Weather hazards | `forever`, nested loops | Rotation, spread work |
| **Thu** | Connect, partner test | **Table read** | TAFs, **Minimums Card** | `while`, the freeze trap | Last rotation |
| **Fri** | Write-up, post | **QUIZ**, submit | **QUIZ**, weather briefs | Finish, showcase | **Pair + check-in due** |

---

## Prep before Friday

**Two quizzes.** Both are plain CSV, no images, nothing coupled.

- **Aviation:** `3-aviation-uas/quiz-bank.csv`, 40 questions, cut to 20. Meteorology: decoding, Zulu time,
  TAFs, hazards, personal minimums. Breakdown in `quiz.md`.
- **Video & Sound:** `2-video-and-sound/quiz-bank.csv`, 30 questions, cut to 20. Pre-production vocabulary
  and screenplay format.

**Everything is due Friday** in every class except Middle School CS.

---

## Notes per class

### Design Techniques: the Redesign Project

The payoff for last week's Figma intro. Pick a real screen that frustrates you, tear it down in design
language, wireframe a fix, build it, post a before and after to the portfolio.

**Monday and Tuesday are entirely paper on purpose.** Do not let anyone open Figma until a wireframe exists.

The question to ask at every desk Wednesday: *"Point at the thing you said was broken. Now show me what you
changed about it."* If those are not the same thing, they are decorating, not redesigning.

### Video & Sound: screenplay format

**The format changes this week.** Last week was two-column A/V; Unit 1.2 specifies screenplay format and BPA
expects it. **Do not present it as a correction.** Both are real, for different jobs, and the handout leads
with a table comparing them. The shot lists they already wrote work with either.

**No editing software needed all week**, or for the rest of this unit. Pre-production is the graded artifact
and the unit runs through week 7.

Monday is taught by **fixing a badly written scene**, not by listing rules. The drill is the lesson.

### Aviation: meteorology

**This is the week that makes coded METARs quizzable**, which last week's quiz deliberately avoided.

**Pull live METARs on the projector every day.** KCMH and KOSU are reliable. When local weather is boring, go
hunting: coastal and mountain fields give far better decodes than invented examples.

The four things they will get wrong, drilled daily: cloud height (**add two zeros**), wind direction is
**FROM**, **the gust** not the average, and Zulu minus 4.

**The Personal Minimums Card is the real point of the week.** Every number needs a written reason, and every
number should be stricter than Part 107.

### Middle School CS: loops

Owed since week 4. New project, Star Catcher, one loop per day: `repeat`, `for index`, `forever` and nesting,
then `while`.

**Teach Monday the tedious way first.** Make one star, then start making the tenth by hand, slowly, until
they tell you to stop. Then show `repeat`. That contrast is the whole lesson.

Two things that will bite: **`for index from 0 to 4` runs FIVE times**, and an infinite `while` freezes the
game. Demo the freeze deliberately on Thursday.

### Yearbook: shutter speed

Ten minute lesson Monday, rotation through the week. Three points: bigger bottom number means more frozen,
faster shutter means darker photo, do not go below 1/60 handheld.

**The gym recipe is the practical payoff:** shutter 1/500, aperture wide open, ISO 1600 to 3200, accept the
grain. Say out loud that a grainy sharp photo beats a clean blurry one, because they will not believe it
otherwise.

**The one-sentence defense is the assessment**, not the photos. Both are technically correct; which one tells
the story better?

---

## Folders

```
INDEX.md                     this file
SLIDE-PROMPTS/               one file per day, all five classes
1-design-techniques/         teardown-sheet.md
2-video-and-sound/           screenplay-format.md, format-drill.md, quiz-bank.csv
3-aviation-uas/              metar-decoder.md, personal-minimums.md, quiz-bank.csv
4-middle-school-cs/          star-catcher-guide.md
5-yearbook/                  shutter-speed.md
program/week-5-daily-log.md
grading-and-categories.md
```

`outline.md`, `project.md`, `vocab.md`, and `handouts/` are **student-facing.** `teacher-notes.md` and
`quiz.md` are **teacher-only.**

---

## Flagged for later

- **DT course map needs resequencing.** Unit 1.4 is scheduled for weeks 8 to 9 and is being taught now.
- **MS CS year map is stale**, and digital citizenship has been skipped entirely.
- **Aviation has no unit outlines**, only labs and quizzes.
- **Video editing software still not installed.** Blocks nothing through week 7.
