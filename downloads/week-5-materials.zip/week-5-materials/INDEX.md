# Week 5 Materials: Mon Sep 14 to Fri Sep 18

**Full five day week.**

---

## Start here

`SLIDE-PROMPTS/` has one file per day, all five classes in each. One prompt per slide, for Google Slides AI.
`program/week-5-daily-log.md` is the week at a glance plus the decisions behind it.

| Class | Mon | Tue | Wed | Thu | Fri |
|-------|-----|-----|-----|-----|-----|
| Design Techniques | 6 | 6 | 5 | 4 | 4 |
| Video & Sound | 7 | 5 | 4 | 4 | 3 |
| Aviation UAS | 6 | 5 | 4 | 6 | 4 |
| Middle School CS | 7 | 6 | 5 | 4 | 3 |
| Yearbook | 1 | 2 | 1 | 1 | 1 |

> **Every Tuesday block also has a BOARD VERSION:** the same content reduced to what fits on a whiteboard,
> for running the lesson without a projector.

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | Pick project, write ONE TASK. Lab: Back | **Camera setup for video** | METAR anatomy, decode together. **Assign ODOT Mod 1** | **`while` lesson**, then lab | Shutter speed lesson |
| **Tue** | **Navigation and focus**, lay out screens | **Camera check** + hands-on, then group scheduling | **Airspace rules**, quick, then **ODOT work time** | **`for index` + modulo** | **Shutter speed lesson** |
| **Wed** | **Components + variants** | **FILMING, 8 min slots.** Packet, silent, otherwise | **Reading sectionals**, hands on | `forever`, nested loops | Photos or spreads |
| **Thu** | Feedback and state. Screens 2 and 3 | **FILMING, day 2.** Retakes first | Hazards, TAFs, **Minimums Card** | **`while` for real** | Last rotation |
| **Fri** | Connect, first partner test | **QUIZ**, film | **QUIZ**, weather briefs | Finish, showcase | **Set + check-in due** |

---

## Prep before Friday

**Two quizzes**, both plain CSV, no images, nothing coupled.

- **Aviation:** `3-aviation-uas/quiz-bank.csv`, 40 questions, cut to 20. Meteorology.
- **Video & Sound:** `2-video-and-sound/quiz-bank.csv`, 44 questions, cut to 20. Pre-production, screenplay
  format, and camera setup.

**Monday also:** assign **ODOT Module 1** in Aviation, due Thu Sep 24.

---

## Notes per class

### Design Techniques: a TWO WEEK project

Runs through **Fri Sep 25.** Same app throughout, a little more each day.

**Every day opens with a ten minute interaction lab**, then work time. Week 5: Back, Overlay, State change,
Scroll. Week 6: Selection, Input, Transitions, Putting it together. All eight are in
`1-design-techniques/handouts/interaction-labs.md`, numbered and self-serve.

**Monday is ideation only.** The gate is that everyone leaves with **one task written in one sentence**.
"Order one coffee." If a screen does not serve that sentence, it does not exist. Ten small project ideas are
in `project.md` for anyone who does not have their own.

**UI patterns are phased to land the day they are needed.** `handouts/ui-patterns.md` is organized in
sections so students read only the part that is live:

| Day | Lesson | While they are |
|-----|--------|----------------|
| Tue | Navigation and focus | Laying out screens |
| Wed | **Components, variants, interactive components** | Reusing a nav bar across screens |
| Thu | Feedback and state | Building screens 2 and 3 |
| Fri | Consistency | Connecting and testing |

**Wednesday is the highest-leverage day of the project.** Their nav bar is duplicated across four screens and
about to drift out of sync. Components fix that before it becomes a problem they can see. The part worth the
most class time is the decision rule: **if it changes only that element it goes in the component; if it
changes the screen it goes on the screen.** Building a heart-fill as two screen frames is how a prototype
becomes unmanageable.

**Make the "looks like a real app" point explicitly on Tuesday.** Not everything has to function, but the
screens should look like the whole app exists: a tab bar with four destinations when only one works, a search
icon that does nothing, a settings gear. Students default to building only what they wired up, and the result
reads as a wireframe rather than a product. The test: **would someone believe a screenshot of this was a real
app?** Have them keep a running list of what they are showing but not implementing.

Scope control is the whole job Monday. They will try to design all of Instagram.

### Video & Sound: cameras, scheduling, then film Thursday

**Monday teaches camera setup for video**, which is a different checklist than for photos. Do the camera half
first while attention is fresh, and **get bodies in hands** rather than just reading the handout.

**Three shooting cameras.** The **T4i, T5, and T6 support manual exposure in movie mode. The T3 does not**,
so it is a behind-the-scenes stills and second-angle camera only. Three groups shoot at a time, which is what
the shared schedule exists to manage. None of the bodies do 1080p60, so slow motion means 720p.

**The highest-value thing Monday is the 180 degree rule:** shutter at double the frame rate. Nobody arrives
knowing it, and it is why amateur video looks wrong.

**Wednesday and Thursday are in-room filming days**, run in eight minute slots. **Anyone not in a slot works
the reading worksheet, silently** (`handouts/review-packet.md`, key in `review-packet-key.md`), because sound
carries onto footage and cannot be removed.

**It is a digital worksheet.** Post it on Classroom as **Make a copy for each student.** Students type under
each question and paste screenshots into questions 14 and 19. Tell them to **turn it in at the end of each
period, finished or not**, and reopen it the next day; it runs across both days with explicit stopping
points.

**Open the two article links before class and confirm they load.** They were not verified from the repo.
Parts 1 and 2 link out to readings on **transitions** and **framing**; a backup summary covering both is at
the end of the packet if a link fails.

The packet runs in five parts with stopping points, so it works whether a student has fifteen minutes or
forty. **Part 3 is the graded part**, applying both readings to their own shot list, and question 19
(critique your own footage in the new vocabulary) is where the transfer happens. Part 4 is a closed-note
self-check that doubles as the Friday study guide.

**Every section is marked GREEN, YELLOW, or RED for lookup:** look it up freely; try from memory, then check,
then **bold** what changed; or close every tab and type `LOOK UP` next to anything you cannot get. Say the
line out loud once: **looking something up is not cheating, pretending you knew it is.**

Because it is digital, you can scan the whole class fast. What students bolded in Part 3 and flagged `LOOK
UP` in Part 4 is their study list, and reading across all of them tells you what to review Friday morning.

`handouts/filming-day.md` covers how to use a short slot: **set up before your slot starts**, since setting up
during it is how eight minutes becomes four. Thursday opens by watching Wednesday's footage and logging
retakes before shooting anything new.

**Tuesday opens with a camera check** (`handouts/camera-check.md`), ten questions answered from memory, then
cameras back in hands to confirm anything they guessed at. Make them run the full sequence once: movie mode
through offload through watching it on the computer. **Any step that stops a student is a thing to fix today,
not Thursday.**

**Then production planning, in small groups:** shoot blocks sorted by location, honest time estimates with
half-again padding, and every shot sorted IN ROOM / IN BUILDING / OUTSIDE / PROBLEM. Groups compare plans
with each other before the period ends and write down what they agree to. Script peer review runs inside the
groups.

**Script locks Wednesday**, and every group leaves with a call sheet. **Thursday is an in-room shoot day**,
so every group needs at least two shots that work inside the classroom. Groups spread into the building next
week. If a group is not ready Thursday, send them anyway.

Enforce naming (`LastName_Project_Shot03_Take2`) and **room tone**, 30 seconds per location. Editing software
is still not installed, so footage will sit a while, which makes organizing the difference between an archive
and a folder of `MVI_4821.MOV`.

### Aviation: weather, then airspace, plus ODOT Module 1

**Monday is group decoding on the board.** `3-aviation-uas/handouts/decode-together.md` has five rounds,
easiest to hardest, with answers: single fields, short strings, no-key strings, trap questions, and building
a METAR backwards from a scenario. Put one up, ninety seconds with a partner, take answers, reveal. **Start
with the key allowed and take it away by round 3.**

**Wednesday is hands-on sectional reading** (`handouts/sectional-reading.md`), in any chart viewer that pans
and zooms. Find one of each airspace class, read stacked numbers and obstruction heights, then answer six
questions about three self-chosen locations, plus a scavenger hunt and two written questions.

**Frame it as a lookup skill, not a memory test.** Say plainly that real pilots check the legend constantly
and nobody memorizes a sectional. Three things to reinforce while circulating: color and line style is the
whole airspace answer; **SFC** on the bottom of a stacked pair means it reaches the ground; the number **in
parentheses** on an obstruction is height above ground, and that is the one that matters at a 400 foot
ceiling.

**Tuesday is a short airspace block, then work time.** Review the classes and which require authorization,
the rules attached to each, LAANC and grid ceilings, and enough sectional to recognize how airspace is
marked. **Do not teach sectional navigation.** Four problems in `handouts/airspace.md`, then release them to
**ODOT Module 1**, which is due Thu Sep 24 and is on the next quiz.

The two things worth landing: **the grid ceiling can be lower than 400 and the lower number wins**, and
**Class G does not mean no rules.**

**Pull live METARs on other days.** KCMH, KOSU, KTZR. When local weather is boring, go hunting.

The four things drilled daily: cloud height (**add two zeros**), wind direction is **FROM**, **the gust** not
the average, Zulu minus 4.

**The Personal Minimums Card is the real point of the week.** Every number needs a written reason and every
number should be stricter than Part 107.

**ODOT Module 1 assigned Monday, due Thu Sep 24**, ahead of next Friday's quiz. Chase LDAP problems early.

### Middle School CS: `while` first, then `for` and modulo

Monday and Tuesday are **content first, then lab**, roughly half and half.

**Monday teaches `while` even though they will not use it until Thursday.** That is deliberate: the concept
gets learned cold, with no game pressure, then sits for three days. Run it as: trace on the board, state the
one rule, **show an infinite loop and let it hang**, four example problems in pairs, then partners **read
loops out loud as English sentences**. That last step is also the question window.

Two trick problems: one counts down when it needs to count up (never ends), and one starts already false
(runs **zero** times, because `while` checks before the first pass).

Tuesday: `for index` earns its place because **the count is usable**. Then modulo as leftovers, and
`remainder of N ÷ 5 = 0` as the "every Nth" pattern. Common error is writing `= 5` instead of `= 0`.

**`for index from 0 to 4` runs FIVE times.** Trace it out loud before they build.

`4-middle-school-cs/handouts/star-catcher-lab.md` is numbered day by day with example problems and a bug
table, fully self-serve.

### Yearbook: the four shot set

**The quarter target: something on every page by the end of the quarter**, so pages can be adjusted as the
book develops. An empty page cannot be improved; a page with a rough layout and placeholder frames can be
critiqued and finished. Worth saying out loud regularly, along with keeping camera sign-ups constant.

Bigger than the aperture pair on purpose. Each shot has a target:

| # | Shot | Proves |
|---|------|--------|
| 1 | Frozen, 1/500+ | Stopping action |
| 2 | **Panning indoors**, ~1/60 | Controlling motion, not avoiding it |
| 3 | **Water frozen**, 1/1000+ | That fast enough changes what a thing IS |
| 4 | **Subject blurred, background sharp**, 1/30 or slower, braced | Blur comes from movement, not bad focus |

**Panning fails far more than it works.** Ten tries for one keeper is normal. Pair students so one shoots
while the other walks, then swap.

**Water is the one that surprises them.** It looks like a stream to the eye and is a line of separate drops
at 1/1000.

**The paragraph defending which belongs in the book is the assessment**, not the photos. All four are
technically correct.

Missing one? Take what they have plus an honest account of which beat them. Three good shots beats four
half-attempts.

---

## Folders

```
INDEX.md                     this file
SLIDE-PROMPTS/               one file per day, all five classes
1-design-techniques/         ui-patterns.md, components-and-variants.md, interaction-labs.md,
                             teardown-sheet.md
2-video-and-sound/           camera-video-settings.md, camera-check.md, production-schedule.md,
                             filming-day.md, review-packet.md, review-packet-key.md,
                             script-peer-review.md, screenplay-format.md, format-drill.md, quiz-bank.csv
3-aviation-uas/              metar-decoder.md, airspace.md, sectional-reading.md, decode-together.md,
                             personal-minimums.md, quiz-bank.csv
4-middle-school-cs/          star-catcher-lab.md
5-yearbook/                  shutter-speed.md
program/week-5-daily-log.md
grading-and-categories.md
```

`outline.md`, `project.md`, `vocab.md`, and `handouts/` are **student-facing.** `teacher-notes.md`,
`quiz.md`, `decode-together.md`, and `review-packet-key.md` are **teacher-only.**

---

## Flagged

- **ODOT Module 1 due date** is set to **Thu Sep 24**, reading "next Friday" as Sep 25. If you meant Sep 18,
  it is a one line change in three files.
- **Three shooting cameras** drives the whole V&S schedule. Confirm the T4i, T5, and T6 are all on the cart
  and charged before Thursday.
- **DT course map** schedules Unit 1.4 for weeks 8 to 9 and it is being taught now.
- **MS CS year map is stale**; digital citizenship skipped entirely.
- **Aviation has no unit outlines**, only labs and quizzes.
