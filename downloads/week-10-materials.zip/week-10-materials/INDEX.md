# Week 10 Materials: Tue Oct 20 to Fri Oct 23

**First week of Q2.** Open `POST-THIS.md` for what to post.

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Tue** | Q2 plan, BPA tour | Color grading | Q2 plan, BPA options | Tinkercad start | Q2 plan, survey |
| **Wed** | Choose second event | Finish color, BPA tour | Choose event | Move, resize, align | Spreads |
| **Thu** | Promo Photo: plan | Choose event and team | Fly or ODOT | Holes and grouping | Assignments posted |
| **Fri** | Start shooting | Bridge Scene due | **QUIZ**, topic, ODOT | Name tag | Check-in due |

## Folders

```
INDEX.md, POST-THIS.md
SLIDE-PROMPTS/          Tuesday
1-design-techniques/    q2-plan.md, handouts/bpa-event-choice.md
2-video-and-sound/      q2-plan.md, handouts/bpa-event-choice.md,
                        handouts/bridge-scene.md and bridge-rubric.md (color, due Fri)
3-aviation-uas/         q2-plan.md, handouts/bpa-event-choice.md,
                        quiz.md, quiz-bank.csv (Friday)
4-middle-school-cs/     q2-plan.md, teacher-notes.md (the Tinkercad unit),
                        handouts/tinkercad-start.md
5-yearbook/             q2-plan.md, teacher-notes.md (making assignments),
                        handouts/q2-survey-FORM.md (build the Google Form from this)
program/                week-10-daily-log.md
```

## Quizzes

Every other week. **Aviation this Friday.** MS CS skips this week, first quiz Fri Oct 30. DT and V&S
next on Fri Oct 30.

## Still to do

- **Yearbook:** build the Form Tuesday, make assignments Wednesday or Thursday
- **Wednesday to Friday slides**, as the week goes
- **Add the WSAP** to DT, V&S and Aviation Classrooms
