# Week 10 Materials: Tue Oct 20 to Fri Oct 23

**First week of Q2.** Open `POST-THIS.md` for what to post.

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Tue** | Q2 plan, BPA tour | Color grading | Q2 plan, BPA options | Tinkercad start | Survey, due end of day |
| **Wed** | Through the Frame, BPA | Finish color, BPA events | Know your event | Skills 1 | Assignments posted |
| **Thu** | Promo Photo: plan | Choose event and team | Fly or ODOT | Skills 2 | Work on assignments |
| **Fri** | Start shooting | Bridge Scene due | **QUIZ**, topic, ODOT | Skills 3 | Work on assignments |

## Folders

```
INDEX.md, POST-THIS.md
SLIDE-PROMPTS/          Tuesday, Wednesday
1-design-techniques/    q2-plan.md, handouts/bpa-event-choice.md, through-the-frame.md
2-video-and-sound/      q2-plan.md, handouts/bpa-event-choice.md,
                        handouts/bridge-scene.md and bridge-rubric.md (color, due Fri)
3-aviation-uas/         q2-plan.md, handouts/bpa-event-choice.md, know-your-event.md,
                        quiz.md, quiz-bank.csv (Friday)
4-middle-school-cs/     q2-plan.md, teacher-notes.md (the Tinkercad unit),
                        vocab.md, handouts/tinkercad-start.md,
                        skills-1, skills-2, skills-3 (Wed, Thu, Fri),
                        3d-project.md (plan by Fri, build next week)
5-yearbook/             q2-plan.md, teacher-notes.md (making assignments),
                        assignments-HOWTO.md + two CSVs (the assignment sheet),
                        handouts/q2-survey-FORM.md (build the Google Form from this)
program/                week-10-daily-log.md, q2-gradebook.md (every Q2 assignment, in points)
```

## Grading

**`program/q2-gradebook.md` lists every graded Q2 assignment with points**, for all five classes.
PowerSchool multiplies points by the category weight, so each category totals 100 raw points.

## First drafts

DT: Promo Photography **Fri Nov 6**, second event **Fri Nov 13**, presented Nov 16 to 18. V&S: whole
piece **Fri Nov 20**, screened Nov 23 to 24. Aviation: **Fri Nov 13**, presented Nov 16 to 18. Check
against the WSAP.

## Quizzes

Every other week. **Aviation this Friday.** MS CS skips this week, first quiz Fri Oct 30. DT and V&S
next on Fri Oct 30.

## Still to do

- **Yearbook:** build the Form Tuesday, make assignments Wednesday or Thursday
- **Wednesday to Friday slides**, as the week goes
- **Add the WSAP** to DT, V&S and Aviation Classrooms
