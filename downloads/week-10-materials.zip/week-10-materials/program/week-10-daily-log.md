# Week 10: Daily Log

**Tue Oct 20 to Fri Oct 23, 2026. First week of Q2.** Monday was PD and grading, no students.

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Tue** | Q2 plan, BPA tour | **Color grading** | Q2 plan, BPA options | Tinkercad accounts, first shapes | Q2 plan, **survey** |
| **Wed** | **Choose second event** | Finish color. BPA tour | **Choose event** | Move, resize, align | Spreads, find missing fall photos |
| **Thu** | Promo Photo: prompt, plan | **Choose event and team** | Fly or ODOT | Holes and grouping | **Assignments posted** |
| **Fri** | Start shooting | **Bridge Scene due** | Topic chosen, ODOT | Name tag or keychain | Check-in due |

---

## Decisions made

**Q2 documents paint in broad strokes, by request.** Each class has a `q2-plan.md` with the quarter in
three or four rough phases, so plans can change without breaking a promise.

**Yearbook: no event list.** Coverage is by area (sports, clubs, arts, student life, academics), not
by event. **Fall is over:** finish placing photos, source missing ones from coaches and advisors, and
apply the theme, **Seasons of Our Lives**, so fall pages look consistent. **Winter** gets a main
photographer and a backup per area. Goals for the quarter: fall pages fully edited, winter laid out with
all photos placed.

**Yearbook workload, per student:** 4 shoots, 15 usable photos per shoot, 2 spreads designed, 2
reviewed, 1 edited. **Students who cannot shoot or design** earn the same credit with small tasks:
editing incoming photos, tagging in eDesign, name checks, captions, collecting coach photos.
**Students who made real progress on a Q1 spread usually keep it.** No work, no credit, but the backup
system makes sure nothing goes uncovered.

**Today is the survey.** 25 questions in a Google Form: roles, fall and winter spreads from the ladder,
winter areas, availability, the theme, and an alternative path. The teacher notes explain how to turn
the answers into assignments.

**DT: Q2 is BPA.** Everyone enters **Promotional Photography** plus one chosen event, individual or
team. **V&S: color grading this week, then BPA**, with Promotional Photography optional. **Aviation:
Presentation (alone or team) is the main recommendation**, since the topic can cover any of the
aviation standards, which make up about 83% of the end-of-course test. Entrepreneurship is the second
option and becomes the capstone. ODOT and review keep running.

**Event names and numbers are not in student documents.** The repo's BPA references are from an older
guide, and this year's list could not be confirmed online. The WSAP you post is what counts.

**MS CS: Tinkercad for Q2.** 3D design for about three weeks, with a few prints to test the printers,
then Tinkercad Circuits with code blocks, then a combined final project. Onshape is a possible Q3
extension.
