# Week 10: Daily Log

**Tue Oct 20 to Fri Oct 23, 2026. First week of Q2.** Monday was PD and grading, no students.

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Tue** | Q2 plan, BPA tour | **Color grading** | Q2 plan, BPA options | Tinkercad accounts, first shapes | Q2 plan, **survey due end of day** |
| **Wed** | **Choose second event** | Keep color grading. BPA tour | **Choose event** | **Skills 1:** getting around | **Assignments posted** |
| **Thu** | Promo Photo: prompt, plan | **Choose event and team** | Fly or ODOT | **Skills 2:** holes and groups | Work on assignments |
| **Fri** | Start shooting | **Bridge Scene due** | **QUIZ**, topic chosen, ODOT | **Skills 3:** details and printing | Work on assignments |

---

## Decisions made

**Q2 documents paint in broad strokes, by request.** Each class has a `q2-plan.md` with the quarter in
three or four rough phases, so plans can change without breaking a promise.

**Yearbook: no event list.** Coverage is by area (sports, clubs, arts, student life, academics), not
by event. **Fall is over:** finish placing photos, source missing ones from coaches and advisors, and
apply the theme, **Seasons of Our Lives**, so fall pages look consistent. **Winter** gets a main
photographer and a backup per area. Goals for the quarter: fall pages fully edited, winter laid out with
all photos placed.

**Yearbook workload, per student:** 4 shoots, 15 usable photos per shoot, 2 spreads designed, 2
reviewed, 1 edited. **Students who cannot shoot or design** earn the same credit with small tasks:
editing incoming photos, tagging in eDesign, name checks, captions, collecting coach photos.
**Students who made real progress on a Q1 spread usually keep it.** No work, no credit, but the backup
system makes sure nothing goes uncovered.

**Today is the survey.** 25 questions in a Google Form: roles, fall and winter spreads from the ladder,
winter areas, availability, the theme, and an alternative path. The teacher notes explain how to turn
the answers into assignments.

**DT: Q2 is BPA.** Everyone enters **Promotional Photography** plus one chosen event, individual or
team. **V&S: color grading this week, then BPA**, with Promotional Photography optional. **Aviation:
Presentation (alone or team) is the main recommendation**, since the topic can cover any of the
aviation standards, which make up about 83% of the end-of-course test. Entrepreneurship is the second
option and becomes the capstone. ODOT and review keep running.

**Event names and numbers are not in student documents.** The repo's BPA references are from an older
guide, and this year's list could not be confirmed online. The WSAP you post is what counts.

**MS CS: one broad unit, Exploring Tinkercad.** 3D design (Weeks 10 to 12, a few prints to test the
printers), Codeblocks to build 3D models with block code (13 to 14), circuit labs on how computer
hardware works: input, processing, output (15 to 17), then a final project combining two parts.
Onshape is a possible Q3 step.

**Quizzes stay every other week.** **Aviation quizzes this Friday** on weather and the mission
briefings: METAR and TAF decoding, Zulu time, the Part 107 weather limits, airspace, TFRs, and writing
to a client. 24 questions. **MS CS skips this week's quiz** to start Tinkercad; the first is Fri Oct 30
on 3D design. **DT and V&S** quizzed Oct 16, so their next is Fri Oct 30.

## Grading: points, not percentages

**PowerSchool's category weight multiplies points** rather than setting a share of the grade, so a
10 point assignment in a 40% category counts as 4. **Every class's Q2 assignments are now planned so each
category totals 100 raw points**, which makes the multipliers come out to the intended weights and the
whole quarter to 100 counted points. The full list, with extra credit for each class, is in
`program/q2-gradebook.md`.

**Yearbook in points:** spreads 50 and 50 (Production and Deadlines), 4 shoots at 25 (Coverage), photo
quality, theme, reviews, and edit (Craft), survey and check-ins (Staff Contribution). Extra
credit is 4 raw per unassigned shoot in Coverage, counting 1 each, up to 5, less than the 6.25 a missed
assigned shoot costs. The survey and `q2-plan.md` now show points.

**MS CS final project:** to be decided near the end of the quarter, since the circuits are simulated and
combining all three parts may not fit.

## Yearbook: shorter survey, check-ins every other week

**Check-ins are every other week, not weekly**, matching what has actually been posted. Five in Q2 at
18 points, starting Fri Oct 30. **The survey is cut to 16 questions** to fit in one period. It now says
**blank choices are assigned at random from what is left**, and **overlaps go first to real Q1 progress
on that spread, then to finished Q1 work.** 12 students.

## First drafts and presenting

**Every BPA student has a first draft due soon**, a complete version even if rough, then presents it to
the class and answers questions in front of everyone. **DT:** Promotional Photography Fri Nov 6, second
event Fri Nov 13, present Nov 16 to 18. **V&S:** the whole piece edited Fri Nov 20, screened Nov 23 to
24. **Aviation:** Fri Nov 13, present Nov 16 to 18. That leaves December for revision before the virtual
registration deadline and January pre-submissions. **The dates are set without the WSAP in hand**; check
them against it at school. The gradebook's first-draft assignments now carry these dates.

**Yearbook:** the survey is due by the end of today. Assignments go up on Classroom Wednesday. Anyone
who finishes the survey works on leftover Q1 work, their spread, or uploading photos.

**V&S:** color grading Tuesday and Wednesday. BPA options are posted Tuesday for anyone who finishes.

**Virtual events are allowed** in every class, by request. The choice sheets now list them: DT adds
Social Media Marketing Campaign and Multimedia and Promotion (Branding Team and Promotional Photography
are already virtual), V&S adds 2D Animation Team, and Aviation adds Promotional Photography (aerial
shots) and Multimedia and Promotion (flight footage). Virtual events usually need registration in early
December and a January submission, which the first-draft dates leave room for.

## Wednesday

**Yearbook:** most finished the survey Tuesday; absences and internet problems left a few. **An
assignment sheet** (two CSVs into one Google Sheet) counts each student's designs, reviews, edits, and
shoots and flags anyone short. Missing surveys finish first thing Thursday; everyone else's assignments
can post now.

**DT:** Promotional Photography examples. This year's prompt is **through the frame**: something in the
scene frames the subject. A short sheet: kinds of frames, two examples, five places to shoot. Then BPA
work time.

**V&S:** finish color grading the Bridge Scene, then look at the BPA events. Choice sheet due Thursday.

**Aviation:** **ODOT Module 3 due Friday.** A **Know Your Event** sheet keeps them in their seats with
the WSAP open: every piece they turn in, the rating sheet, penalties, and deadlines. Each student should
be able to say what they are making by the end of the period.

**MS CS:** the three-day pencil cup build-along was too little work, so it became **one skills sheet a
day, each with new vocabulary**: getting around (views, exact sizes, stacking, a table and a snowman),
holes and groups (a window, a die, the pencil cup, a mirrored build), and details and printing (text,
the ruler, the workplane tool, modeling a real object with tolerance, a print-ready keychain). Each has
more than a period of work plus a done-early build. A vocab list feeds the Oct 30 quiz. Gradebook: three
skills sheets at 5 points in Labs; the measured fit design drops to 10.

**MS CS project:** skills this week while students plan a **3D Design Project**, built next week and due
Mon Nov 2, with Codeblocks starting Tue Nov 3. Three tracks: solve a problem for a real person (measured
to fit), a scale model, or a game. Requirements: 15 or more shapes, holes, groups, align, text, exact
millimeters, one print-ready part. The plan (sketch with sizes, parts list) is due Friday and replaces
the measured-fit lab in the gradebook; the project takes the Projects slot that was "design for a
classmate." Students who finish the skills early start the project early.

