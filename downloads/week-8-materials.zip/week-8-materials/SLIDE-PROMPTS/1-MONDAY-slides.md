# MONDAY (Oct 5): Slide Prompts (all classes)

Every block is **one prompt, for one slide.** Board versions included.

**Standards come first, before the agenda, in every career-tech class.** Full text, not numbers.

| Class | Slides | Shape |
|-------|--------|-------|
| Design Techniques | 5 | **The editor.** White balance, one period |
| Video & Sound | 4 | Storyboard check, then detach audio and layer |
| Aviation UAS | 5 | **New unit: meteorology.** Why air moves |
| Middle School CS | 3 | Lists that change, then practice problems |
| Yearbook | 1 | Next assignment |

---

## 1. Design Techniques: White balance

**Documents:** `week-8/handouts/white-balance-lab.md` (student-facing, post it)
**Before class:** **open a RAW file yourself and confirm which editor comes up.** The handout gives both
paths (Photoshop opens the raw dialog, or Lightroom's Develop module) because the app on these machines
could be either. Confirm it so you can say one thing instead of two.
**Everyone needs to shoot at least one new photo today** for Part 5, so cameras have to be out.
**Run it as:** one period, white balance only. **Do not let them loose on the other sliders yet.**
**The payoff is Part 4:** RAW gives Kelvin, JPEG gives a relative scale with much less room. Students
who grabbed JPEGs will see the limit rather than being told about it.

### Slide 1: Competencies today

> Create one standards slide for a high school design class. Title: "Today's Competencies." List these
> with their FULL text, not just the numbers, in large readable type: 7.9.5 Use International Standards
> Organization (ISO), shutter speed, aperture, and white balance settings to shoot manual photographs.
> 7.9.6 Edit photographs (e.g., color corrections, cropping, enhancements). 7.9.7 Identify differences
> between film photographs and digital images. Add a short line: "Today that means white balance, and
> finding out what a RAW file gives you that a JPEG does not." One slide.

### Slide 2: Getting in

> Create one slide for a high school photography class titled "Opening Your Photos." Two labeled routes,
> side by side. Left, "FROM PHOTOSHOP": File, then Open, then pick a CR2 from your LastName_Photo folder;
> the raw window opens by itself; sliders are on the right, in the Basic panel. Right, "FROM LIGHTROOM":
> import your folder, then click Develop; sliders are on the right, in the Basic panel. Then a box: "Only
> have JPEGs? Open one anyway. Part of today is finding out what you lost." One slide.

### Slide 3: Temperature and tint

> Create one concept slide for a high school photography class titled "White Balance." Explain it is at
> the top of the Basic panel, above everything else. Then two sliders described: TEMPERATURE, blue at one
> end and yellow at the other, measured in Kelvin on a RAW file; and TINT, green at one end and magenta
> at the other. Then in large text: "White balance means making things that are white look white." Add a
> box: "Push each slider ALL THE WAY to both ends before you decide what it does. You cannot learn a
> control by nudging it." One slide.

### Slide 4: The thing to notice

> Create one slide for a high school photography class titled "RAW Versus JPEG." Two columns. Left, "A
> RAW FILE": white balance shown as a real Kelvin number; presets for Daylight, Cloudy, Shade, Tungsten;
> a huge amount of room to move before it falls apart. Right, "A JPEG": a relative scale, not Kelvin;
> far less room; push it and it breaks. Then a box in very large text: "This is why we shot RAW. You are
> about to see it rather than be told it." One slide.

### Slide 5: Do Now

> Create one "Do Now" slide for a high school photography class titled "Start Here." Numbered: "1. Open
> one of your RAW photos. 2. Write down the Kelvin number it opens at. 3. Drag Temperature all the way
> down, then all the way up. Write what color it goes at each end. 4. Do the same with Tint." Then a box:
> "Then find a photo with something you KNOW is white. A wall, paper, a shirt. Is it actually white in the
> photo?" Add a line: "Later today everyone shoots one new photo under the worst light in the room. Keep
> a camera handy." One slide.

### Board version

```
TODAY'S COMPETENCIES (leave on the board)
  7.9.5  use ISO, shutter speed, aperture, and white balance
         settings to shoot manual photographs
  7.9.6  edit photographs (color corrections, cropping,
         enhancements)
  7.9.7  identify differences between film photographs and
         digital images
  -> today: white balance, and what RAW gives you that
     a JPEG does not

GETTING IN
  FROM PHOTOSHOP            FROM LIGHTROOM
   File > Open > a .CR2      import the folder
   the raw window opens      click DEVELOP
   sliders: right side       sliders: right side
   the BASIC panel           the BASIC panel

  only have JPEGs? open one anyway.
  part of today is finding out what you lost.

WHITE BALANCE  (top of the Basic panel)
  TEMPERATURE   blue <-----> yellow    (Kelvin, on RAW)
  TINT          green <-----> magenta

  "white balance = making white things look white"

  PUSH EACH SLIDER ALL THE WAY TO BOTH ENDS first.
  you can't learn a control by nudging it.

RAW                      |  JPEG
  real Kelvin number     |   a relative scale, no Kelvin
  presets: daylight,     |   far less room
  cloudy, shade, tungsten|   push it and it breaks
  lots of room

  *** this is why we shot RAW ***

DO NOW
  1. open a RAW photo. write the Kelvin it opens at.
  2. temperature all the way down, then up. what colors?
  3. same with tint.
  4. find something you KNOW is white. is it actually white?

LATER: everyone shoots ONE new photo under the worst light
  in the room. keep a camera handy.
```

---

## 2. Video & Sound: Detach audio, then layer

**Documents:** `week-8/handouts/layering-and-audio.md` (student-facing, post it),
`week-7/project.md`, `week-7/handouts/cut-plan-and-storyboard.md`
**Run it as:** storyboard check first. **Demo detaching audio and layering on the projector**, then
cleared students build and the rest finish planning.
**The framing that ties it together:** detaching audio and layering video are the same idea. A timeline
has layers, and picture and sound do not have to move together.

### Slide 1: Standards today

> Create one standards slide for a high school video production class. Title: "Today's Standards." List
> these with their FULL text, not just the numbers, in large readable type: 7.3.7 Edit video footage.
> 7.7.6 Add transitions (dissolves, wipes, cuts), titles, special effects, and digital effects. 7.8.8
> Perform audio mixing. One slide.

### Slide 2: The gate

> Create one slide for a high school video production class. In very large text: "Show me a complete,
> clear storyboard and you can start editing." Below: "Until then, CapCut stays closed." Then, smaller:
> "Whoever finishes the plan first starts editing first." Then a short checklist headed "Complete means":
> every shot in order; framing visible; characters tellable apart; the cut type written between panels.
> One slide.

### Slide 3: Detach the audio

> Create one slide for a high school video production class titled "Break Them Apart." Explain that every
> clip arrives with picture and sound locked together, and the first thing you do is separate them: right
> click the clip and look for Detach audio or Separate audio, and the sound drops to its own track. Then
> show two small timeline diagrams in monospace text, a J-CUT with the audio row changing earlier than
> the picture row, and an L-CUT with the audio row changing later. Then a box in large text: "That is all
> a J-cut or an L-cut IS. You are dragging one edge past the other. Adjust in TENTHS of a second." One
> slide.

### Slide 4: Top covers bottom

> Create one slide for a high school video production class titled "The Timeline Has Layers." In large
> text: "A clip on the track above COVERS the clip below it, for as long as it lasts. That is the whole
> mechanism." Then: "So a cutaway is just a clip on the track above." Numbered: "1. Main clip stays on
> the bottom track, WITH its audio. 2. Cutaway goes on the track above, over the moment you want covered.
> 3. Mute or delete the cutaway's audio. 4. Trim it to one or two seconds." Then a box: "The audience
> hears the scene continue while they look at something else. That is why it hides a bad cut." One slide.

### Board version

```
STANDARDS TODAY (leave on the board)
  7.3.7  edit video footage
  7.7.6  add transitions (dissolves, wipes, cuts), titles,
         special effects, and digital effects
  7.8.8  perform audio mixing

* THE GATE: complete, clear storyboard -> you can edit *
  until then, CapCut stays closed.
  whoever finishes the plan first starts editing first.

DETACH THE AUDIO  (right-click > detach / separate audio)
  every clip arrives with picture + sound LOCKED.
  break that first.

  J-CUT              L-CUT
  PIC [ A    ][ B ]  PIC [ A ][ B    ]
  AUD [ A ][ B    ]  AUD [ A    ][ B ]

  that's ALL a J or L cut is. drag one edge past the other.
  adjust in TENTHS of a second.

THE TIMELINE HAS LAYERS.  TOP COVERS BOTTOM.
  -> so a cutaway is just a clip on the track ABOVE

  1. main clip on the bottom track, WITH its audio
  2. cutaway on the track above, over the bad moment
  3. MUTE the cutaway's audio
  4. trim to 1-2 seconds

  they hear the scene continue while looking elsewhere.
  that's why it hides a bad cut.

CAN'T SEE SOMETHING? something above it is in the way.
```

---

## 3. Aviation UAS: Why air moves

**Documents:** `week-8/handouts/meteorology-worksheet.md` (student-facing, make-a-copy, all week),
`week-8/outline.md`
**Run it as:** board instruction, then Part 1 of the worksheet.
**The frame worth opening with:** they already decode METARs. **This week is what the numbers mean.**
**The connection to last week:** density altitude eats your margin exactly the way a heavy payload
does. Say it in those words, because they just learned the payload version.
**Quiz Friday covers everything through last Friday. No meteorology on it.** Say that too.

### Slide 1: Competencies for the week

> Create one standards slide for a high school aviation and drone class. Title: "This Week: Meteorology."
> List these with their FULL text, not just the numbers, in large readable type: 7.6.3 Explain the effects
> of temperature on weather. 7.6.9 Describe weather system formation, including air masses and fronts.
> 7.6.6 Identify wind patterns based on weather systems. 7.6.13 Describe wind and wind effects
> (crosswind, tailwind, windshear, mountain wave). 7.6.11 Describe the types, conditions and factors of
> turbulence. 7.6.12 Describe the types and impact of thunderstorms, tornados, microbursts and
> hurricanes. Design it to stay readable on the board all week. One slide.

### Slide 2: The week, and the quiz

> Create one agenda slide for a high school aviation class titled "This Week." A day plan: MONDAY,
> temperature, pressure, and why air moves at all. TUESDAY, air masses and fronts. WEDNESDAY, wind:
> crosswind, tailwind, windshear, mountain wave. THURSDAY, turbulence and severe weather. FRIDAY, QUIZ,
> then finish the worksheet. Then a box in large text: "Friday's quiz covers everything through LAST
> Friday: forces, motors, hardware, airspace, charts, Part 107. NO meteorology from this week is on it."
> One slide.

### Slide 3: You can already read it

> Create one slide for a high school aviation class. In very large text: "You can already read a METAR.
> This week is what the numbers mean." Below, smaller: "Back in Week 5 you learned to pull visibility,
> ceiling, wind and temperature out of a report. None of that told you WHY the air was doing it, or what
> it was about to do next. That is this week." One slide.

### Slide 4: Why air moves

> Create one concept slide for a high school aviation class titled "Why Air Moves At All." A simple
> three-step chain in large text: "1. The sun heats the ground unevenly. 2. Warm air is less dense, so it
> rises. 3. Air rushes in underneath to replace it." Then in large text: "That rushing in IS wind. Wind
> is air moving from high pressure toward low pressure." Then a small example: "Asphalt heats faster than
> grass. Fly across the edge of the parking lot at 20 feet and you will feel it." One slide.

### Slide 5: Density altitude

> Create one slide for a high school drone class titled "Thin Air." Explain density altitude: how thin
> the air behaves, regardless of your actual altitude, and that three things make air thinner: HEAT,
> HUMIDITY, and ALTITUDE. Then: "Thinner air means your propellers have less to push against, so you get
> less lift from the same motor speed." Then a box in very large text: "Last week: adding a payload eats
> your margin. A hot humid day does exactly the same thing, and you did not choose it." Add a line: "You
> flew fine here in April. It is 95 and humid now. Your aircraft is not the same aircraft today." One
> slide.

### Board version

```
THIS WEEK: METEOROLOGY (leave up all week)
  7.6.3   explain the effects of temperature on weather
  7.6.9   describe weather system formation, including air
          masses and fronts
  7.6.6   identify wind patterns based on weather systems
  7.6.13  describe wind and wind effects (crosswind,
          tailwind, windshear, mountain wave)
  7.6.11  describe the types, conditions and factors of
          turbulence
  7.6.12  describe the types and impact of thunderstorms,
          tornados, microbursts and hurricanes

  MON temperature + pressure: why air moves
  TUE air masses and fronts
  WED wind: crosswind / tailwind / windshear / mountain wave
  THU turbulence + severe weather
  FRI QUIZ, then finish the worksheet

QUIZ FRIDAY = everything through LAST friday.
  forces / motors / hardware / airspace / charts / part 107
  NO meteorology from this week on it.

"you can already read a METAR.
 this week is what the numbers MEAN."

WHY AIR MOVES
  1. the sun heats the ground unevenly
  2. warm air is less dense, so it RISES
  3. air rushes in underneath to replace it

  -> that rushing in IS wind.
     high pressure ---> low pressure

  asphalt heats faster than grass. fly across the edge of
  the lot at 20 ft and you'll feel it.

DENSITY ALTITUDE = how THIN the air behaves
  heat + humidity + altitude all make it thinner
  thinner air = less for the props to push against
              = less lift from the same motor speed

  ** last week: a payload eats your margin.
     a hot humid day does the same thing,
     and you didn't choose it. **

  you flew fine here in april. it's 95 and humid now.
  it is not the same aircraft today.
```

---

## 4. Middle School CS: Lists that change

**Documents:** `week-8/handouts/list-practice.md` (student-facing, post it),
`week-8/project.md` (the final project plan, introduce it today or Tuesday)
**Run it as:** the four mutation blocks on the board, then the practice problems. **Problem 3 is the
lesson:** removing from a list while looping over it breaks, and it is a bug professionals write.
**Mention the final project today** so they start thinking. Planning is Wednesday to Friday.

### Slide 1: Lists change now

> Create one slide for a middle school computer science class titled "Lists That Change." Body: last week
> your lists mostly sat there; this week they change while the game runs. Then a table of four blocks from
> the Arrays drawer with what each does: "add value to end of list" makes the list longer; "remove value
> at index" takes one out and everything after it shifts down; "remove last value" takes the last one off
> and hands it to you; "insert at index" puts one in the middle and everything after it shifts up. Then a
> box in large text: "The SHIFTING is what people forget. Remove item 2 from a list of 5 and what used to
> be item 3 is now item 2." One slide.

### Slide 2: The bug worth seeing

> Create one slide for a middle school computer science class titled "Build This. It Breaks." Show in
> large monospace text: "set stuff to array of 'a' 'b' 'c'" then "for index from 0 to (length of stuff) -
> 1" then indented "remove value at index". Below it: "Run it. What happens? Why?" Then a box: "This is a
> real bug that professionals write. Removing items from a list while you are looping through it changes
> the length underneath you." Do not show the answer. One slide.

### Slide 3: Coming up

> Create one slide for a middle school computer science class titled "Your Own Game." Body: next week is
> the last week of the quarter, and you are going to design and build your own game. This week you plan
> it. Then the six required things in large text: a list used for something that matters; a loop; a
> conditional; a variable that changes during play; a way to win; a way to lose. Then a box: "That is the
> grade. Not how impressive it is. Small and finished beats big and broken, every single time." Add a
> line: "No code until your plan is approved." One slide.

### Board version

```
LISTS THAT CHANGE

  add value to end        -> list gets longer
  remove value at index   -> everything after SHIFTS DOWN
  remove last value       -> takes it off and hands it to you
  insert at index         -> everything after SHIFTS UP

  the SHIFTING is what people forget.
  remove item 2 from a list of 5 ->
  what was item 3 is now item 2.

BUILD THIS. IT BREAKS.
  set stuff to array of  "a"  "b"  "c"
  for index from 0 to (length of stuff) - 1
      remove value at index

  run it. what happens? WHY?
  (professionals write this bug.)

COMING: YOUR OWN GAME, next week.
  this week you PLAN it.

  six required things:
    a LIST that matters / a LOOP / a CONDITIONAL
    a VARIABLE that changes / a WAY TO WIN / a WAY TO LOSE

  that's the grade. not how impressive it is.
  SMALL AND FINISHED BEATS BIG AND BROKEN.

  no code until your plan is approved.
```

---

## 5. Yearbook: Next assignment

**Last week's photos and check-in were due Friday.** This slide needs your call on what the next
assignment is. The pattern that has worked is a two week window with a mid-point check-in.

### Slide 1: What is next

> Create one work slide for a high school yearbook class titled "What's Next." Leave a large open area
> for the teacher to fill in the next assignment and its due date. Add a box at the bottom with the
> standing rules: photos go to eDesign AND Google Classroom, both; files named LastName_Event_01; sign the
> equipment log going out and coming back, every time; offload before you return a camera. One slide.

### Board version

```
YEARBOOK

  NEXT ASSIGNMENT: ______________________
  DUE: ______________________

STANDING RULES
  eDesign AND Classroom. both.
  named  LastName_Event_01
  sign the log out AND back. every time.
  offload BEFORE you return a camera.
```
