# Week 8 Materials: Mon Oct 5 to Fri Oct 9

---

## Slide convention

**Standards and agenda are now one slide, not two.** Standards at the top in exact text, agenda
underneath with each activity paired to the standard it serves. It stays on the board. Changed in
`CLAUDE.md` and applied to this deck.

---

## Four things before first period Monday

1. **Open a RAW file on a student machine.** "The Lightroom that opens with the older Photoshop" is most
   likely **Adobe Camera Raw**, the raw dialog that opens from inside Photoshop or Bridge, not standalone
   Lightroom. **The handout gives both click paths**, so it works either way, but confirm it so you can
   say one thing instead of two
2. **Find Save Image in Camera Raw** (bottom left) or File then Export in Lightroom. **Three of Monday's
   four DT files come out through it**, so the click path has to be right
3. **Have cameras out in DT.** Everyone shoots at least one new photo Monday, deliberately under bad
   light
4. **Decide the next Yearbook assignment.** The Monday slide has a blank for it

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | **White balance, export, isolate a color** | Storyboard check, **detach audio and layer** | **The weather brief opens** | Lists change. **Two problems**, project opens | Next assignment |
| **Tue** | Exposure and tone | Assemble the edit | Air masses and fronts | The larger set, the bug, the collection game | Shoot |
| **Wed** | Clarity, vibrance, saturation | **Split edits**, logged | **Wind, turbulence, severe weather** | **Project planning** | Shoot |
| **Thu** | **Color.** HSL | **Cutaways and layering** | **FLIGHT.** Same drills as last week | Finish the plan, build | Shoot |
| **Fri** | Catch up, submit | Export, then version 2 | **QUIZ**, then the brief | **QUIZ**, then plan or build | Shoot |

---

## Design Techniques: the editor, one slider group a day

**Monday is three things:** white balance, exporting a JPEG, and one open-ended color experiment.
Temperature and tint alone will not fill the period.

**Export is the part they will use forever.** Camera Raw's **Save Image** button, bottom left, Format set
to JPEG. Lightroom's **File then Export**. Both are in the handout. Three files out of one photo:
`LastName_WB_Cold_01`, `LastName_WB_Warm_01`, `LastName_WB_Fixed_01`.

**Then they go further on their own.** Scroll past Basic to **HSL / Color / Color Mixer**, pull every
Saturation slider to minus 100 except one, and a single color survives the photo. Exported as
`LastName_ColorPop_01`. From there they pick at least one more thing: shift that color with Hue, change
its Luminance, leave two colors instead of one, or find split toning and color grading. **Competency
7.4.7 is added** to cover the export.

**Monday is still white balance for teaching purposes.** The other sliders in the Basic panel stay shut
until Tuesday. The temptation is to hand over the whole panel on day one and let them flail.

**The rule in both handouts:** push one slider all the way to both ends before deciding what it does.
**Nudging teaches nothing. Wrong tells you more than subtle.**

**The spine of Monday is RAW versus JPEG.** RAW gives a real Kelvin number and a lot of latitude; a JPEG
gives a relative scale and breaks fast. **Students who grabbed JPEGs last week will see the cost rather
than be told about it.** Question 10 on that sheet is worth more than the rest.

**Everyone shoots one new photo Monday** under the worst light in the room. That covers anyone whose
camera was not set to RAW, and it makes the in-camera versus in-editor comparison real.

**This completes 7.9.5**, which was marked partial last week because white balance was held back on
purpose.

---

## Video & Sound: the gate, then layers

**The storyboard is still the gate.** Complete and clear, and CapCut opens. **Whoever finishes the plan
first starts editing first.**

**Detaching audio and layering video are taught as one idea:** a timeline has layers, and picture and
sound do not have to travel together.

Once that lands, two things become mechanical:

- **A J-cut or an L-cut is just dragging one edge past the other**, in tenths of a second
- **A cutaway is just a clip on the track above**, with its own audio muted so the scene underneath keeps
  running

**The three questions that matter** on that handout are 5, 7 and 8, and they are all the same question:
do you understand that top covers bottom?

---

## Aviation: one weather brief, built all week

**The week is one deliverable, not a worksheet a day.** It is the pre-flight weather brief a real crew
produces before a flight, in `handouts/weather-brief-project.md`, and students build it a section at a
time. **Every section ends in a verdict**, and the data is real, pulled from `aviationweather.gov`.

| Day | What they add to the brief |
|-----|---|
| **Mon** | Section 1: the site and the air. Temperature, pressure, density altitude |
| **Tue** | Section 2: the system moving through. Air masses, fronts, the wind they bring |
| **Wed** | Section 3: the hazard list, ending in **their own go or no-go numbers.** The heavy day |
| **Thu** | Section 4: **they fly it.** `still-in-use/aviation-orbit-drill.md`, and did the brief hold up? |
| **Fri** | **QUIZ**, then finish any unfinished section |

**Thursday the brief gets tested, not graded on paper.** Their Wednesday numbers go outside with them,
and Section 4 asks what the brief **missed**, which is graded as highly as the rest of it.

**Wednesday carries the load on purpose.** Wind effects, turbulence and severe weather together, because
they all answer the same question: what can stop you flying. That makes it the natural home for the
running question's final version.

**Thursday is where the week pays off.** Students bring their own go or no-go list outside and use it on
whatever the actual weather is. Three worksheet questions get answered **after** flying: what the real
numbers were, whether it was a go, and whether they felt anything in the aircraft that the week
explains.

**Friday's time after the quiz is for finishing the brief**, not new material.

**The frame to open with:** *you can already read a METAR. This week is what the numbers mean.* They
decoded METARs and TAFs in Week 5, so this is the layer underneath rather than new territory.

**Density altitude is last week's margin idea in a different costume.** A hot, humid day thins the air
and eats your lift exactly the way a heavy payload does, except you did not choose it. **Say it in those
words**, because they just learned the payload version.

**The question the brief is really asking:** *what would make me cancel this flight?* Each section
narrows it, and Wednesday it becomes numbers. **That is the point of the whole unit.**

**Friday's quiz covers everything through last Friday and no meteorology.** Say that Monday so nobody
studies the wrong material. The **Week 7 Gimkit kit (75 questions)** and the **Week 6 quiz bank** are
both in `still-in-use/`.

---

## Middle School CS: two problems Monday, then planning, quiz Friday

**Monday is deliberately short on practice.** Two problems, both about the shift when you remove an item,
and then the final project opens and they brainstorm. The larger set is Tuesday, in
`handouts/list-practice-day-2.md`, numbered continuously from Monday's sheet.

**Tuesday's Problem 3 is the week's real lesson.** Removing items from a list while looping over it
breaks, and it is a bug professionals write. **They build it, run it, and watch it fail** before being
told why.

**The project sheet is built on project-management stages**, not "go plan it": Scope, Requirements,
Breakdown, Risk. `handouts/project-plan.md`, due Thursday.

**The checklist turns on a removal test**, stated to them exactly this way:

> **Remove it. If the game still plays the same, it was not meaningful.**

Six requirements, each with a Counts and a Does-not-count column: a list the game **reads** to make a
decision, a `for` or `while` loop where the count matters, a conditional that can go either way, a
variable that changes during play, a reachable way to win, a reachable way to lose. **`forever` is
explicitly excluded**, since it is the game loop every project already has. Questions 9 to 14 make them
say what breaks if each one is removed, and **"nothing really" means the design changes, not the answer.**

**No code until the plan is approved**, which is the same shape as the V&S storyboard gate.

**Quiz Friday**, which is new for this class. `4-middle-school-cs/quiz-bank-FOR-FRIDAY.csv`, 31 questions,
cut to 20. Lists, changing a list in a loop, loops, conditionals and variables, and the planning language
off the project sheet. Coverage notes are in the repo at `week-8/quiz.md` (teacher-only).

---

## Flagged

- **Yearbook has no assignment this week yet.** The pattern that has worked is a two week window with a
  mid-point check-in
- **BPA event selection is due this week or next**, across all courses, hard deadline end of Week 9.
  `program/bpa-selection-plan.md` still has three open decisions
- **Unit 1.3 Audio is still owed in V&S**, roughly 16% of the WebXam, nothing covered. This week's
  layering touches levels, which is an on-ramp, not the unit
- **Next week is the last week of the quarter.** MS CS is building. Worth deciding what the other four
  courses do with it, and what has to close for grades

---

## Folders

```
INDEX.md                     this file
POST-THIS.md                 what to post, in priority order
gimkit-howto.md              import steps for the review kits
SLIDE-PROMPTS/               Monday, all five classes
1-design-techniques/         outline,
                             handouts/white-balance-lab.md    (MON)
                             handouts/editing-week-lab.md     (TUE-FRI)
2-video-and-sound/           outline,
                             handouts/layering-and-audio.md   (all week)
3-aviation-uas/              outline,
                             handouts/weather-brief-project.md (ALL WEEK,
                             one section per day)
4-middle-school-cs/          outline,
                             handouts/list-practice.md        (MON)
                             handouts/list-practice-day-2.md  (TUE)
                             handouts/project-plan.md         (THE FINAL
                             PROJECT, due THU)
                             quiz-bank-FOR-FRIDAY.csv         (31, cut to 20)
5-yearbook/                  (empty, pending the next assignment)
still-in-use/                the V&S edit project and cut plan, the Aviation
                             orbit drill for Thursday, the Gimkit kit and
                             Week 6 quiz bank for Friday, and last week's
                             DT photo worksheet
program/week-8-daily-log.md
program/bpa-selection-plan.md
grading-and-categories.md
```

`outline.md`, `project.md`, `vocab.md` and `handouts/` are **student-facing.** `teacher-notes.md`,
`quiz.md` and the quiz banks are **teacher-only.**
