# Week 8 Materials: Mon Oct 5 to Fri Oct 9

---

## Slide convention

**Standards and agenda are now one slide, not two.** Standards at the top in exact text, agenda
underneath with each activity paired to the standard it serves. It stays on the board. Changed in
`CLAUDE.md` and applied to this deck.

---

## Tuesday, at a glance

| Class | Tuesday |
|-------|---------|
| **DT** | **Ten minutes to finish Monday**, then the histogram, then two constrained rounds. Read `1-design-techniques/teacher-notes.md` |
| **V&S** | Ten minutes on rough assembly, then work time. The storyboard gate still holds |
| **Aviation** | **Section 1 reviewed out loud**, then fronts by prediction, then **half the period to work.** Read `3-aviation-uas/teacher-notes.md` first |
| **MS CS** | The bug in the first half, **project planning in the second** |
| **Yearbook** | Keep working. Week 9 check-in already posted |

**Before Tuesday:** put today's METAR, TAF and a surface map on screen before Aviation; pick one photo of
yours with a bright sky and a dark foreground for the DT histogram demo; and start building the Mood
Photos folder for Week 9.

---

## Four things before first period Monday

1. ~~Open a RAW file on a student machine.~~ **Resolved: it is Adobe Camera Raw.** Everything from
   Tuesday forward says Camera Raw only
2. **Find Save Image in Camera Raw** (bottom left) or File then Export in Lightroom. **Three of Monday's
   four DT files come out through it**, so the click path has to be right
3. **Have cameras out in DT.** Everyone shoots at least one new photo Monday, deliberately under bad
   light
4. **Decide the next Yearbook assignment.** The Monday slide has a blank for it

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | **White balance, export, isolate a color** | Storyboard check, **detach audio and layer** | **The weather brief opens** | Lists change. **Two problems**, project opens | Keep working |
| **Tue** | Exposure and tone. **Week 9 named** | 10 min, then **work time** | Air masses and fronts, **rebuilt** | The bug, then **planning** | Keep working |
| **Wed** | Clarity, vibrance, saturation | **Split edits**, logged | **Wind, turbulence, severe weather** | **Project planning** | Keep working |
| **Thu** | **Color.** HSL | **Cutaways and layering** | **FLIGHT.** Same drills as last week | Finish the plan, build | Keep working |
| **Fri** | Catch up, submit | Export, then version 2 | **QUIZ**, then the brief | **QUIZ**, then plan or build | Keep working |

---

## Design Techniques: the editor, one slider group a day

**Monday is three things:** white balance, exporting a JPEG, and one open-ended color experiment.
Temperature and tint alone will not fill the period.

**Export is the part they will use forever.** Camera Raw's **Save Image** button, bottom left, Format set
to JPEG. Lightroom's **File then Export**. Both are in the handout. Three files out of one photo:
`LastName_WB_Cold_01`, `LastName_WB_Warm_01`, `LastName_WB_Fixed_01`.

**Then they go further on their own.** Scroll past Basic to **HSL / Color / Color Mixer**, pull every
Saturation slider to minus 100 except one, and a single color survives the photo. Exported as
`LastName_ColorPop_01`. From there they pick at least one more thing: shift that color with Hue, change
its Luminance, leave two colors instead of one, or find split toning and color grading. **Competency
7.4.7 is added** to cover the export.

**Monday is still white balance for teaching purposes.** The other sliders in the Basic panel stay shut
until Tuesday. The temptation is to hand over the whole panel on day one and let them flail.

**The rule in both handouts:** push one slider all the way to both ends before deciding what it does.
**Nudging teaches nothing. Wrong tells you more than subtle.**

**The spine of Monday is RAW versus JPEG.** RAW gives a real Kelvin number and a lot of latitude; a JPEG
gives a relative scale and breaks fast. **Students who grabbed JPEGs last week will see the cost rather
than be told about it.** Question 10 on that sheet is worth more than the rest.

**Everyone shoots one new photo Monday** under the worst light in the room. That covers anyone whose
camera was not set to RAW, and it makes the in-camera versus in-editor comparison real.

**This completes 7.9.5**, which was marked partial last week because white balance was held back on
purpose.

---

## Video & Sound: the gate, then layers

**The storyboard is still the gate.** Complete and clear, and CapCut opens. **Whoever finishes the plan
first starts editing first.**

**Detaching audio and layering video are taught as one idea:** a timeline has layers, and picture and
sound do not have to travel together.

Once that lands, two things become mechanical:

- **A J-cut or an L-cut is just dragging one edge past the other**, in tenths of a second
- **A cutaway is just a clip on the track above**, with its own audio muted so the scene underneath keeps
  running

**The three questions that matter** on that handout are 5, 7 and 8, and they are all the same question:
do you understand that top covers bottom?

---

## Aviation: Monday went poorly, Tuesday is rebuilt

**Two failures, one root cause:** a long stretch of teacher talk, and the concepts not landing. A student
who has not had to produce an answer does not know they do not have one, and neither do you.

**The day is split in half.** The first twelve minutes are **Monday's questions 1 through 8, taken from
the room out loud**, with students fixing their own answers as you go. **The re-teach lives inside that
review**, not beside it: questions 3, 6 and 7 *are* why air moves and density altitude. Those three get
the turn-and-talks; 1, 4 and 5 are quick confirmations. Then about twelve minutes of new content, and
**the back half of the period they finish Section 2** with the data still on screen. Monday they left
with nothing finished.

**Ten thin slides instead of four**, one idea each, every beat ending in a question they answer, nothing
longer than six minutes of talking. **The four fronts are predict-then-reveal:** they already know dense
air sinks, so every front follows from something they have, and they commit a guess in writing before
seeing any answer.

**There is a per-question answer guide for the Section 1 review** in the teacher notes: what to listen
for on each of the eight, and where to go when it goes wrong.

**The turn-and-talk protocol goes on the board:** 30 seconds alone writing, 60 seconds with a partner
both saying it out loud, then **two people called by name, not hands.** The rule that makes it work is
that you may be asked for **your partner's** answer. Do that once in the first beat or the room will not
believe you.

**You supply the data today.** METAR, TAF and a surface map already on screen. Monday's hunting for it ate
the thinking time.

**The run of show, the two failed concepts and how to re-teach them, and the front-by-front predict
questions are all in `3-aviation-uas/teacher-notes.md`.** Read it before first period.

---

## Aviation: one weather brief, built all week

**The week is one deliverable, not a worksheet a day.** It is the pre-flight weather brief a real crew
produces before a flight, in `handouts/weather-brief-project.md`, and students build it a section at a
time. **Every section ends in a verdict**, and the data is real, pulled from `aviationweather.gov`.

| Day | What they add to the brief |
|-----|---|
| **Mon** | Section 1: the site and the air. Temperature, pressure, density altitude |
| **Tue** | Section 2: the system moving through. Air masses, fronts, the wind they bring |
| **Wed** | Section 3: the hazard list, ending in **their own go or no-go numbers.** The heavy day |
| **Thu** | Section 4: **they fly it.** `still-in-use/aviation-orbit-drill.md`, and did the brief hold up? |
| **Fri** | **QUIZ**, then finish any unfinished section |

**Thursday the brief gets tested, not graded on paper.** Their Wednesday numbers go outside with them,
and Section 4 asks what the brief **missed**, which is graded as highly as the rest of it.

**Wednesday carries the load on purpose.** Wind effects, turbulence and severe weather together, because
they all answer the same question: what can stop you flying. That makes it the natural home for the
running question's final version.

**Thursday is where the week pays off.** Students bring their own go or no-go list outside and use it on
whatever the actual weather is. Three worksheet questions get answered **after** flying: what the real
numbers were, whether it was a go, and whether they felt anything in the aircraft that the week
explains.

**Friday's time after the quiz is for finishing the brief**, not new material.

**The frame to open with:** *you can already read a METAR. This week is what the numbers mean.* They
decoded METARs and TAFs in Week 5, so this is the layer underneath rather than new territory.

**Density altitude is last week's margin idea in a different costume.** A hot, humid day thins the air
and eats your lift exactly the way a heavy payload does, except you did not choose it. **Say it in those
words**, because they just learned the payload version.

**The question the brief is really asking:** *what would make me cancel this flight?* Each section
narrows it, and Wednesday it becomes numbers. **That is the point of the whole unit.**

**Friday's quiz covers everything through last Friday and no meteorology.** Say that Monday so nobody
studies the wrong material. The **Week 7 Gimkit kit (75 questions)** and the **Week 6 quiz bank** are
both in `still-in-use/`.

---

## Design Techniques: Monday did not finish, and Tuesday is the histogram

**One worksheet and four exported files in one period was too much.** The place they stalled is almost
certainly **the export**, which was brand new and is four trips through Save Image, not one. **Give the
first ten minutes to it** and demo Save Image once more on the projector, including the part nobody
guesses: **the slider positions stay put between exports.** You move Temperature and save again, you do
not re-edit each time. **Do not re-teach white balance.** They are behind on clicks, not concept.

**Tuesday's goal is not "the rest of the sliders."** It is that they can look at the Camera Raw screen
and know what a slider will do **before** they drag it. That makes the histogram the lesson and the
sliders the practice.

Three facts and nothing more: **left is dark, right is bright, height is how much.** Then:

- **Clipping warnings on in the first two minutes.** The two small triangles in the histogram's top
  corners. **Blue means shadow detail is gone, red means highlight detail is gone.** Leave them on all
  week. That one step is what turns "looks about right" into something checkable
- **Five regions left to right, one slider each:** Blacks, Shadows, Exposure, Highlights, Whites.
  **Check whether hovering a region names its slider** on these machines. If it does, dragging the mouse
  across the graph teaches all five faster than explaining them
- **Exposure slides the whole graph. Contrast pulls the ends apart.** Show both watching the histogram
  rather than the photo

**The back half is two constrained rounds, and this is the part to protect:**

| | |
|---|---|
| **Round 1** | **Exposure and Contrast only.** Make it as good as you can, then **name what is still wrong**, specifically, and where |
| **Round 2** | **Unlock Blacks, Shadows, Highlights, Whites. Exposure and Contrast are frozen.** Fix the thing you named |

**Handed all six sliders at once, a student drags everything until it looks okay and learns nothing about
which slider did what.** Round 1 produces a specific complaint, Round 2 has a target, and the last
question asks what Round 1 proved about why the other four exist. **That is the understanding, not the
finished photo.**

**Photos: their own RAW files from last week.** There was no time to build a supplied pool before first
period and everyone has a folder already. **Put one photo of yours on the projector** for the demo,
picked on purpose: bright sky, dark foreground, so the warnings actually fire. A flat indoor snapshot
shows nothing.

**Exemplars are optional and the rubric is the part that transfers.** If you make one, screenshot the
histogram in both the before and the after, because without it you are showing taste rather than a
measurable claim. The rubric: histogram reaches both ends without piling against either wall; no red or
blue except specular highlights, which are allowed to clip; the subject's midtones near the middle; and
the toggle test shows an obvious difference a stranger could not attribute to specific sliders. Full
notes, including the distinctions they get wrong, are in `1-design-techniques/teacher-notes.md`.

**Mood moved to Wednesday**, next to Saturation, since they are the same kind of decision. The lab is
renumbered **1 to 36**.

---

## Design Techniques: the editor is Camera Raw

**Confirmed: Adobe Camera Raw**, the raw dialog that opens from inside Photoshop. Tuesday's handout and
slides say Camera Raw only. **Monday's white balance sheet still names both paths and is already posted
to students, so it was left alone.**

**Wednesday opens with mood**, questions 16 to 18. Six tone sliders is mechanics. The thing worth
teaching is:

> **Correct is a measurement. Mood is a decision.**

Three decisions carry it: **where the shadows sit** (Shadows, Blacks), **how far apart dark and light
are** (Contrast), and **which way the color leans** (Temperature). They take the photo they just fixed,
make it heavier **without touching Exposure**, then make it lighter, then answer whether the honest
version is the better photo. **That last one has no right answer and it is the highest-value question on
the sheet.**

**Week 9 is Three Moods, not the Repair Clinic.** The clinic needed four RAW files each broken exactly one
way, and a free gallery posts its good photos, not its failures, so building that set meant shooting all
four yourself. Three Moods needs only decent RAW files: one photo, three versions (neutral and correct,
then two moods from four starting points), then they argue for one and name the audience. **The grade is
on the decision, not the repair**, which is the harder skill anyway.

**The diagnostic muscle is not lost.** It is Tuesday through Thursday in the editing lab, where they find
clipping by causing it.

**You have to build the folder:** six to eight RAW photos, nothing already graded, with sky and ground in
the same frame so all three mood decisions have something to act on.
`1-design-techniques/week-9-mood-TEACHER.md` has the sources, what to pick, what to avoid, and what to
listen for on each question. **None of those pages could be opened from the environment that built this**,
so budget ten minutes to check them.

---

## Middle School CS: two problems Monday, then planning, quiz Friday

**Monday is deliberately short on practice.** Two problems, both about the shift when you remove an item,
and then the final project opens and they brainstorm. The larger set is Tuesday, in
`handouts/list-practice-day-2.md`, numbered continuously from Monday's sheet.

**Tuesday's Problem 3 is the week's real lesson.** Removing items from a list while looping over it
breaks, and it is a bug professionals write. **They build it, run it, and watch it fail** before being
told why.

**The project sheet is built on project-management stages**, not "go plan it": Scope, Requirements,
Breakdown, Risk. `handouts/project-plan.md`, due Thursday.

**The checklist turns on a removal test**, stated to them exactly this way:

> **Remove it. If the game still plays the same, it was not meaningful.**

Six requirements, each with a Counts and a Does-not-count column: a list the game **reads** to make a
decision, a `for` or `while` loop where the count matters, a conditional that can go either way, a
variable that changes during play, a reachable way to win, a reachable way to lose. **`forever` is
explicitly excluded**, since it is the game loop every project already has. Questions 9 to 14 make them
say what breaks if each one is removed, and **"nothing really" means the design changes, not the answer.**

**No code until the plan is approved**, which is the same shape as the V&S storyboard gate.

**The collection game is cut.** Their own project is the build now, and a second collection game competes
for the same time. Tuesday is the problems in the first half and the plan in the second. Say the split out
loud at the start or they will pace themselves for a full period of problems.

**Quiz Friday**, which is new for this class. `4-middle-school-cs/quiz-bank-FOR-FRIDAY.csv`, 31 questions,
cut to 20. Lists, changing a list in a loop, loops, conditionals and variables, and the planning language
off the project sheet. Coverage notes are in the repo at `week-8/quiz.md` (teacher-only).

---

## Flagged

- **DT Week 9 needs a folder of six to eight RAW photos before Monday**, and they are not in this zip
- **BPA event selection is due this week or next**, across all courses, hard deadline end of Week 9.
  `program/bpa-selection-plan.md` still has three open decisions
- **Unit 1.3 Audio is still owed in V&S**, roughly 16% of the WebXam, nothing covered. This week's
  layering touches levels, which is an on-ramp, not the unit
- **Next week is the last week of the quarter.** MS CS is building and DT has the Repair Clinic. **V&S,
  Aviation and Yearbook are still undecided for Week 9**, and so is what has to close for grades

---

## Folders

```
INDEX.md                     this file
POST-THIS.md                 what to post, in priority order
gimkit-howto.md              import steps for the review kits
SLIDE-PROMPTS/               Monday and Tuesday, all five classes
1-design-techniques/         outline,
                             teacher-notes.md                 (TUESDAY
                             RUN OF SHOW + exemplar rubric. teacher-only)
                             handouts/white-balance-lab.md    (MON)
                             handouts/editing-week-lab.md     (TUE-FRI,
                             questions 1-36)
                             week-9-mood-project.md           (WEEK 9)
                             week-9-mood-TEACHER.md           (sourcing
                             the photos. teacher-only)
2-video-and-sound/           outline,
                             handouts/layering-and-audio.md   (all week)
3-aviation-uas/              outline,
                             teacher-notes.md                 (TUESDAY
                             RUN OF SHOW. read it. teacher-only)
                             handouts/weather-brief-project.md (ALL WEEK,
                             one section per day)
4-middle-school-cs/          outline,
                             handouts/list-practice.md        (MON)
                             handouts/list-practice-day-2.md  (TUE, then
                             planning takes the back half)
                             handouts/project-plan.md         (THE FINAL
                             PROJECT, due THU)
                             quiz-bank-FOR-FRIDAY.csv         (31, cut to 20)
5-yearbook/                  (empty, pending the next assignment)
still-in-use/                the V&S edit project and cut plan, the Aviation
                             orbit drill for Thursday, the Gimkit kit and
                             Week 6 quiz bank for Friday, and last week's
                             DT photo worksheet
program/week-8-daily-log.md
program/bpa-selection-plan.md
grading-and-categories.md
```

`outline.md`, `project.md`, `vocab.md` and `handouts/` are **student-facing.** `teacher-notes.md`,
`quiz.md`, `teacher-notes.md`, anything marked TEACHER, and the quiz banks are **teacher-only.**
