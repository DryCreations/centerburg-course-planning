# Week 8 Materials: Mon Oct 5 to Fri Oct 9

---

## Three things before first period Monday

1. **Open a RAW file on a student machine.** "The Lightroom that opens with the older Photoshop" is most
   likely **Adobe Camera Raw**, the raw dialog that opens from inside Photoshop or Bridge, not standalone
   Lightroom. **The handout gives both click paths**, so it works either way, but confirm it so you can
   say one thing instead of two
2. **Have cameras out in DT.** Everyone shoots at least one new photo Monday, deliberately under bad
   light
3. **Decide the next Yearbook assignment.** The Monday slide has a blank for it

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | **White balance** | Storyboard check, **detach audio and layer** | **Meteorology opens** | Lists that change | Next assignment |
| **Tue** | Exposure and tone | Assemble the edit | Air masses and fronts | The collection game | Shoot |
| **Wed** | Clarity, vibrance, saturation | **Split edits**, logged | **Wind, turbulence, severe weather** | **Project planning** | Shoot |
| **Thu** | **Color.** HSL | **Cutaways and layering** | **FLIGHT.** Same drills as last week | Finish the plan, build | Shoot |
| **Fri** | Catch up, submit | Export, then version 2 | **QUIZ**, then the worksheet | Keep building | Shoot |

---

## Design Techniques: the editor, one slider group a day

**Monday is white balance only.** The temptation is to hand over the whole Basic panel on day one and
let them flail.

**The rule in both handouts:** push one slider all the way to both ends before deciding what it does.
**Nudging teaches nothing. Wrong tells you more than subtle.**

**The spine of Monday is RAW versus JPEG.** RAW gives a real Kelvin number and a lot of latitude; a JPEG
gives a relative scale and breaks fast. **Students who grabbed JPEGs last week will see the cost rather
than be told about it.** Question 14 on that sheet is worth more than the rest.

**Everyone shoots one new photo Monday** under the worst light in the room. That covers anyone whose
camera was not set to RAW, and it makes the in-camera versus in-editor comparison real.

**This completes 7.9.5**, which was marked partial last week because white balance was held back on
purpose.

---

## Video & Sound: the gate, then layers

**The storyboard is still the gate.** Complete and clear, and CapCut opens. **Whoever finishes the plan
first starts editing first.**

**Detaching audio and layering video are taught as one idea:** a timeline has layers, and picture and
sound do not have to travel together.

Once that lands, two things become mechanical:

- **A J-cut or an L-cut is just dragging one edge past the other**, in tenths of a second
- **A cutaway is just a clip on the track above**, with its own audio muted so the scene underneath keeps
  running

**The three questions that matter** on that handout are 5, 7 and 8, and they are all the same question:
do you understand that top covers bottom?

---

## Aviation: three days of weather, fly Thursday, quiz Friday

| Day | |
|-----|---|
| **Mon** | Temperature, pressure, why air moves, density altitude |
| **Tue** | Air masses, fronts, and the wind patterns they create |
| **Wed** | **Wind effects, turbulence, severe weather.** The heavy day |
| **Thu** | **FLIGHT.** Orbit a target or figure eight, assigned by name. `still-in-use/aviation-orbit-drill.md` |
| **Fri** | **QUIZ**, then finish whatever is unfinished in the worksheet |

**Wednesday carries the load on purpose.** Wind effects, turbulence and severe weather together, because
they all answer the same question: what can stop you flying. That makes it the natural home for the
running question's final version.

**Thursday is where the week pays off.** Students bring their own go or no-go list outside and use it on
whatever the actual weather is. Three worksheet questions get answered **after** flying: what the real
numbers were, whether it was a go, and whether they felt anything in the aircraft that the week
explains.

**Friday's time after the quiz is for finishing the worksheet**, not new material.

**The frame to open with:** *you can already read a METAR. This week is what the numbers mean.* They
decoded METARs and TAFs in Week 5, so this is the layer underneath rather than new territory.

**Density altitude is last week's margin idea in a different costume.** A hot, humid day thins the air
and eats your lift exactly the way a heavy payload does, except you did not choose it. **Say it in those
words**, because they just learned the payload version.

**A running question carries the week:** *what would make me cancel a flight?* Answered at the end of
every day, getting longer each time. By Thursday it should be specific and include numbers. **That is the
point of the whole unit.**

**Friday's quiz covers everything through last Friday and no meteorology.** Say that Monday so nobody
studies the wrong material. The **Week 7 Gimkit kit (75 questions)** and the **Week 6 quiz bank** are
both in `still-in-use/`.

---

## Middle School CS: mutation, then planning

**Problem 3 is the week's real lesson.** Removing items from a list while looping over it breaks, and it
is a bug professionals write. **They build it, run it, and watch it fail** before being told why.

**The final project is free choice against six required items:** a list that matters, a loop, a
conditional, a variable that changes, a way to win, a way to lose. **That is the grade**, not ambition.

**The stated rule:** small and finished beats big and broken, every single time.

**No code until the plan is approved**, which is the same shape as the V&S storyboard gate.

---

## Flagged

- **Yearbook has no assignment this week yet.** The pattern that has worked is a two week window with a
  mid-point check-in
- **BPA event selection is due this week or next**, across all courses, hard deadline end of Week 9.
  `program/bpa-selection-plan.md` still has three open decisions
- **Unit 1.3 Audio is still owed in V&S**, roughly 16% of the WebXam, nothing covered. This week's
  layering touches levels, which is an on-ramp, not the unit
- **Next week is the last week of the quarter.** MS CS is building. Worth deciding what the other four
  courses do with it, and what has to close for grades

---

## Folders

```
INDEX.md                     this file
POST-THIS.md                 what to post, in priority order
gimkit-howto.md              import steps for the review kits
SLIDE-PROMPTS/               Monday, all five classes
1-design-techniques/         outline,
                             handouts/white-balance-lab.md    (MON)
                             handouts/editing-week-lab.md     (TUE-FRI)
2-video-and-sound/           outline,
                             handouts/layering-and-audio.md   (all week)
3-aviation-uas/              outline,
                             handouts/meteorology-worksheet.md (MON-WED,
                             plus a short Thursday and Friday section)
4-middle-school-cs/          outline, project.md (THE FINAL PROJECT),
                             handouts/list-practice.md
5-yearbook/                  (empty, pending the next assignment)
still-in-use/                the V&S edit project and cut plan, the Aviation
                             orbit drill for Thursday, the Gimkit kit and
                             Week 6 quiz bank for Friday, and last week's
                             DT photo worksheet
program/week-8-daily-log.md
program/bpa-selection-plan.md
grading-and-categories.md
```

`outline.md`, `project.md`, `vocab.md` and `handouts/` are **student-facing.** `teacher-notes.md` and
`quiz.md` are **teacher-only.**
