# Week 8 Materials: Mon Oct 5 to Fri Oct 9

---

## Slide convention

**Standards and agenda are now one slide, not two.** Standards at the top in exact text, agenda
underneath with each activity paired to the standard it serves. It stays on the board. Changed in
`CLAUDE.md` and applied to this deck.

---

## Friday, at a glance

| Class | Friday |
|-------|--------|
| **DT** | **Portfolio day.** Two different photos from the week, each a before and after, with a short reflection |
| **V&S** | **Finish and upload.** You circulate for playback, one student at a time |
| **Aviation** | **QUIZ**, then finish the weather brief |
| **MS CS** | **QUIZ**, then build |
| **Yearbook** | Keep working |

### The two quizzes

**Aviation: `3-aviation-uas/quiz-bank-FOR-FRIDAY.csv`, 30 questions, 22 on charts and airspace.** No
weather at all, including no METAR or TAF decoding. **Part 107 is one question** since you are adding your
own ODOT-aligned ones. **Option lengths are balanced:** the correct answer is the longest option in 6 of
30, and never more than 4 characters longer than every distractor. Notes in `3-aviation-uas/quiz.md`.

**MS CS: 14 new code-trace questions** in `4-middle-school-cs/quiz-screenshot-questions.csv`, with the
JavaScript snippets in `4-middle-school-cs/handouts/quiz-screenshot-blocks.md`. **Paste into the
JavaScript tab, switch to Blocks, screenshot.** Your three formats: what does the sprite say, what is the
variable after this runs, the player presses A then B. **Every answer was verified by running the code.**
Suggested mix with your most-missed questions from earlier quizzes is in `4-middle-school-cs/quiz.md`.

### Do these yourself

1. **Build the MS CS screenshots before class.** Clear the editor between each
2. **Check the reset-to-defaults menu name in Camera Raw**, which DT needs to export the before images.
   Older: Camera Raw Defaults. Newer: Reset to Default
3. **Tell Aviation the quiz has no weather on it**, before it starts
4. **V&S: keep a list of who has played back for you**

### One flag from writing the aviation quiz

**The Week 5 `sectional-reading.md` handout calls the big grid-square number magenta. On sectionals it is
blue.** The quiz never asks its color. The handout is already out, so it was not changed.

---

## Thursday, at a glance

| Class | Thursday |
|-------|----------|
| **DT** | **Three photos.** Ten minutes of base, then changing one color. **Five questions** |
| **V&S** | **Cutaways**, demoed in CapCut, then cover your own worst cut |
| **Aviation** | **FLIGHT.** One slide, split: pre-check and the goal. **The orbit is now centered in frame** |
| **MS CS** | Bell ringer: **search a list.** Then **project plans are due** |
| **Yearbook** | Keep working |

**Also today: Trojan time.** `program/trojan-time-oct.md`. **Nothing to print.** Count To Twenty for five
minutes, then Werewolf for twenty, with role counts for 17 and a run-of-show. Drawing Telephone is the
paper-and-pencil backup.

### DT: three photos, five questions

**Three RAW files attached to the assignment. They edit all three, and the editing is the period.** The
sheet is five questions and one of them is just their notes from the presentation.

| | |
|---|---|
| **Before the bell** | **Slide 1 is up:** standards, agenda, and the download steps |
| **~10 min** | Get all three to a decent base, in order. **No questions attached** |
| **~12 min** | The color lesson: three definitions, three jobs, the one-slider discovery |
| **Rest** | **Make one color win on each photo**, then submit all three |

**They need Finder open**, not the download bar: shift-click all three, right-click, **Open With,
Photoshop**, any version listed. All three land in the filmstrip.

**The first ten minutes, in order:** Temperature and Tint, Contrast then Exposure, the tonal details
(Highlights, Shadows, Whites, Blacks), then Vibrance, Saturation, Clarity, Dehaze, then final tweaks.
**They have done all of these already**, so this is the first unassisted run of the whole chain, which
**tells you who is ready for Friday.** Say the reason out loud: **a photo that is still too dark will not
be saved by changing its greens.**

### Picking the three photos

**HSL is per-color, so the colors have to be separated.** Across the three you want:

| Trait | Why |
|---|---|
| **A blue sky in at least one** | **Blue Luminance is the most satisfying demo in HSL.** Sky goes deep and dramatic, nothing else moves |
| **Green foliage in at least one** | Green Hue is the most visible Hue move there is |
| **One strong warm accent somewhere** | Red door, yellow sign, orange jacket. **The obvious "make one color win" subject** |
| **3 or 4 distinct hues per photo, large areas** | A slider that moves a tiny sign teaches nothing |
| **One with a face, if you can** | Orange and red control skin, so it teaches the caution while they work |

**Three photos that differ from each other beats three good ones that are similar**, because question 4
asks which needed the most color work and that only has an answer if they differ. **Avoid**
monochromatic, sunsets, gradients and night shots: you cannot tell which slider did what.

### The two things to teach carefully

**1. Three tabs, three jobs**, or the tabs feel like the same slider three times.

| Tab | Job |
|---|---|
| **Hue** | **Fix and separate.** A color is wrong, or two colors mush together |
| **Saturation** | **Subtract to emphasize.** Pull the other nine down rather than pushing one up |
| **Luminance** | **Add drama.** Darker is heavier, brighter lifts off the page |

**Question 1 is them writing these down**, so give it a beat. **And say the subtraction point out loud:**
every instinct is to push the favorite color up, which makes a neon mess.

**2. One slider rarely owns a whole object.** A sky is **blue and aqua**, grass **green and yellow**, skin
**orange and red**. Question 2 makes them find it by noticing **what did not go grey.** That is why a
first dramatic sky only half works.

### Question 5 is the quiet one

**What did you set in the first ten minutes that you went back and changed after the color work?**

**Editing is not a one-way list.** Dropping a sky's luminance usually means exposure needs nudging;
killing four colors' saturation often means the photo needs more contrast. **"Nothing" means they did
very little, or did not look again.**

### Color grading is a separate assignment

`handouts/color-grading-extension.md`, **posted ungraded and due Friday**, for whoever finishes.

**Say out loud that we go deeper into grading later in the year**, so nobody thinks they missed the real
version. It covers both **Color Grading** (newer, three wheels) and **Split Toning** (older, hue and
saturation pairs plus Balance), and its one rule is **saturation around 5 to 15**, so whoever tries 60
first will decide the panel is useless.

**Friday is a catch-up day.** Finish and submit what is outstanding; anyone done moves to the grading
assignment. **No new sheet.**

### The five things to do yourself

1. **Demo the cutaway in CapCut**, under five minutes. Clip on the track above, **mute its audio**, trim
   to one or two seconds. Then they cover their own worst cut
2. **Say a no-go is a real answer** before anyone goes outside. If today exceeds the limits they wrote
   yesterday, saying so is the correct call and gets logged
3. **Collect MS CS plans**, asking the one question that is the whole rubric: what breaks if I remove it?
4. **Open all three DT photos yourself**, via Finder and Open With, and confirm they land in the
   filmstrip together
5. **Check which grading panel Camera Raw has**, so you can name it when you point at the extension

### Aviation: the orbit standard changed

**The target stays centered in the camera frame the whole way around.** That means **the aircraft has to
rotate as it circles**: a nose-fixed circle loses the object out of frame within a quarter lap. Roll,
pitch and yaw mixed continuously, controls reversing through the far half. **Expect the first laps to
wobble.**

**Scaffold in `3-aviation-uas/orbit-drill.md`:** one lap nose-fixed to get the circle round, then add the
rotation. **Do not let them stop at nose-fixed.**

**The figure eight has no single target to center on**, so its standard stays even loops, constant
altitude, clean crossover. **Say that out loud** so that group does not think it is being let off.

**Recording is the submission.** Anyone who thinks they have it films a lap and the videos get watched as
a group. **The frame does not lie** about centering the way your eyes from the ground might.

---

## Wednesday, at a glance

| Class | Wednesday |
|-------|-----------|
| **DT** | **Walk back the clipping rule.** Two photos all period, **one page, five questions**: silent review, discussion, dehaze, clarity, Vibrance vs Saturation |
| **V&S** | Split edits. Three J-cuts, three L-cuts, logged with timecodes and offsets |
| **Aviation** | **The hazard list.** Vocab and the two things they cannot infer, then half the period on Section 3 |
| **MS CS** | **Dialogue and parallel lists**, then project planning. **Plan due Thursday** |
| **Yearbook** | Keep working |

**Before Wednesday:** **check whether Camera Raw has Dehaze** and where (Basic in newer versions, **FX
panel** in older, absent before 2015, and question 2 depends on it); **attach the two RAW files to the DT
assignment and open them yourself first**; **put slide 1 up before the bell**; and read the Aviation
teacher notes for the two things to teach directly.

### DT: the clipping correction

**Tuesday's rule was too strict.** "Avoid red and blue" produces grey, timid photos.

> A clipped area is a **solid block of one color**, no detail, no texture. The warnings say **where**
> that is happening. **They do not say you made a mistake.**
>
> **Most good photos have at least one thing that is solid black.** Without a true black anywhere, an
> image reads washed out, foggy and weak.

**The rule instead:** push until the warning **just barely appears**, then stop. Never a large area,
never the subject. **Aesthetics come first.** Said as a question: not *is anything clipped*, but ***is
anything I care about clipped.***

### DT: two photos, all period

**Wednesday has its own one-page sheet**, `handouts/two-photos.md`, **five questions, four steps.** Step
1 opens both files, **step 2 is the silent review with no questions attached**, step 3 is the four new
sliders pushed both ways on both photos with four reflection questions, step 4 is deciding final values
and exporting. **`editing-week-lab.md` is now the Thursday-and-Friday sheet**, 13 questions.

**Say "all the way up, then all the way down, then back to zero" out loud** before step 3. Left to
themselves they will nudge, and the reflection questions only have answers if they went to both ends.

**Two RAW files attached to the assignment:** a **hazy cityscape** and a **backlit portrait**, person in
front of grass with sun behind and cloud in the sky. **They edit both.**

| | |
|---|---|
| **Before the bell** | **Slide 1 is up.** Download both, shift-select, right-click, **Open With, Photoshop** |
| **~10 min** | **Silent review.** Monday and Tuesday, both photos, their own calls. **No worksheet questions** |
| **~10 min** | **Discussion.** Look-fors, artistic choices, histogram shape |
| **~8 min** | **Dehaze** on both, and below zero |
| **~6 min** | **Clarity** on both, and below zero |
| **~7 min** | **Saturation against Vibrance** on the portrait |
| **Rest** | Finish both, export both, write the two paragraphs |

**No slack in that period.** If something gives, **shorten the discussion**, not the silent ten minutes
and not the finishing time: the two paragraphs are the assignment.

**Do not help during the ten minutes** unless someone is stuck on a click. You are finding out what they
can do unassisted, which is information you need before Friday. **Checklist on the board, timebox said
out loud.**

### Why Dehaze behaves differently on the two photos

**This is question 1, the best question on the sheet.** Same slider, same value, two different results,
because **only one of those photos has real haze in it.**

**Cityscape:** genuine atmosphere between camera and buildings. Dehaze is built for it. The distance
separates and gains contrast and color. **It looks like the photo was waiting for it.**

**Backlit portrait:** the milky wash is **veiling glare**, light scattering inside the lens from shooting
toward the sun. **Dehaze cannot tell the difference and attacks it anyway:** the glow around the subject
dies, the sky goes unnaturally heavy, the grass goes dark and over-saturated. **The photo's best feature
is the thing Dehaze removes.**

**Negative Dehaze is the payoff.** Below zero it adds a milky lift. On the cityscape that just looks like
the problem came back. **On the portrait it can be genuinely good**, exaggerating the glow into something
intentional, which means **the right move on that photo may be the opposite of what the slider is named
for.**

### Clarity: these two photos are its best and worst case

**On the cityscape, this is what Clarity is for.** Building edges, window grids, brick. Point out the
**halo** along the roofline against the sky when it goes too far, and that **Clarity makes the haze look
grungier** rather than clearing it, because it boosts local contrast inside the murk instead of cutting
through it.

**On the portrait, this is the demo they remember.** +100 on skin exaggerates every pore and line,
deepens the under-eye shadows, and **ages the person about fifteen years**, with a halo around the hair.
**Let them do it to a real face.**

**Then below zero on that same photo**, because slight negative Clarity is a genuine portrait technique:
it softens skin without blurring the eyes. Paired with negative Dehaze, that is a point worth saying out
loud: **on this portrait, both sliders are better run backwards than forwards.**

**Question 3 is the synthesis question.** Both make a photo punchier, so how do they differ?

| | Dehaze | Clarity |
|---|---|---|
| **Targets** | The haze. Atmosphere between camera and subject | Local contrast at **edges**, anywhere |
| **Color** | Changes it noticeably. Deepens and saturates | Mostly leaves it alone |
| **Overdone giveaway** | Skies unnaturally heavy, shadows crush | **Halos** along hard edges |

**"Dehaze is about distance, Clarity is about edges" has it.**

### Saturation against Vibrance, on the portrait

That photo has all three cases in one frame, which is why it is the right one:

| Look at | Saturation +60 | Vibrance +60 |
|---|---|---|
| **The sky** | Already strong, so it goes first. Banding, cloud edges breaking up | Barely moves |
| **The grass** | Electric, unreal green | Comes up, stays plausible |
| **Their skin** | **Orange.** Visible from the back of the room | Mostly protected |

**Demo it yourself, in that order, pointing at the three places.** Thirty seconds, and it lands harder
than the explanation. Then: **reach for Vibrance first, add Saturation only if it still needs it.**

### Two things that will go wrong

1. **Double-click may not open Photoshop** if the association is something else. **Open With is the
   reliable path**, which is why the slide says it that way
2. **The filmstrip offers to sync settings across both images.** Somebody will use it and both photos get
   the cityscape's treatment. **Say not to, twice**

### What they hand in

**`LastName_City_01` and `LastName_Portrait_01`, plus one short paragraph per photo** (question 5). What they were
going for, the two or three decisions that mattered most, and anything that fought them. **Not a
slider-by-slider account.** That paragraph is the assignment.

**Clarity got cut.** No room, and it is off the sheet. It belongs next to the portrait, so **pick it up
Thursday with HSL** or let it go. Nothing later depends on it.

---

## Tuesday, at a glance

| Class | Tuesday |
|-------|---------|
| **DT** | **Ten minutes to finish Monday**, then the histogram **taught off the slides**, then two versions exported. Read `1-design-techniques/teacher-notes.md` |
| **V&S** | Ten minutes on rough assembly, then work time. The storyboard gate still holds |
| **Aviation** | **Section 1 reviewed out loud**, then fronts by prediction, then **half the period to work.** Read `3-aviation-uas/teacher-notes.md` first |
| **MS CS** | The bug in the first half, **project planning in the second** |
| **Yearbook** | Keep working. Week 9 check-in already posted |

**Before Tuesday:** put today's METAR, TAF and a surface map on screen before Aviation; **download a set
of 6 to 8 RAW files for DT** and let them pick one, **testing one on a student machine first**; and start
building the Mood Photos folder for Week 9.

---

## Four things before first period Monday

1. ~~Open a RAW file on a student machine.~~ **Resolved: it is Adobe Camera Raw.** Everything from
   Tuesday forward says Camera Raw only
2. **Find Save Image in Camera Raw** (bottom left) or File then Export in Lightroom. **Three of Monday's
   four DT files come out through it**, so the click path has to be right
3. **Have cameras out in DT.** Everyone shoots at least one new photo Monday, deliberately under bad
   light
4. **Decide the next Yearbook assignment.** The Monday slide has a blank for it

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | **White balance, export, isolate a color** | Storyboard check, **detach audio and layer** | **The weather brief opens** | Lists change. **Two problems**, project opens | Keep working |
| **Tue** | Exposure and tone. **Week 9 named** | 10 min, then **work time** | Air masses and fronts, **rebuilt** | The bug, then **planning** | Keep working |
| **Wed** | Clarity, vibrance, saturation | **Split edits**, logged | **Wind, turbulence, severe weather** | **Project planning** | Keep working |
| **Thu** | **Color.** HSL | **Cutaways and layering** | **FLIGHT.** Same drills as last week | Finish the plan, build | Keep working |
| **Fri** | Catch up, submit | Export, then version 2 | **QUIZ**, then the brief | **QUIZ**, then plan or build | Keep working |

---

## Design Techniques: the editor, one slider group a day

**Monday is three things:** white balance, exporting a JPEG, and one open-ended color experiment.
Temperature and tint alone will not fill the period.

**Export is the part they will use forever.** Camera Raw's **Save Image** button, bottom left, Format set
to JPEG. Lightroom's **File then Export**. Both are in the handout. Three files out of one photo:
`LastName_WB_Cold_01`, `LastName_WB_Warm_01`, `LastName_WB_Fixed_01`.

**Then they go further on their own.** Scroll past Basic to **HSL / Color / Color Mixer**, pull every
Saturation slider to minus 100 except one, and a single color survives the photo. Exported as
`LastName_ColorPop_01`. From there they pick at least one more thing: shift that color with Hue, change
its Luminance, leave two colors instead of one, or find split toning and color grading. **Competency
7.4.7 is added** to cover the export.

**Monday is still white balance for teaching purposes.** The other sliders in the Basic panel stay shut
until Tuesday. The temptation is to hand over the whole panel on day one and let them flail.

**The rule in both handouts:** push one slider all the way to both ends before deciding what it does.
**Nudging teaches nothing. Wrong tells you more than subtle.**

**The spine of Monday is RAW versus JPEG.** RAW gives a real Kelvin number and a lot of latitude; a JPEG
gives a relative scale and breaks fast. **Students who grabbed JPEGs last week will see the cost rather
than be told about it.** Question 10 on that sheet is worth more than the rest.

**Everyone shoots one new photo Monday** under the worst light in the room. That covers anyone whose
camera was not set to RAW, and it makes the in-camera versus in-editor comparison real.

**This completes 7.9.5**, which was marked partial last week because white balance was held back on
purpose.

---

## Video & Sound: the gate, then layers

**The storyboard is still the gate.** Complete and clear, and CapCut opens. **Whoever finishes the plan
first starts editing first.**

**Detaching audio and layering video are taught as one idea:** a timeline has layers, and picture and
sound do not have to travel together.

Once that lands, two things become mechanical:

- **A J-cut or an L-cut is just dragging one edge past the other**, in tenths of a second
- **A cutaway is just a clip on the track above**, with its own audio muted so the scene underneath keeps
  running

**The three questions that matter** on that handout are 5, 7 and 8, and they are all the same question:
do you understand that top covers bottom?

---

## Aviation: Monday went poorly, Tuesday is rebuilt

**Two failures, one root cause:** a long stretch of teacher talk, and the concepts not landing. A student
who has not had to produce an answer does not know they do not have one, and neither do you.

**The day is split in half.** The first twelve minutes are **Monday's questions 1 through 8, taken from
the room out loud**, with students fixing their own answers as you go. **The re-teach lives inside that
review**, not beside it: questions 3, 6 and 7 *are* why air moves and density altitude. Those three get
the turn-and-talks; 1, 4 and 5 are quick confirmations. Then about twelve minutes of new content, and
**the back half of the period they finish Section 2** with the data still on screen. Monday they left
with nothing finished.

**Ten thin slides instead of four**, one idea each, every beat ending in a question they answer, nothing
longer than six minutes of talking. **The four fronts are predict-then-reveal:** they already know dense
air sinks, so every front follows from something they have, and they commit a guess in writing before
seeing any answer.

**There is a per-question answer guide for the Section 1 review** in the teacher notes: what to listen
for on each of the eight, and where to go when it goes wrong.

**The turn-and-talk protocol goes on the board:** 30 seconds alone writing, 60 seconds with a partner
both saying it out loud, then **two people called by name, not hands.** The rule that makes it work is
that you may be asked for **your partner's** answer. Do that once in the first beat or the room will not
believe you.

**You supply the data today.** METAR, TAF and a surface map already on screen. Monday's hunting for it ate
the thinking time.

**The run of show, the two failed concepts and how to re-teach them, and the front-by-front predict
questions are all in `3-aviation-uas/teacher-notes.md`.** Read it before first period.

---

## Aviation: one weather brief, built all week

**The week is one deliverable, not a worksheet a day.** It is the pre-flight weather brief a real crew
produces before a flight, in `handouts/weather-brief-project.md`, and students build it a section at a
time. **Every section ends in a verdict**, and the data is real, pulled from `aviationweather.gov`.

| Day | What they add to the brief |
|-----|---|
| **Mon** | Section 1: the site and the air. Temperature, pressure, density altitude |
| **Tue** | Section 2: the system moving through. Air masses, fronts, the wind they bring |
| **Wed** | Section 3: the hazard list, ending in **their own go or no-go numbers.** The heavy day |
| **Thu** | Section 4: **they fly it.** `3-aviation-uas/orbit-drill.md`, and did the brief hold up? |
| **Fri** | **QUIZ**, then finish any unfinished section |

**Thursday the brief gets tested, not graded on paper.** Their Wednesday numbers go outside with them,
and Section 4 asks what the brief **missed**, which is graded as highly as the rest of it.

**Wednesday carries the load on purpose.** Wind effects, turbulence and severe weather together, because
they all answer the same question: what can stop you flying. That makes it the natural home for the
running question's final version.

**Thursday is where the week pays off.** Students bring their own go or no-go list outside and use it on
whatever the actual weather is. Three worksheet questions get answered **after** flying: what the real
numbers were, whether it was a go, and whether they felt anything in the aircraft that the week
explains.

**Friday's time after the quiz is for finishing the brief**, not new material.

**The frame to open with:** *you can already read a METAR. This week is what the numbers mean.* They
decoded METARs and TAFs in Week 5, so this is the layer underneath rather than new territory.

**Density altitude is last week's margin idea in a different costume.** A hot, humid day thins the air
and eats your lift exactly the way a heavy payload does, except you did not choose it. **Say it in those
words**, because they just learned the payload version.

**The question the brief is really asking:** *what would make me cancel this flight?* Each section
narrows it, and Wednesday it becomes numbers. **That is the point of the whole unit.**

**Friday's quiz covers everything through last Friday and no meteorology.** Say that Monday so nobody
studies the wrong material. The **Week 7 Gimkit kit (75 questions)** and the **Week 6 quiz bank** are
both in `still-in-use/`.

---

## Design Techniques: Monday did not finish, and Tuesday is the histogram

**One worksheet and four exported files in one period was too much.** The place they stalled is almost
certainly **the export**, which was brand new and is four trips through Save Image, not one. **Give the
first ten minutes to it** and demo Save Image once more on the projector, including the part nobody
guesses: **the slider positions stay put between exports.** You move Temperature and save again, you do
not re-edit each time. **Do not re-teach white balance.** They are behind on clicks, not concept.

**Tuesday is taught off the slides, not off Camera Raw.** Every histogram shape they need to recognize is
drawn on a slide, so you point at a diagram while they compare it to their own screen, rather than
driving the editor and explaining at the same time. **16 thin slides**, each ending in a prompt.

| | |
|---|---|
| **~10 min** | Finish Monday's four files |
| **~5 min** | Pick a photo from the set and download it |
| **~20 min** | **Part 1 together**, off the slides. Call and response |
| **Rest** | **Three stages**, and **two exports** |

**They pick from a set of 6 to 8 downloaded RAW files**, not one shared file. Choice keeps them invested,
and the lesson is reading their own graph rather than matching your result.

### Downloading the set

**The risk is compatibility, not licensing.** An older Camera Raw cannot open a RAW file from a camera
newer than itself. **Prefer Canon CR2 from bodies roughly 2010 to 2016**, the same era as the room's
Rebels. **A CR3 from a newer Canon is the most likely thing to fail.** Test one on a student machine
before posting the link.

**None of these pages could be opened from the environment that built this zip**, so the notes come from
search descriptions. Budget ten minutes.

| Source | Why | Watch for |
|---|---|---|
| **[raw.pixls.us](https://raw.pixls.us/)** | **The pick.** Searchable by exact camera model, so filtering to a Rebel-era Canon removes the compatibility risk, and everything is **CC0 public domain** | Built for developers, so many are plain test shots. Do not clone the dataset, it is ~65GB |
| **[Lapse of the Shutter](https://www.lapseoftheshutter.com/free-raw-landscape-images-for-retouching/)** | One-click, no email or signup. Landscapes, so sky plus ground suits all six goals | No faces |
| **[Shotkit](https://shotkit.com/free-raw-photos/)** | ~138 files organized by camera brand, Canon section reachable directly | Wrapped in article text |
| **[Signature Edits](https://www.signatureedits.com/free-raw-photos/)** | Biggest and best looking, mostly CR2, free for any use | Most likely of the four to want an email address |

**Build the set on purpose**, not just eight nice photos: a bright area and a dark area in the same frame,
something slightly wrong rather than broken, real detail in the bright part, nothing already graded and
re-exported. **Include one with a visible color cast** so stage 1 has real work in it, **one clipped at
capture** so slide 9 has its permanent-loss example, and **one with a person in it**, because a face at
the far left of the histogram reads as a dark photo in a way a dark barn does not.

**Part 1 is call and response.** Each prompt slide says do one thing, look at your screen, report. Four
shapes, which is yours. Warnings on, any red or blue already. **Everybody push Exposure to +2**, what
turned red and where. Bring it back. Blacks to minus 100.

### The clipping distinction, which is the lesson of the day

> **Red that appeared when you pushed comes back.** Nothing was thrown away. You asked the file to show
> more than it holds in that spot, and backing off returns it.
>
> **Red that was there at 0 does not come back.** The camera lost it at capture. No slider recovers it.
>
> **And once you export a clipped JPEG, it is gone for everybody, forever.**

**Do not say clipping is simply irreversible.** Inside Camera Raw on a RAW file it is not, and a student
who pushes a slider and watches it return will catch you. **Flag whoever reports red at 0** on slide 7
and use their photo as the example on slide 9: it is the one permanent case, sitting right there in the
room.

### They get a target, not a taste test

Six goals, on slide 13 and on the sheet, **checked before each export:**

1. **White things look white.** No color cast. Monday's lesson, carried forward
2. The graph reaches toward both ends
3. No tall spike jammed against either wall
4. No red or blue, except a bulb, a window, or sun off chrome
5. The subject sits in the middle, not at an edge
6. Toggle the edits off and on and the difference is obvious

Two slides back these up: **gaps versus walls** (a gap is a wasted opportunity, a wall is lost
information) and **what Exposure and Contrast do to the graph**, which is where too much Contrast
clipping both ends at once comes from.

**The back half is three stages, and this is the part to protect:**

| Stage | | |
|---|---|---|
| **1** | **Temperature and Tint** | **Review of Monday**, and the right order anyway: a cast makes every tone decision after it a guess, because a dark area and a blue area look the same |
| **2** | **Exposure and Contrast** | The coarse controls. Get as close to the six goals as you can, then **name which goal is still off** and where. Export `LastName_Tone_A_01` |
| **3** | **Highlights, Shadows, Whites, Blacks** | For what is left over, which is what stage 2 made them name. Export `LastName_Tone_B_01` |

**Say the order out loud rather than just imposing it.** White balance first because a cast poisons every
tone judgment after it. The coarse controls next, so the fine ones have less to do. The region sliders
last, because they are for the leftovers.

**Handed the whole panel at once, a student drags everything until it looks okay and learns nothing about
which slider did what.** Stage 2 produces a specific complaint against the goals list, and stage 3 has a
target. **Nobody is asked which version they prefer.** Version B meets more of the goals; that is
the finding and it needs no preference attached. The last question is what the four could do that two
could not.

**Hold the slider list and the order, and say the restriction is temporary.** **No Saturation, Vibrance,
Clarity or HSL today**, or somebody finds Saturation and the photo becomes a different assignment. Camera
Raw has no separate midtone slider: **Exposure is the midtones.** The rest of the color panel opens up
Wednesday.

**From Wednesday on they go back to their own RAW files.** The shared photo is only so Tuesday's
follow-along stays in step.

**No exemplars.** The goals list is the better instrument anyway: a target a student checks their own
photo against beats a picture of someone else's result, and it costs no prep. **Put the goals list on the
board.** Full notes, including the call-and-response table and the distinctions they get wrong, are in
`1-design-techniques/teacher-notes.md`.

**Mood moved to Wednesday**, next to Saturation, since they are the same kind of decision.

---

## Design Techniques: the editor is Camera Raw

**Confirmed: Adobe Camera Raw**, the raw dialog that opens from inside Photoshop. Tuesday's handout and
slides say Camera Raw only. **Monday's white balance sheet still names both paths and is already posted
to students, so it was left alone.**

**Wednesday opens with mood**, questions 16 to 18. Six tone sliders is mechanics. The thing worth
teaching is:

> **Correct is a measurement. Mood is a decision.**

Three decisions carry it: **where the shadows sit** (Shadows, Blacks), **how far apart dark and light
are** (Contrast), and **which way the color leans** (Temperature). They take the photo they just fixed,
make it heavier **without touching Exposure**, then make it lighter, then answer whether the honest
version is the better photo. **That last one has no right answer and it is the highest-value question on
the sheet.**

**Week 9 is Three Moods, not the Repair Clinic.** The clinic needed four RAW files each broken exactly one
way, and a free gallery posts its good photos, not its failures, so building that set meant shooting all
four yourself. Three Moods needs only decent RAW files: one photo, three versions (neutral and correct,
then two moods from four starting points), then they argue for one and name the audience. **The grade is
on the decision, not the repair**, which is the harder skill anyway.

**The diagnostic muscle is not lost.** It is Tuesday through Thursday in the editing lab, where they find
clipping by causing it.

**You have to build the folder:** six to eight RAW photos, nothing already graded, with sky and ground in
the same frame so all three mood decisions have something to act on.
`1-design-techniques/week-9-mood-TEACHER.md` has the sources, what to pick, what to avoid, and what to
listen for on each question. **None of those pages could be opened from the environment that built this**,
so budget ten minutes to check them.

---

## Middle School CS: two problems Monday, then planning, quiz Friday

**Monday is deliberately short on practice.** Two problems, both about the shift when you remove an item,
and then the final project opens and they brainstorm. The larger set is Tuesday, in
`handouts/list-practice-day-2.md`, numbered continuously from Monday's sheet.

**Tuesday's Problem 3 is the week's real lesson.** Removing items from a list while looping over it
breaks, and it is a bug professionals write. **They build it, run it, and watch it fail** before being
told why.

**The project sheet is built on project-management stages**, not "go plan it": Scope, Requirements,
Breakdown, Risk. `handouts/project-plan.md`, due Thursday.

**The checklist turns on a removal test**, stated to them exactly this way:

> **Remove it. If the game still plays the same, it was not meaningful.**

Six requirements, each with a Counts and a Does-not-count column: a list the game **reads** to make a
decision, a `for` or `while` loop where the count matters, a conditional that can go either way, a
variable that changes during play, a reachable way to win, a reachable way to lose. **`forever` is
explicitly excluded**, since it is the game loop every project already has. Questions 9 to 14 make them
say what breaks if each one is removed, and **"nothing really" means the design changes, not the answer.**

**No code until the plan is approved**, which is the same shape as the V&S storyboard gate.

**The collection game is cut.** Their own project is the build now, and a second collection game competes
for the same time. Tuesday is the problems in the first half and the plan in the second. Say the split out
loud at the start or they will pace themselves for a full period of problems.

**Quiz Friday**, which is new for this class. `4-middle-school-cs/quiz-bank-FOR-FRIDAY.csv`, 31 questions,
cut to 20. Lists, changing a list in a loop, loops, conditionals and variables, and the planning language
off the project sheet. Coverage notes are in the repo at `week-8/quiz.md` (teacher-only).

---

## Flagged

- **DT Week 9 needs a folder of six to eight RAW photos before Monday**, and they are not in this zip
- **BPA event selection is due this week or next**, across all courses, hard deadline end of Week 9.
  `program/bpa-selection-plan.md` still has three open decisions
- **Unit 1.3 Audio is still owed in V&S**, roughly 16% of the WebXam, nothing covered. This week's
  layering touches levels, which is an on-ramp, not the unit
- **Next week is the last week of the quarter.** MS CS is building and DT has Three Moods. **V&S and
  Aviation are still undecided for Week 9**, and so is what has to close for grades
- **Aviation Section 3 may have been revised.** Wednesday's slides and teacher notes are written against
  the version in this zip, questions 19 to 30. If it changed, they need re-cutting

---

## Folders

```
INDEX.md                     this file
POST-THIS.md                 what to post, in priority order
gimkit-howto.md              import steps for the review kits
SLIDE-PROMPTS/               Mon through Fri, all five classes
1-design-techniques/         outline,
                             teacher-notes.md                 (TUESDAY
                             RUN OF SHOW + where to download the
                             photo set. teacher-only)
                             handouts/white-balance-lab.md    (MON)
                             handouts/tone-lab.md             (TUE.
                             13 questions, TWO files out)
                             handouts/two-photos.md           (WED.
                             5 questions. post it with the TWO
                             raw files attached)
                             handouts/color-lab.md            (THU.
                             5 questions. post it with THREE
                             raw files attached)
                             handouts/portfolio-photos.md     (FRI)
                             handouts/color-grading-extension.md
                             (SEPARATE assignment. ungraded.
                             due Friday. for whoever finishes)
                             week-9-mood-project.md           (WEEK 9)
                             week-9-mood-TEACHER.md           (sourcing
                             the photos. teacher-only)
2-video-and-sound/           outline,
                             handouts/layering-and-audio.md   (all week)
3-aviation-uas/              outline, quiz-bank-FOR-FRIDAY.csv (30),
                             quiz.md (teacher), orbit-drill.md (THU flight,
                             teacher ref. CENTERING standard updated),
                             teacher-notes.md                 (TUESDAY
                             RUN OF SHOW. read it. teacher-only)
                             handouts/weather-brief-project.md (ALL WEEK,
                             one section per day)
4-middle-school-cs/          outline,
                             handouts/list-practice.md        (MON)
                             handouts/list-practice-day-2.md  (TUE, then
                             planning takes the back half)
                             handouts/dialogue-lists.md       (WED)
                             handouts/bell-ringer-thu.md      (THU)
                             handouts/project-plan.md         (THE FINAL
                             PROJECT, due THU)
                             quiz-bank-FOR-FRIDAY.csv         (31 text)
                             quiz-screenshot-questions.csv    (14 code)
                             handouts/quiz-screenshot-blocks.md (the
                             snippets for the screenshots)
5-yearbook/                  (empty, pending the next assignment)
still-in-use/                the V&S edit project and cut plan, the Gimkit kit,
                             the Week 6 aviation bank (for METAR or regulation
                             add-ins), and last week's
                             DT photo worksheet
program/week-8-daily-log.md
program/trojan-time-oct.md   TROJAN TIME. no setup needed.
program/bpa-selection-plan.md
grading-and-categories.md
```

`outline.md`, `project.md`, `vocab.md` and `handouts/` are **student-facing.** `teacher-notes.md`,
`quiz.md`, `teacher-notes.md`, anything marked TEACHER, and the quiz banks are **teacher-only.**
