# Post This

Week 7. Each line is one post. Paths are inside `week-7-materials/` in the zip.

---

## Monday, before class

| Post | File | Type |
|------|------|------|
| 1 | `2-video-and-sound/vocab.md` | **Material. The study guide**, and it says how to study it |
| 2 | `4-middle-school-cs/handouts/starter-code-lists.md` | **Material.** Today's build, follow along |
| 3 | `5-yearbook/handouts/spirit-week-shot-plan.md` | **Material.** Post before cameras go out |
| 4 | `3-aviation-uas/handouts/how-to-study-this.md` | **Material.** Monday's second half |
| 5 | **DT: hold.** Post `state-and-variables.md` **or** `photo-composition.md` once you know which plan | See below |

### Gimkit kits, both ready to import

| Class | File | Questions |
|-------|------|-----------|
| Design Techniques | `1-design-techniques/gimkit-review.csv` | 52 |
| Video & Sound | `2-video-and-sound/gimkit-review.csv` | 58 |

Columns are already in Gimkit's order: **Question, Correct Answer, Incorrect Answer 1, 2, 3.** Create a
kit, Import, upload or paste, host.

> **Retrieval first, game second.** If the game comes first it is entertainment. If they have already
> found out what they do not know, the game is the second pass and it sticks.

### Design Techniques is a decision, not a post

**Do not post a DT handout until the login test is done.** First ten minutes of class: two or three
students log in and open the Figma Variables panel.

**Monday is a review day either way.** The test only decides Tuesday.

| Result | Post, and when |
|--------|------|
| Panel is there | `1-design-techniques/handouts/state-and-variables.md`, **Monday** |
| Missing, greyed out, or logins fail | `1-design-techniques/handouts/photo-composition.md`, **Tuesday** |

**Do not narrate the licensing problem to students.** One sentence: *"We are done with this unit. It is
finished work and it is on your portfolio. Today we start photography."*

**Also Monday, not a post:** pull the miss counts off Friday's Aviation and MS CS quizzes. Both Monday
lessons are built on real data, not a general review.

---

## Design Techniques

| Post | File | Type |
|------|------|------|
| 0 | `1-design-techniques/gimkit-review.csv` | **Monday's review game.** 52 questions, import straight in |
| 1a | `1-design-techniques/handouts/state-and-variables.md` | **Plan A only, Monday.** Find the state, make the variable, delete the frames |
| 1b | `1-design-techniques/handouts/photo-composition.md` | **Plan B only, Tuesday.** Composition, light, five frames |
| 2 | `1-design-techniques/outline.md` | Material. Week at a glance. **Plan A wording** |
| 3 | Quiz from `1-design-techniques/quiz-bank.csv` | **Quiz Friday**, cut to 20 |

**Post 1a or 1b, never both.**

**Due Friday, Plan A:** prototype with a working variable, duplicate frames deleted and listed,
write-up, portfolio updated, share link on Classroom.

**Due Friday, Plan B:** the five composition frames with a sentence each, the four lighting frames, and
the three you picked with your reasoning.

**Quiz, either plan:** same bank. Plan A cuts 9 state + 8 UX/UI + 3 typography. **Plan B skips the 16
state questions, and what remains is exactly 20.** No new bank needed.

---

## Video & Sound

| Post | File | Type |
|------|------|------|
| 1 | `2-video-and-sound/vocab.md` | **Material, post Monday. The study guide**, and it opens with how to study it |
| 2 | `2-video-and-sound/gimkit-review.csv` | **Monday's review game.** 58 questions, import straight in |
| 3 | `2-video-and-sound/handouts/how-cuts-happen.md` | **Material, post Tuesday.** J-cuts, L-cuts, cutaways, cutting on action |
| 4 | `2-video-and-sound/handouts/capcut-color-and-features.md` | **Material, post Wednesday.** Color order, then the features they have not touched |
| 5 | `2-video-and-sound/handouts/screening-and-peer-review.md` | **Material, post Thursday** if you run the screening |
| 6 | `2-video-and-sound/handouts/editing-depth-lab.md` | **Optional.** The 20% cut and the extension list. Good filler any day |
| 7 | `2-video-and-sound/outline.md` | Material |
| 8 | Quiz from `2-video-and-sound/quiz-bank.csv` | **Quiz Friday**, cut to 20 |

**Due Friday:** final cut at 1080p **and** last week's assembly, both. A log of the four cut techniques
(timecode, which one, did it help). Three sentences.

**Thursday is flexible.** Screening or next-project planning, both written. Decide midweek.

---

## Aviation UAS

| Post | File | Type |
|------|------|------|
| 1 | `3-aviation-uas/handouts/how-to-study-this.md` | **Material, post Monday.** Retrieval practice, spacing, and the nine numbers |
| 2 | `3-aviation-uas/vocab.md` | **Material, post Monday. The running study list**, everything through Week 7 |
| 3 | `3-aviation-uas/handouts/aircraft-and-battery-safety.md` | **Material, post Tuesday.** Components, batteries, preflight, logging |
| 4 | `3-aviation-uas/handouts/bpa-event-choice.md` | **Material, post by Wednesday.** So they have time to think before Friday |
| 5 | `3-aviation-uas/outline.md` | Material |
| 6 | **A short form** for the BPA choice | **Assignment, due Friday.** Event, topic or business idea, and why |

**Bell ringers resume Tuesday.** One chart question a day, from
`week-6/handouts/coordinate-bell-ringers.md`. Teacher reference, do not post.

---

## Middle School CS

| Post | File | Type |
|------|------|------|
| 1 | `4-middle-school-cs/handouts/starter-code-lists.md` | **Material, post Monday.** Today's guided build |
| 2 | `4-middle-school-cs/handouts/lists-lab.md` | **Material, post Tuesday.** The rest of the week plus extensions |
| 3 | `4-middle-school-cs/outline.md` | Material |

**No quiz this week.** Thursday's build is the check.

---

## Yearbook

| Post | File | Type |
|------|------|------|
| 1 | `5-yearbook/handouts/spirit-week-shot-plan.md` | **Material, post Monday.** Daily plan and settings |
| 2 | `5-yearbook/outline.md` | Material |

**Already out:** the two week photo assignment (`week-6/project.md`), **due Friday Oct 2**.

**Check the camera sign-out sheet Monday and name who is not on it.** Friday will be full.

---

## Quizzes this week

| Class | When | Bank | Cut to |
|-------|------|------|--------|
| Design Techniques | **Friday** | 36 questions | 20 |
| Video & Sound | **Friday** | 34 questions | 20 |

Both plain CSV, no images, nothing coupled. `option_a` is always correct, so let the script shuffle.
Each has a suggested cut in its `quiz.md`.

> **V&S note:** the bank has **both** 180 degree rules, shutter speed and camera placement. Unrelated
> concepts, same name. If your cut includes both, say so before the quiz.

---

## The short version

If Monday goes sideways, in this order:

1. **The two Gimkit kits.** DT and V&S both run a full period off them alone
2. **Run the DT login test anyway.** Ten minutes, and it decides Tuesday
3. **The Yearbook shot plan**, so cameras go out the door on the best coverage week of the quarter
4. **`how-to-study-this.md`** for Aviation and the MS CS starter code
5. Everything else can wait until Tuesday
