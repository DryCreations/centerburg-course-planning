# Week 7 Materials: Mon Sep 28 to Fri Oct 2

---

## Wednesday: three things to do before first period

1. **Check every camera body is set to RAW**, and ISO on Auto. **A body left on JPEG costs that student
   the whole week** and you will not find out until Monday
2. **Download the Cinestudy hospital scene** into the V&S shared folder, verify it works, and grab the
   lower-resolution version if the machines struggle.
   `cinestudy.org/2025/03/12/interactive-project-l-cuts-split-edits/`. **Read
   `2-video-and-sound/handouts/footage-options-TEACHER.md` first** for the vetted menu and which
   projects to preview before offering
3. Post `photo-worksheet.md` (make-a-copy), `split-edits-lab.md`, and `2-video-and-sound/project.md`

---

## Wednesday at a glance

| Class | Wednesday |
|-------|-----------|
| **DT** | **Unit 2.1 Photography opens.** BPA for 10 minutes, shutter priority, then shoot. New: `handouts/photo-worksheet.md` (digital, three days) plus its key |
| **V&S** | Cut types, then **the edit project opens.** Pick, download, read the script. **No editor today.** New: `project.md`, `split-edits-lab.md`, `cut-plan-and-storyboard.md`, `footage-options-TEACHER.md` |
| **Aviation** | Your plan: torque, CW and CCW rotation, worksheet second half |
| **MS CS** | Your plan: one more thing with lists. Thu and Fri are work days |
| **Yearbook** | Two days left. Games today, the last easy coverage before Friday |

---

## Design Techniques: photography, three days

**Cameras stay in the room**, shared, signed out per period, because Yearbook has checkout as a
requirement with photos due Friday. All four bodies shoot RAW including the T3, since this is stills.

**Shutter priority first.** The motion effects are immediately visible, and the slow end works fine
indoors because a slow shutter lets in **more** light. The fast end going dark indoors is taught as the
trade, not as a failure.

**Every challenge gives a range, not a number.** A student handed `1/500` learns to obey a number. A
student handed `1/250, 1/500, 1/1000` finds the edge themselves, and the edge is the lesson.

**The panning correction:** a walking subject needs **`1/30`, `1/15`, `1/8`**. Anything faster will not
blur the background, which is why the last round came out sharp. Expect **one keeper in fifteen**, and
say that number out loud.

**White balance is deliberately not mentioned.** 7.9.5 covers ISO, shutter, aperture and white balance
together, so it is **marked partial** and finished next week in the editor. ISO stays on Auto all week
so they learn two settings rather than three.

**While waiting for a camera, students answer written questions.** There are twelve and they need no
equipment. Say that up front.

**Grade the explanations, not the photos.** A blurry photo with a correct explanation of why it blurred
beats a lucky sharp one with nothing behind it.

---

## Video & Sound: the edit project opens, and runs into next week

**This is no longer a one-period lab.** `project.md` has the whole arc.

| Day | What |
|-----|------|
| **Wed** | Cut types. Pick a project, download, **read the script.** No editor |
| **Thu** | Watch every clip, log it, start marking cut points |
| **Fri** | Quiz, then finish the cut plan and start the storyboard |
| **Next week** | Build it. Then build it **again, differently** |

**No editor Wednesday, and say why:**

> *An editor with a plan makes decisions. An editor without one makes whatever the timeline suggests.*

Expect pushback. The honest version: **the scene takes about an hour to build with a plan and four hours
without one, and the four-hour version comes out worse.**

**Their own footage does not suit split edits**, which live in conversations. They get a finished script
and complete coverage, so every remaining decision is editing.

### The storyboard bar, stated clearly

**Art quality does not matter. Stick figures are fine.** What is graded is **framing** (how much of the
person is in frame), **who is in the shot**, and the **cut type marked between panels**. Characters only
have to be tellable apart: different hair, a hat, a letter over the head.

**Say "five seconds a panel."** Someone spending two minutes on a panel is drawing, not planning.

### Footage choice

`handouts/footage-options-TEACHER.md` has the vetted menu with URLs. **Offer two or three, not ten.**

**Say the hospital scene is the easiest path to a good grade**, because it was built for exactly this.
That makes choosing something else deliberate rather than accidental. **The documentary one is the
strongest second option**: real interview footage, and cutting an interview is nothing but J and L cuts.

> **Several projects on that site are horror or mature in tone.** The student list contains only the
> safe set. **Preview whatever you offer.** Those pages could not be opened from here, so the flags come
> from titles and descriptions rather than from viewing them.

### The question that makes the cut plan work

> **"Whose face do I want to be on right now? The person speaking, or the person hearing it?"**

That turns "where do I cut" from a mechanical question into a dramatic one. **Watch for** students
marking a cut at the end of every line: that is the tennis match, on paper.

---

## Known correction: the Yearbook shutter handout

`week-5/handouts/shutter-speed.md` lists **`1/60` for panning a runner.** That is far too fast for a
walking subject and is why those pans had sharp backgrounds. **Correct range: `1/30`, `1/15`, `1/8`.**

That handout is already out to students, so it was **not** edited. Correct it verbally in Yearbook, or
repost it fixed.

---

## Standards come first now, everywhere

A standing rule went into `CLAUDE.md` this week and Tuesday's materials implement it:

- **Standards go first, before the agenda**, in their **exact text**, not numbers
- **Then the agenda**, with each activity named as serving one of them
- **Every student-facing career-tech worksheet carries its standards at the top**

Both new worksheets label every section with the competency it serves, so the slide and the paper agree.

---

## Where the week landed

**Monday ran.** DT logins worked, so **Plan A and Plan B both happen, in sequence**: variables Monday,
conditionals Tuesday, **photography from Wednesday** as the next unit rather than as a fallback. That
makes Friday's quiz simpler, since state and conditionals get two full days and the 16 state questions
are fair game with no alternate cut.

**Aviation pivoted to physics.** Unit 1.2 Aerodynamics opens Tuesday, and flight moves to Wednesday and
Thursday on two tracks.

**MS CS is on your own loops-and-lists lab.** The `lists-lab.md` and `starter-code-lists.md` here are
backup material.

**`POST-THIS.md`** lists what goes to each Classroom. **`SLIDE-PROMPTS/1-MONDAY-slides.md`** has all five
classes with board versions, including a separate Plan B set for DT.

**Career-tech classes open with standards**, written out in full, meant to stay on the board.

---

## Three things before first period

1. **Import the two Gimkit kits.** `1-design-techniques/gimkit-review.csv` (52) and
   `2-video-and-sound/gimkit-review.csv` (58). Already in Gimkit's column order. `gimkit-howto.md` has
   the import steps
2. **Pull the miss counts off Friday's Aviation and MS CS quizzes.** Both Monday lessons are built on
   real data, not a general review
3. **Do not post a DT handout yet.** The login test decides which one, and when

> **Retrieval first, game second.** In both DT and V&S, have them quiz themselves on the vocabulary
> before the Gimkit game. If the game comes first it is entertainment. If they have already found out
> what they do not know, the game is the second pass and it sticks.

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | **Review.** Test decides Tuesday | **Review.** Vocab, then Gimkit | Quiz review, **how to study** | Quiz review, **build a list together** | **Spirit week.** Cameras out |
| **Tue** | **Conditionals.** Last build day | **Watch everything, then color** | **PHYSICS:** forces, axes, motors | Loops and lists lab | Offload, then sign up for tonight |
| **Wed** | **PHOTOGRAPHY starts** | **How cuts happen.** J, L, on action | **FLIGHT**, two tracks. Then batteries | Loops and lists lab | Shoot, spreads |
| **Thu** | Photography: shoot and critique | Screening, features, or next project | **FLIGHT**, two tracks. Then logging | Apply it | Homecoming setup |
| **Fri** | **QUIZ**, submit | **QUIZ**, export | **BPA event choice** | Finish and show | **Photos + check-in DUE** |

---

## Tuesday at a glance

| Class | Tuesday |
|-------|---------|
| **DT** | Conditionals demo, then work. **Say out loud it is the last build day.** Photography starts Wednesday |
| **V&S** | **Every piece on screen 30 to 60 seconds**, watched for one question only, then color. New: `handouts/color-grading-lab.md` |
| **Aviation** | **Unit 1.2 opens.** Classroom, whole period. New: `handouts/forces-and-motors.md` |
| **MS CS** | Your loops-and-lists lab |
| **Yearbook** | Offload first, then spreads. Push sign-ups for tonight's games |

**Teacher only, for Wed and Thu:** `3-aviation-uas/handouts/flight-drills-two-tracks.md`.

---

## Video & Sound Tuesday: critique lenses, then color correction

**Set the expectation before anything plays.** That is the part that decides whether the screening is
worth doing. Put the five lenses up, explain the format, **then** ask for volunteers. If nobody offers,
pick a few. Watch a few, not all.

**The format:** every student gives **one thing that works and one thing that could be fixed**, per
piece. Not "did you like it."

| Lens | The question |
|---|---|
| **Continuity of look** | Same camera, same day, same room? |
| **Exposure** | Too dark to see, or blown to white? |
| **Color cast** | Anything tinted that should not be? **Look at white things** |
| **Consistency of cuts** | One thing, or clips stapled together? |
| **One good decision** | What do you want to steal? |

**Make them point at a moment.** "The shot of the hallway is bluer than the one before it" beats "it
looks off." Say before the first one plays: *being watched is not a punishment and it is not a reward.*

**The framing sentence for the whole day:**

> *Your piece should look like it was filmed continuously, with one camera, on the same settings, in the
> same light.*

It was not. That sentence tells them what finished looks like, which the word "correction" does not. The
follow-up: **the audience never thinks "the white balance shifted," they think "this feels cheap."**

**Then color. The order is not optional:** exposure, contrast, white balance, saturation. Students go
straight to saturation, which means saturating a cast instead of removing one. **White balance is the
step that earns the day.**

**Nothing is submitted Tuesday.** The corrected re-export is due Friday, with the earlier version
alongside it.

**A Lightroom fallback is written in** for later in the week: same skill on old RAW photos, easier to
see because nothing moves, concepts transfer exactly.

The rule: *if you can tell a shot has been graded, you went too far.*

**Why color is allowed when filters are banned**, worth saying out loud: a filter is a look applied
without a decision. Correction makes footage look like what your eye saw. Grading is a decision you can
explain. One is avoidance, the other two are craft.

**Standards are mapped to specific tools** in `2-video-and-sound/outline.md`, not to the software in
general: keyframes are 7.3.4, titles are 7.3.2, color is 7.3.5, effects and transitions are 7.7.6.

---

## Aviation Tuesday: the physics

**The hook, in the first thirty seconds:** *"You have flown these for two weeks. Nobody has told you
there is no steering."* True, surprising, and it earns the period.

Build it on the board in order: four forces as a free-body diagram, then lift two ways (Newton and
Bernoulli, **both correct, describing the same event**), then the motor layout. **Ask before explaining:
what would happen if all four spun the same way?** Let someone get to "it would spin" themselves. Then
torque cancels, then the table of what all four motors do for climb, pitch, roll and yaw.

**The two payoff sentences:**

- *"Forward flight is tilted lift. There is no separate thrust."* Explains the sink they have all felt
- *"Yaw is leftover torque."* Explains why yaw feels mushy compared to roll

**Have them draw.** Three free-body diagrams, an airfoil, and the motor layout, by hand. Watching you
draw it is not the same thing.

**Nothing needs printing.** `forces-worksheet.md` goes out as make-a-copy on Classroom; the drawings are
on paper, photographed and attached. **It spans Tuesday and Wednesday**, Parts 1 to 3 then 4 to 6, so
nobody runs out of work.

**Part 2 is addition and subtraction only.** A 1,000 g aircraft, four motors at 400 g each. 4 x 250 is a
hover, 4 x 300 climbs. Then add a 200 g camera and per-motor spare drops from 150 g to 100 g. **Teach
that as a safety idea, not an arithmetic one:** weight does not just slow you down, it eats the margin
you need to climb, fight wind, or recover from a mistake.

**Grade the explanations, not the numbers.** 1.5, 2.5, 3.3, 4.2, 5.3 and all of Part 6. Key is in
`forces-worksheet-key.md`.

**Already written:** `units/unit-1-2-aerodynamics/` has a lab, project, quiz and vocab for this unit
with Mavic 3 numbers. Pull from it rather than rebuilding, and clean the em dashes from anything you
carry forward.

---

## Flight Wed and Thu: two tracks

Assign by name, quietly, at the briefing. **One question off last week's log:** did the aircraft stop
turning at the crossover, or wander through it?

| | |
|---|---|
| **Track A** | Own the figure eight. Six steps that isolate the crossover |
| **Track B** | Maneuverability: nose-in circle, square with yaw, altitude changes, orbit on a target, precision landing |

**Do not announce them as levels.** A Track A pilot who gets it clean moves up the same day.

**The insight for Track A:** the problem is almost never the loops, it is the crossover, where the nose
changes which way it points and every input reverses. **Most pilots who cannot fly a figure eight can
fly step A3 fine**, which is the crossover alone.

**Connect it back to Tuesday in the moment**, ten seconds at a time. They sink pushing forward: *"where
did your lift go? You tilted it."* That is the week's real payoff and it only works on the field.

---

## Design Techniques: both plans, in sequence

**The logins worked.** So both happen, in order:

| | |
|---|---|
| **Mon to Tue** | State, variables, conditionals. Unit 1.4 closes Tuesday |
| **Wed to Thu** | **Q2 Unit 2.1 Photography.** Composition, light, cull and critique |
| **Fri** | Quiz on Unit 1.4, **including variables and conditionals.** Nothing from photography |

**Tell them Tuesday is the last build day.** After that the prototype is finished work.

**Post `photo-composition.md` Wednesday**, not Tuesday.

**No alternate quiz cut needed.** State and conditionals got two full days, so all 36 questions are in
play and the suggested cut is 9 state, 8 UX/UI, 3 typography.

---

## Video & Sound: the tool, then the craft

The framing worth saying out loud all week:

> **"You have been learning the tool. This week is the craft."**

Every technique this week works identically in Premiere, Resolve and Final Cut. **None of them are
CapCut features.** That stops the week reading as "more CapCut" and starts it reading as transferable.

**Tuesday is the best day of the week.** `handouts/how-cuts-happen.md`: straight cut, J-cut, L-cut,
cutaway, match cut, jump cut, cut on action. The two that will actually change their work:

- **J-cuts and L-cuts.** Unlink the audio, drag one edge past the other by half a second. This is the
  real answer to "why does professional dialogue feel smooth and mine does not." Say that, because they
  have all noticed the gap and assumed it was the camera
- **Cutting on action.** The easiest upgrade to any edit and almost nobody does it. Beginners cut when a
  shot "is done," which is exactly when the cut is most visible

**Make them log it:** timecode, technique, did it help. **"It made it worse" is a legitimate answer.**

**Wednesday: color order is exposure, contrast, white balance, saturation.** They will skip to
saturation. The rule: *if you can tell a shot has been graded, you went too far.* The line that keeps
the filter ban coherent: **correction makes footage look like what your eye saw; a filter is a look
applied without a decision.** Push **keyframes** out of the feature list, they transfer everywhere.

**Audio is deliberately about a minute this week.** Levels and room tone, nothing more. Unit 1.3 is ~16%
of the WebXam and deserves its own unit rather than a corner of an editing week.

**Thursday is loose on purpose.** Screening and next-project planning are both written. The screening is
the safer pick the week of a vocabulary quiz, because peer notes force the words into use.

---

## Two quizzes, both Friday

| Class | Bank | Gimkit | Cut to | Closes |
|-------|------|--------|--------|--------|
| Design Techniques | 36 | 52 | 20 | **Unit 1.4 UX/UI**, plus state if Plan A ran |
| Video & Sound | 34 | 58 | 20 | **Pre-production and editing basics** |

`option_a` is always correct in the quiz banks, so let the script shuffle.

> **V&S:** the bank has **both** 180 degree rules, shutter speed and camera placement. Unrelated
> concepts, same name. If your cut includes both, say so before the quiz.

**Both classes have a published study guide**, `2-video-and-sound/vocab.md` and
`3-aviation-uas/vocab.md`, each opening with how to study it, which is not by reading it.

---

## Aviation

**Monday's second half is a study skills lesson**, built on the real miss pattern: regulation numbers,
which cannot be reasoned to. **Do the four minute demo**: cover the nine number table, write them from
memory. Most get five or six, and the line is *so you have three things to learn, not nine.*

**The sentence:** *recognizing an answer when you see it is not the same as producing it when you do
not.* Taught as method, not as a lecture about effort.

**Wednesday is the day that matters.** Battery safety has real consequences. Have a pack in your hands.

**Sectionals move to the bell ringer**, one a day, Tue through Fri. They return as a tool in Unit 2.2.

**The hardware handout is generic.** Check failsafe, battery storage mode and firmware against the
aircraft actually in the room before Tuesday.

---

## Middle School CS

**Monday: review, then build together with about twenty minutes left.** They get working code with an
obvious flaw and the list is added as a class.

**The rule to state:** *any time you are about to copy code and change one number, something is wrong.*

**The sentence for the week:** *the index is not which one, it is how far from the start.*

**Let someone trigger the error on purpose** by asking for item 4 in a list of 4.

---

## Yearbook

**Check the sign-out sheet Monday and name who is not on it.** Cameras are limited, this is the busiest
week, and a student who waits until Friday has a genuine excuse, which is worse than no excuse.

**Both uploads:** eDesign and Classroom. They will do one and consider it done.

---

## Folders

```
INDEX.md                     this file
POST-THIS.md                 what to post, in priority order
gimkit-howto.md              import steps for the review kits
SLIDE-PROMPTS/               Mon, Tue, Wed, all five classes
1-design-techniques/         outline, quiz-bank.csv (36), gimkit-review.csv (52),
                             quiz.md, teacher-notes,
                             handouts/state-and-variables.md   (Mon-Tue)
                             handouts/photo-worksheet.md       (WED-FRI,
                                                   digital, make-a-copy)
                             handouts/photo-worksheet-key.md   (TEACHER ONLY)
                             handouts/photo-composition.md     (reference)
2-video-and-sound/           outline, quiz-bank.csv (34), gimkit-review.csv (58),
                             quiz.md, teacher-notes, vocab.md (the study guide),
                             handouts/color-grading-lab.md         (TUE)
                             project.md  (THE EDIT PROJECT, multi-day)
                             handouts/split-edits-lab.md           (WED)
                             handouts/cut-plan-and-storyboard.md   (THU-FRI)
                             handouts/footage-options-TEACHER.md   (TEACHER ONLY)
                             handouts/how-cuts-happen.md           (reference)
                             handouts/capcut-color-and-features.md (Thu, optional)
                             handouts/screening-and-peer-review.md (Thu, optional)
                             handouts/editing-depth-lab.md         (filler any day)
3-aviation-uas/              outline, teacher-notes, vocab.md,
                             handouts/how-to-study-this.md          (Mon)
                             handouts/forces-and-motors.md          (TUE, reading)
                             handouts/forces-worksheet.md           (TUE-WED,
                                                       digital, make-a-copy)
                             handouts/forces-worksheet-key.md       (TEACHER ONLY)
                             handouts/flight-drills-two-tracks.md   (Wed-Thu,
                                                       TEACHER ONLY)
                             handouts/aircraft-and-battery-safety.md (Wed-Thu)
                             handouts/bpa-event-choice.md           (Fri)
4-middle-school-cs/          outline, teacher-notes,
                             handouts/starter-code-lists.md (Mon, guided build)
                             handouts/lists-lab.md          (rest of the week)
5-yearbook/                  outline, teacher-notes,
                             handouts/spirit-week-shot-plan.md
still-in-use/                yearbook assignment due Friday, Aviation chart bell
                             ringers (teacher only), CapCut lab Levels 2 and 3
program/week-7-daily-log.md
grading-and-categories.md
```

`outline.md`, `project.md`, `vocab.md`, and `handouts/` are **student-facing.** `teacher-notes.md` and
`quiz.md` are **teacher-only**, as are the chart bell ringer file in `still-in-use/`,
`flight-drills-two-tracks.md`, `forces-worksheet-key.md`, `photo-worksheet-key.md`, and `footage-options-TEACHER.md`. The Gimkit CSVs are for you to import, not to post.
