# Week 7 Materials: Mon Sep 28 to Fri Oct 2

---

## Monday is a review day in four of five classes

DT and V&S review **for** Friday. Aviation and MS CS review **from** last Friday. That was not planned as
a theme, but it is a reasonable shape for the Monday of a quiz week.

**`POST-THIS.md`** lists what goes to each Classroom. **`SLIDE-PROMPTS/1-MONDAY-slides.md`** has all five
classes with board versions, including a separate Plan B set for DT.

**Career-tech classes open with standards**, written out in full, meant to stay on the board.

---

## Three things before first period

1. **Import the two Gimkit kits.** `1-design-techniques/gimkit-review.csv` (52) and
   `2-video-and-sound/gimkit-review.csv` (58). Already in Gimkit's column order. `gimkit-howto.md` has
   the import steps
2. **Pull the miss counts off Friday's Aviation and MS CS quizzes.** Both Monday lessons are built on
   real data, not a general review
3. **Do not post a DT handout yet.** The login test decides which one, and when

> **Retrieval first, game second.** In both DT and V&S, have them quiz themselves on the vocabulary
> before the Gimkit game. If the game comes first it is entertainment. If they have already found out
> what they do not know, the game is the second pass and it sticks.

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | **Review.** Test decides Tuesday | **Review.** Vocab, then Gimkit | Quiz review, **how to study** | Quiz review, **build a list together** | **Spirit week.** Cameras out |
| **Tue** | Variables, or photography starts | **How cuts happen.** J, L, on action | Components | Your own list | People not in the book yet |
| **Wed** | Read it: bound text | **Color**, and untouched features | **Batteries** | **Length and index** | Something being done |
| **Thu** | Polish, test, write-up | Screening and/or next project | Preflight, logging, **vocab** | Apply it | Homecoming setup |
| **Fri** | **QUIZ**, submit | **QUIZ**, export | **BPA event choice** | Finish and show | **Photos + check-in DUE** |

---

## Design Techniques: the test decides Tuesday, not Monday

**Monday is review either way.** First ten minutes, two or three students log in and open the Figma
Variables panel while the rest settle. Then everyone reviews.

| Test result | Rest of Monday | Tuesday onward |
|---|---|---|
| Panel is there | Demo variables, they find the state in their own file | **Plan A.** Build it out |
| Missing, greyed out, logins fail | **Keep reviewing.** More Gimkit, or UX/UI vocabulary | **Plan B.** Photography starts Tuesday |

**The risk is contained to one class period.** If the logins fail, Monday was still a useful review
before Friday's quiz rather than a wasted one.

**Ten minutes on the test, then move.** Do not troubleshoot for a period.

**If it fails, one sentence:** *"We are done with this unit. It is finished work and it is on your
portfolio. Tomorrow we start photography."* **Do not narrate the licensing problem to students.**

**Plan B is the next unit on the map** (Q2 2.1 Photography), so the pivot costs nothing in sequence and
depends on nothing working. Phones are fine, and spirit week means there is something to photograph in
every hallway.

**The quiz works either way with no second bank.** The 16 state questions are rows 2 to 17, so they lift
out in one selection, and what remains is exactly 20.

---

## Video & Sound: the tool, then the craft

The framing worth saying out loud all week:

> **"You have been learning the tool. This week is the craft."**

Every technique this week works identically in Premiere, Resolve and Final Cut. **None of them are
CapCut features.** That stops the week reading as "more CapCut" and starts it reading as transferable.

**Tuesday is the best day of the week.** `handouts/how-cuts-happen.md`: straight cut, J-cut, L-cut,
cutaway, match cut, jump cut, cut on action. The two that will actually change their work:

- **J-cuts and L-cuts.** Unlink the audio, drag one edge past the other by half a second. This is the
  real answer to "why does professional dialogue feel smooth and mine does not." Say that, because they
  have all noticed the gap and assumed it was the camera
- **Cutting on action.** The easiest upgrade to any edit and almost nobody does it. Beginners cut when a
  shot "is done," which is exactly when the cut is most visible

**Make them log it:** timecode, technique, did it help. **"It made it worse" is a legitimate answer.**

**Wednesday: color order is exposure, contrast, white balance, saturation.** They will skip to
saturation. The rule: *if you can tell a shot has been graded, you went too far.* The line that keeps
the filter ban coherent: **correction makes footage look like what your eye saw; a filter is a look
applied without a decision.** Push **keyframes** out of the feature list, they transfer everywhere.

**Audio is deliberately about a minute this week.** Levels and room tone, nothing more. Unit 1.3 is ~16%
of the WebXam and deserves its own unit rather than a corner of an editing week.

**Thursday is loose on purpose.** Screening and next-project planning are both written. The screening is
the safer pick the week of a vocabulary quiz, because peer notes force the words into use.

---

## Two quizzes, both Friday

| Class | Bank | Gimkit | Cut to | Closes |
|-------|------|--------|--------|--------|
| Design Techniques | 36 | 52 | 20 | **Unit 1.4 UX/UI**, plus state if Plan A ran |
| Video & Sound | 34 | 58 | 20 | **Pre-production and editing basics** |

`option_a` is always correct in the quiz banks, so let the script shuffle.

> **V&S:** the bank has **both** 180 degree rules, shutter speed and camera placement. Unrelated
> concepts, same name. If your cut includes both, say so before the quiz.

**Both classes have a published study guide**, `2-video-and-sound/vocab.md` and
`3-aviation-uas/vocab.md`, each opening with how to study it, which is not by reading it.

---

## Aviation

**Monday's second half is a study skills lesson**, built on the real miss pattern: regulation numbers,
which cannot be reasoned to. **Do the four minute demo**: cover the nine number table, write them from
memory. Most get five or six, and the line is *so you have three things to learn, not nine.*

**The sentence:** *recognizing an answer when you see it is not the same as producing it when you do
not.* Taught as method, not as a lecture about effort.

**Wednesday is the day that matters.** Battery safety has real consequences. Have a pack in your hands.

**Sectionals move to the bell ringer**, one a day, Tue through Fri. They return as a tool in Unit 2.2.

**The hardware handout is generic.** Check failsafe, battery storage mode and firmware against the
aircraft actually in the room before Tuesday.

---

## Middle School CS

**Monday: review, then build together with about twenty minutes left.** They get working code with an
obvious flaw and the list is added as a class.

**The rule to state:** *any time you are about to copy code and change one number, something is wrong.*

**The sentence for the week:** *the index is not which one, it is how far from the start.*

**Let someone trigger the error on purpose** by asking for item 4 in a list of 4.

---

## Yearbook

**Check the sign-out sheet Monday and name who is not on it.** Cameras are limited, this is the busiest
week, and a student who waits until Friday has a genuine excuse, which is worse than no excuse.

**Both uploads:** eDesign and Classroom. They will do one and consider it done.

---

## Folders

```
INDEX.md                     this file
POST-THIS.md                 what to post, in priority order
gimkit-howto.md              import steps for the review kits
SLIDE-PROMPTS/               Monday, all five classes, DT with both plans
1-design-techniques/         outline, quiz-bank.csv (36), gimkit-review.csv (52),
                             quiz.md, teacher-notes,
                             handouts/state-and-variables.md   (PLAN A, Monday)
                             handouts/photo-composition.md     (PLAN B, Tuesday)
2-video-and-sound/           outline, quiz-bank.csv (34), gimkit-review.csv (58),
                             quiz.md, teacher-notes, vocab.md (the study guide),
                             handouts/how-cuts-happen.md          (Tue)
                             handouts/capcut-color-and-features.md (Wed)
                             handouts/screening-and-peer-review.md (Thu, optional)
                             handouts/editing-depth-lab.md         (filler any day)
3-aviation-uas/              outline, teacher-notes, vocab.md,
                             handouts/how-to-study-this.md         (Mon)
                             handouts/aircraft-and-battery-safety.md (Tue-Thu)
                             handouts/bpa-event-choice.md          (Fri)
4-middle-school-cs/          outline, teacher-notes,
                             handouts/starter-code-lists.md (Mon, guided build)
                             handouts/lists-lab.md          (rest of the week)
5-yearbook/                  outline, teacher-notes,
                             handouts/spirit-week-shot-plan.md
still-in-use/                yearbook assignment due Friday, Aviation chart bell
                             ringers (teacher only), CapCut lab Levels 2 and 3
program/week-7-daily-log.md
grading-and-categories.md
```

`outline.md`, `project.md`, `vocab.md`, and `handouts/` are **student-facing.** `teacher-notes.md` and
`quiz.md` are **teacher-only**, as is the chart bell ringer file in `still-in-use/`. The Gimkit CSVs are
for you to import, not to post.
