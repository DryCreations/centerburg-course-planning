# Week 7 Materials: Mon Sep 28 to Fri Oct 2

---

## Start here

**`POST-THIS.md`** lists what goes to each Classroom, with a short list for Monday.

**`SLIDE-PROMPTS/1-MONDAY-slides.md`** has all five classes, one prompt per slide, with board versions.
**Design Techniques has two full slide sets in there**, Plan A and Plan B.

**Career-tech classes open with standards**, written out in full, meant to stay on the board.

---

## Three things before first period Monday

1. **Design Techniques is a decision, not a lesson.** Student logins on the upgraded Figma plan cannot
   be verified until a student is in there. **Have two or three log in and open the Variables panel
   before you teach anything.** Panel there means Plan A. Missing or logins fail means Plan B, and you
   say one sentence and move on
2. **Pull the miss counts off Friday's Aviation and MS CS quizzes.** Both Monday lessons are built on
   real data, not a general review
3. **Do not post a DT handout until the test is done.** Post `state-and-variables.md` or
   `photo-composition.md`, never both

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | **Login test.** Then state, or Plan B | **Cut 20% out** | Quiz review, **how to study** | Quiz review, **build a list together** | **Spirit week.** Cameras out |
| **Tue** | Wire it: change the value | **Screening and peer review** | Components | Your own list | People not in the book yet |
| **Wed** | Read it: bound text | **Color and audio** | **Batteries** | **Length and index** | Something being done |
| **Thu** | Polish, test, write-up | **Vocab**, then plan the next shoot | Preflight, logging, **vocab** | Apply it | Homecoming setup |
| **Fri** | **QUIZ**, submit | **QUIZ**, export | **BPA event choice** | Finish and show | **Photos + check-in DUE** |

---

## Design Techniques has two plans

| | |
|---|---|
| **Plan A** | State and variables. Extend the existing prototype. `handouts/state-and-variables.md` |
| **Plan B** | Close Unit 1.4, open **Q2 Unit 2.1 Photography**. `handouts/photo-composition.md` |

**Plan B is the next unit on the map**, so the pivot costs nothing in sequence, and it depends on nothing
working: phones are fine, and spirit week means there is something to photograph in every hallway.

**The quiz works either way with no new bank.** Plan A cuts 9 state + 8 UX/UI + 3 typography. **Plan B
skips the 16 state questions and what remains is exactly 20.** The bank is ordered so the state block
lifts out in one selection.

> **Do not narrate the licensing problem to students.** It is not their problem and it makes the pivot
> read as a failure rather than a plan.

---

## Two quizzes, both Friday

| Class | Bank | Cut to | Closes |
|-------|------|--------|--------|
| Design Techniques | 36 | 20 | **Unit 1.4 UX/UI**, plus state if Plan A ran |
| Video & Sound | 34 | 20 | **Pre-production and editing basics** |

Plain CSV, no images, nothing coupled. `option_a` is always correct, so let the script shuffle.

> **V&S:** the bank has **both** 180 degree rules, shutter speed and camera placement. Unrelated
> concepts, same name. If your cut includes both, say so before the quiz.

**Both classes have a published study guide.** `2-video-and-sound/vocab.md` and
`3-aviation-uas/vocab.md` are comprehensive, and both open with how to study them, which is not by
reading them.

---

## Notes per class

### Design Techniques

**Plan A: Monday is diagnostic, not instructional.** Do not open with the Variables panel. Open by having
them find two nearly identical frames in their own file and name the one thing that differs.

**The sentence:** *duplicating a screen is how you fake a change you cannot build yet.*

**Deleting frames is the deliverable.** Ask at every desk Wednesday: how many frames did this delete?

**Where it breaks:** the interaction lands on the frame or the text instead of the button. Most of the
support requests, and it fails silently, so walk the room Tuesday.

**Plan B: Thursday's photo critique reuses last week's feedback training.** Same rule: name what is in
the frame, not whether you liked it. Say the transfer out loud.

### Video & Sound

**Monday's 20% cut is non-negotiable and that is the entire pedagogy.** You cannot cut a fifth by
trimming frames. They keep both versions and submit both.

**Tuesday's screening: the editor says nothing first.** Once they explain the shot, nobody can tell them
whether it read on its own, which is the only thing worth knowing. Four or five cuts done properly beats
twelve rushed.

**The screening sits next to the vocab day on purpose.** Peer notes are live quiz rehearsal: "it felt
weird" gets sent back, "the cut at 0:14 is a jump cut" is the standard.

**Wednesday: color order is exposure, contrast, white balance, saturation.** Students skip to saturation
because it is the most visible slider. The rule: *if you can tell a shot has been graded, you went too
far.* The assignment is concrete, match two shots that do not match, because "explore color" produces
purple footage.

**Thursday, second half: start the next project's pre-production.** They have just felt what bad coverage
costs in the edit, and that is the only moment pre-production is ever persuasive. *Every problem you hit
this week was created two weeks ago, on the shoot.*

### Aviation UAS

**Monday's second half is a study skills lesson**, built on the actual miss pattern: regulation numbers,
which cannot be reasoned to. **Do the four minute demo in class**, covering the nine number table and
writing them from memory. Most will get five or six, and the line is: *so you have three things to
learn, not nine.*

**The sentence:** *recognizing an answer when you see it is not the same as producing it when you do
not.*

**Taught as a method, not a lecture about effort.** The handout is written that way deliberately.

**Wednesday is the day that matters.** Battery safety has real consequences. Have a pack in your hands.

**Sectionals move to the bell ringer**, one a day, Tue through Fri. They return as a tool in Unit 2.2.

**The hardware handout is generic.** Check failsafe, battery storage mode, and firmware against the
aircraft actually in the room before Tuesday.

### Middle School CS

**Monday: review, then build together with about twenty minutes left.** They get working code with an
obvious flaw and the list is added as a class.

**The rule to state:** *any time you are about to copy code and change one number, something is wrong.*

**The one sentence for the week:** *the index is not which one, it is how far from the start.*

**Let someone trigger the error on purpose** by asking for item 4 in a list of 4. A deliberately
triggered error beats a warning about one.

### Yearbook

**Check the sign-out sheet Monday and name who is not on it.** Cameras are limited, this is the busiest
week, and a student who waits until Friday has a genuine excuse, which is worse than no excuse.

**Both uploads:** eDesign and Classroom. They will do one and consider it done.

---

## Folders

```
INDEX.md                     this file
POST-THIS.md                 what to post, in priority order
SLIDE-PROMPTS/               Monday, all five classes, DT with both plans
1-design-techniques/         outline, quiz-bank.csv (36), quiz.md, teacher-notes,
                             handouts/state-and-variables.md   (PLAN A)
                             handouts/photo-composition.md     (PLAN B)
2-video-and-sound/           outline, quiz-bank.csv (34), quiz.md, teacher-notes,
                             vocab.md (the study guide),
                             handouts/editing-depth-lab.md,
                             handouts/screening-and-peer-review.md,
                             handouts/capcut-color-and-features.md
3-aviation-uas/              outline, teacher-notes, vocab.md (the study list),
                             handouts/how-to-study-this.md,
                             handouts/aircraft-and-battery-safety.md,
                             handouts/bpa-event-choice.md
4-middle-school-cs/          outline, teacher-notes,
                             handouts/starter-code-lists.md (Monday),
                             handouts/lists-lab.md (the rest of the week)
5-yearbook/                  outline, teacher-notes,
                             handouts/spirit-week-shot-plan.md
still-in-use/                yearbook assignment due Friday, Aviation chart
                             bell ringers (teacher only), and the CapCut lab
                             whose Levels 2 and 3 are still live
program/week-7-daily-log.md
grading-and-categories.md
```

`outline.md`, `project.md`, `vocab.md`, and `handouts/` are **student-facing.** `teacher-notes.md` and
`quiz.md` are **teacher-only**, as is the chart bell ringer file in `still-in-use/`.
