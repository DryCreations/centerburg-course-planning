# Week 7 Materials: Mon Sep 28 to Fri Oct 2

---

## Start here

**`POST-THIS.md`** lists what goes to each Classroom, with a short list for Monday.

**`SLIDE-PROMPTS/1-MONDAY-slides.md`** has all five classes for Monday, one prompt per slide, with board
versions for running without a projector.

**Career-tech classes open with standards**, written out in full, meant to stay on the board.

---

## Two things to do before first period Monday

1. **Pull the miss counts off Friday's Aviation and MS CS quizzes.** Both Monday lessons are built
   around the questions the class actually got wrong, not a general review
2. **Open the Figma Variables panel yourself** and confirm it is there. Education approval came through,
   but confirm rather than assume

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | Find the state | **Cut 20% out** | **Quiz review**, new unit | **Quiz review**, what a list is | **Spirit week.** Cameras out |
| **Tue** | Wire it: change the value | Cutaways | Components | Make a list | People not in the book yet |
| **Wed** | Read it: bound text | **Audio:** levels, room tone | **Batteries** | **Length and index** | Something being done |
| **Thu** | Polish, test, write-up | Titles and finish | Preflight, logging | Apply it | Homecoming setup |
| **Fri** | **QUIZ**, submit | **QUIZ**, export | **BPA event choice** | Finish and show | **Photos + check-in DUE** |

---

## Two quizzes, both Friday

| Class | Bank | Cut to | Closes |
|-------|------|--------|--------|
| Design Techniques | 36 | 20 | **Unit 1.4 UX/UI**, plus this week's state and variables |
| Video & Sound | 34 | 20 | **Pre-production and editing basics** |

Plain CSV, no images, nothing coupled. `option_a` is always correct, so let the script shuffle.

> **V&S:** the bank has **both** 180 degree rules, shutter speed and camera placement. Unrelated
> concepts with the same name. If your cut includes both, say so before the quiz.

---

## Notes per class

### Design Techniques

**Monday is diagnostic, not instructional.** Do not open with the Variables panel. Open by having them
find two nearly identical frames in their own file and name the one thing that differs. That sorts the
class for you and it is the actual lesson.

**The sentence:** *duplicating a screen is how you fake a change you cannot build yet.*

**Deleting frames is the deliverable.** Students will build the variable and leave the old frames in
place, which means they have added work rather than replaced it. Ask at every desk Wednesday: how many
frames did this delete?

**Where it breaks:** the interaction lands on the frame or the text instead of the button. That is most
of the support requests, and the failure is silent, so walk the room Tuesday.

### Video & Sound

**The 20% cut is non-negotiable and that is the entire pedagogy.** If it is optional, nobody does it.
Expect pushback; the answer is that you cannot cut a fifth by trimming frames, you have to remove
something you liked.

**Make them keep both versions.** Watching them back to back and realizing nothing was lost is the
moment it lands.

**Tuesday's cutaway is the highest-value trick in the course.** It is also the argument for shooting
B-roll that no amount of telling them ever wins.

**Wednesday will be the weakest day.** Do the demo: a clip with mismatched levels, then fixed, on the
room speakers. Thirty seconds and it is settled.

### Aviation UAS

**Wednesday is the day that matters.** Battery safety has real consequences. Have a pack in your hands,
not a slide deck.

**Sectionals move to the bell ringer**, one a day, Tue through Fri. That is the plan, not a consolation:
charts reward spaced repetition, and they come back as a tool rather than a topic in Unit 2.2.

**The hardware handout is generic.** Check failsafe behavior, battery storage mode, and firmware process
against the aircraft actually in the room before Tuesday.

**BPA choice is due end of Week 9**, first asked Friday. Say the real structure out loud: if they pick
#505, the Unit 4.3 capstone IS the entry.

### Middle School CS

**The one sentence for the week:** *the index is not which one, it is how far from the start.* Students
who memorize "lists start at zero" get it wrong under pressure. Students who understand why do not.

**Wednesday, let someone trigger the error on purpose** by asking for item 4 in a list of 4. A
deliberately triggered error beats a warning about one.

**Thursday is one option out of four, steered by ability.** Struggling goes to the sprite army, strong
goes to shuffle. The four options are deliberately different difficulties.

### Yearbook

**Check the sign-out sheet Monday and name who is not on it.** Cameras are limited, this is the busiest
week, and a student who waits until Friday has a genuine excuse, which is worse than no excuse.

**Both uploads:** eDesign and Classroom. They will do one and consider it done.

---

## Folders

```
INDEX.md                     this file
POST-THIS.md                 what to post, in priority order
SLIDE-PROMPTS/               Monday, all five classes
1-design-techniques/         outline, quiz-bank.csv (36), quiz.md, teacher-notes,
                             handouts/state-and-variables.md
2-video-and-sound/           outline, quiz-bank.csv (34), quiz.md, teacher-notes,
                             handouts/editing-depth-lab.md
3-aviation-uas/              outline, teacher-notes,
                             handouts/aircraft-and-battery-safety.md,
                             handouts/bpa-event-choice.md
4-middle-school-cs/          outline, teacher-notes, handouts/lists-lab.md
5-yearbook/                  outline, teacher-notes,
                             handouts/spirit-week-shot-plan.md
still-in-use/                the yearbook assignment due Friday, and the
                             Aviation chart bell ringers (teacher only)
program/week-7-daily-log.md
grading-and-categories.md
```

`outline.md`, `project.md`, and `handouts/` are **student-facing.** `teacher-notes.md` and `quiz.md` are
**teacher-only**, as is the chart bell ringer file in `still-in-use/`.

> **Still live from Week 6:** the Yearbook photo assignment, **due this Friday**, and the Aviation
> coordinate bell ringers, which now run daily. Both are in `still-in-use/`.
