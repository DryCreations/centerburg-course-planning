# Week 3 Materials (Aug 31 to Sep 4)

Everything for Week 3, one folder per class, in the order they appear in the day.

| Folder | What is in it |
|--------|---------------|
| `1-design-techniques/` | Outline, poster project, vocab, quiz, Gimkit bank, teacher notes, daily slide prompts (tue/wed/thu/fri), handouts |
| `2-video-and-sound/` | Same structure: RAW and editing project, vocab, quiz, Gimkit bank, slides, handouts |
| `3-aviation-uas/` | Mission project, vocab, Gimkit bank, **gimkit-rainout-backup.csv**, slides, handouts (mission plan, preflight, controller practice) |
| `4-middle-school-cs/` | Decision Game project, Gimkit bank, slides, handouts (bell ringers, **makecode-screenshot-blocks.md**) |
| `5-yearbook/` | Frames-first project, Gimkit bank, slides, handouts (**page-checklist-module.md**) |
| `quizzes-friday/` | The three 30-question quiz CSVs (Design Techniques, Video and Sound, Middle School CS) plus a README |
| `program/` | Daily log and the cross-class actions and slide-prompt sheets |
| `grading-and-categories.md` | Gradebook categories and weights for PowerTeacher and Google Classroom |

## Quick notes

- Slide files are named `tuesday-slides.md`, `wednesday-...`, `thursday-slides.md`, `friday-slides.md`. Each
  holds **one copy-paste prompt per slide** for Google Slides AI.
- Gimkit CSVs import directly: columns are Question, Correct Answer, Incorrect 1, 2, 3, with the correct answer
  always in column 2.
- Quiz CSVs use the same schema as the pretests, so the existing Apps Script imports them. `option_a` is always
  the correct answer.
- **Friday:** Design Techniques and Video and Sound quiz. Middle School CS is a Gimkit review only. Aviation
  flies, or runs the rain-out backup bank. Yearbook is a one-slide weekly check-in against the exemplar.
