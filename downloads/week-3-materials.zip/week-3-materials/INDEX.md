# Week 3 Materials (Aug 31 to Sep 4)

Everything for Week 3, one folder per class.

| Folder | What is in it |
|--------|---------------|
| `1-design-techniques/` | Outline, poster project, vocab, quiz, Gimkit bank, teacher notes, daily slide prompts, handouts |
| `2-video-and-sound/` | RAW and editing project, vocab, quiz, Gimkit bank, slides, handouts |
| `3-aviation-uas/` | Mission project, vocab, Gimkit bank, **gimkit-rainout-backup.csv**, slides, handouts |
| `4-middle-school-cs/` | Decision Game project, Gimkit bank, slides, handouts (bell ringers, **makecode-screenshot-blocks.md**) |
| `5-yearbook/` | Frames-first project, Gimkit bank, slides, handouts (**page-checklist-module.md**) |
| `quizzes-friday/` | Three 30-question quiz CSVs plus a README |
| `program/` | Daily log and cross-class action and slide-prompt sheets |
| `grading-and-categories.md` | Gradebook categories and weights |

## Question banks

All Gimkit and quiz questions are **content, standards and vocabulary only**. Nothing asks about the software
we use, how to submit work, or class logistics, so everything maps to material that could appear on the WebXam.

- Gimkit CSVs import directly: Question, Correct Answer, Incorrect 1, 2, 3, correct answer always column 2.
- Quiz CSVs use the pretest schema, so the existing Apps Script imports them. `option_a` is always correct.

## Friday

Design Techniques and Video and Sound quiz. Middle School CS is a Gimkit review only. Aviation flies, or runs
the rain-out backup bank. Yearbook is a one-slide weekly check-in.
