# Week 4 Materials (Wed Sep 9 to Fri Sep 11)

**Three day week.** Labor Day Monday, professional development Tuesday. Everything for the week is in here.

## How this folder is structured

```
week-4-materials/
    INDEX.md                     <- you are here
    SLIDE-PROMPTS/               <- START HERE, one file per day, all five classes
        1-WEDNESDAY-slides.md
        2-THURSDAY-slides.md
        3-FRIDAY-slides.md
    1-design-techniques/
    2-video-and-sound/
    3-aviation-uas/              <- METAR scavenger hunt + quiz-bank.csv (40 Q)
    4-middle-school-cs/          <- tile map guide + quiz-bank.csv (30 Q)
    5-yearbook/
    program/week-4-daily-log.md
    grading-and-categories.md
```

## Using the slide prompts

Every block in a SLIDE-PROMPTS file is **one prompt for one slide.** Paste it into Google Slides AI to
generate that slide. These are prompts, not finished slides.

Every deck follows the same skeleton: **As You Come In, Standards + Today, content, Do Now, Turn and Talk,
If You Finish Early, Before You Leave.** One focus per class per day; anything unfinished carries into next week.

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Wed** | Portfolio catch-up | Read a real BPA prompt, pre-production | **METAR scavenger hunt**, then lock the plan | **Tile maps:** maze, walls, collision | Aperture + shoot |
| **Thu** | UX vs UI, user journey | Pick idea, shot list | **FLIGHT DAY** | **Variables:** count items, win condition | Work time |
| **Fri** | Start wireframes + retake | Start storyboards + retake | **QUIZ**, then footage debrief | **QUIZ**, then maze work | Aperture pair due |

## Friday has three assessments

- **DT and V&S:** optional **independent retake** of last week's quiz, taken during work time. The retake score
  **replaces** the original. One time only.
- **Aviation:** **first quiz of the year**, whole class, silent. Weeks 1 to 4. Bank is
  `3-aviation-uas/quiz-bank.csv`, **40 questions, cut to your best 20**. Keep the `AV-S1` METAR scenario set.
- **Middle School CS:** **first quiz**, whole class, silent. If statements and everything before, **not** tile
  maps. Bank is `4-middle-school-cs/quiz-bank.csv`, 30 questions cut to 20.

Both quiz banks use the same schema as the pretests, so the existing Apps Script imports them directly
(`option_a` is always correct, `answer` is always A). Turn on shuffle after import.

## Things to bring

- **Wed, Video & Sound:** an actual past BPA Video Production Team (#430) prompt. The handout has the
  discussion structure but no prompt text, so students read the real thing.
- **Wed, Aviation:** laptops for aviationweather.gov, and the closest reporting station identifier to give
  students as their "home field" for the scavenger hunt.
- **Thu, Aviation:** charged battery, the case, cleared card, flight logs. If it is a no-go, run the Week 3
  rain-out Gimkit bank as quiz review and reschedule.

## Middle School CS this week

Loops are dropped; **tile maps** replace them. Students start a **brand new project** and build the Maze
Collector: draw a maze, mark walls, move with collision (Wed), then count collected items with a variable and
an if (Thu). Guide: `4-middle-school-cs/handouts/tilemap-maze-guide.md`.

## Carrying into next week

DT wireframes, V&S storyboards, the MS CS Maze Collector lab, and loops (still to be taught).
