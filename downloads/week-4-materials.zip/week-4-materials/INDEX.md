# Week 4 Materials: Wed Sep 9 to Fri Sep 11

**Three day week.** Labor Day Monday, professional development Tuesday.

---

## Start here

`SLIDE-PROMPTS/` has one file per day, all five classes in each. Every block is one prompt for one slide,
written to paste into Google Slides AI.

`program/week-4-daily-log.md` is the week at a glance plus what changed and why.

**Slide counts are deliberately lean.** A class doing one thing gets one slide.

| Class | Wed | Thu | Fri |
|-------|-----|-----|-----|
| Design Techniques | 11 | 9 | 7 |
| Video & Sound | 9 | 5 | 8 |
| Aviation UAS | 9 | 2 | 7 |
| Middle School CS | 10 | 5 | 5 |
| Yearbook | 8 | 1 | 7 |

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Wed** | Portfolio catch-up, restructure the menu | Read a BPA prompt, intro preproduction, brainstorm | METAR scavenger hunt on aviationweather.gov | Tile maps: maze, walls, collision | Aperture explainer, work time |
| **Thu** | UX/UI vocab, then into Figma, build the player screen | Script / storyboard / shot list, then write yours | **FLIGHT DAY** | Bell ringer, then build the counter and win live | Aperture pair or spreads |
| **Fri** | **Retake first**, then connect it into a prototype | Storyboards + retake | **QUIZ**, then footage debrief | **QUIZ**, then maze work | Aperture pair due |

---

## Thursday and Friday: Design Techniques is a Figma intro

**Low stakes on purpose. Graded in Labs, on completion.**

Everyone builds the **same music player phone screen from a written spec**, then makes a second version and
connects them so the play button clicks through. Copying a spec is the point: there are no design decisions
to stall on, so all the effort goes into tool fluency, and "did I match it?" is a self-check students can
apply without you.

Everything is in **`1-design-techniques/handouts/figma-intro-build.md`**, written so an absent student can
catch up start to finish on their own: sign-in steps, a tour of the four panels, the five tools, exact
`X`/`Y`/`W`/`H` numbers and hex codes for every element, the prototyping steps, a "Stuck?" table, and finish-
early extensions. The last section is a **teacher note with an AI image prompt** for generating the reference
picture to put on the Do Now slide.

**Run it as:** build alongside them on the projector, one step at a time. Step, wait, look around, next step.
Do not demo the whole thing and set them loose.

**Friday's retake opens the second class starts.** The prototyping work is self-paced and independent, so
retakers rejoin whenever they finish. Nothing is time-gated.

**Next week** is the real design work: pick a screen that frustrates you and redesign it. That material is
already written (`1-design-techniques/handouts/thu-teardown-and-setup.md`), and Thursday's bell ringer seeds
it.

---

## Friday has three assessments

- **DT and V&S:** optional independent **retake** of last week's quiz. The retake score **replaces** the
  original, one time only.
- **Aviation:** **first quiz of the year.** 40 questions in `3-aviation-uas/quiz-bank.csv`, cut to the best 20.
  Keep the `AV-S1` scenario set together (four questions off one METAR ending in a go/no-go call).
- **MS CS:** **first quiz.** 30 questions in `4-middle-school-cs/quiz-bank.csv`, cut to 20. **If statements
  and everything before. NOT tile maps.**

---

## Bring / set up

| Day | What |
|-----|------|
| Wed | Fill in your home-field identifier at the top of the METAR scavenger hunt (KCMH or KOSU are reliable) |
| Thu | Aviation: the case, a charged battery, a cleared card, flight logs. DT: generate the reference image ahead of time if you want it on the slide |
| Fri | Both quizzes built and posted, and the DT retake open at the bell |

**Figma note:** free Starter accounts are enough (unlimited drafts, real frames, real prototyping). Do not
make Thursday depend on Figma for Education, that verification can take days. Apply in the background.

---

## Folders

```
INDEX.md                     this file
SLIDE-PROMPTS/               one file per day, all five classes
1-design-techniques/         + handouts/figma-intro-build.md  <- Thu and Fri live here
2-video-and-sound/           + handouts/thu-preproduction-terms.md
3-aviation-uas/              + quiz-bank.csv, quiz.md
4-middle-school-cs/          + quiz-bank.csv, bell-ringer-thu.md, thu-live-build-script.md
5-yearbook/
program/week-4-daily-log.md
grading-and-categories.md
```

`outline.md`, `project.md`, `vocab.md`, and `handouts/` are **student-facing.** `teacher-notes.md` and
`quiz.md` are **teacher-only.**

---

## Carrying into next week

- **DT:** the Redesign Project, using the tool they just learned
- **V&S:** storyboards, then into production
- **MS CS:** the Maze Collector lab, plus loops still to be taught
- **Aviation:** footage critique, and the flight if weather scrubbed Thursday
