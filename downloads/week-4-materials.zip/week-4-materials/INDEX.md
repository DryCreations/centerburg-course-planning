# Week 4 Materials (Tue Sep 8 to Fri Sep 11)

Four day week, Labor Day Monday off.

## Start here

**`SLIDE-PROMPTS-tuesday.md`** is the one you want first. It has today's slide prompts for all five classes.
Every block is one prompt for one slide: paste it into Google Slides AI to generate that slide.

Every deck follows the same skeleton: As You Come In, Standards + Today, content slides, Do Now, Before You
Leave.

| Folder | What is in it |
|--------|---------------|
| `1-design-techniques/` | Portfolio review + UX/UI wireframing unit. `handouts/tue-portfolio-update.md` has the portfolio checklist, the year-long menu structure, and the model write-up. |
| `2-video-and-sound/` | BPA prompt reading + pre-production. `handouts/tue-bpa-prompt-read.md` has the discussion structure. |
| `3-aviation-uas/` | Footage review, weather, Mission retry. `handouts/metar-resources.md` has the real METAR references. |
| `4-middle-school-cs/` | Loops unit, plus `quiz-bank.csv` (30 questions, cut to 20) for Friday's quiz. |
| `5-yearbook/` | Aperture practice set, mostly work time. |
| `program/` | The daily log. |
| `grading-and-categories.md` | Gradebook categories and weights. |

## This week at a glance

| Class | Tuesday | Key note |
|-------|---------|----------|
| Design Techniques | Portfolio checklist, menu restructure, post + describe poster | UX/UI starts Wednesday, may run into next week |
| Video & Sound | Read a real BPA prompt, react, intro pre-production | Bring an actual past #430 prompt |
| Aviation UAS | Footage review, real METAR, new roles | **Flight is Thursday**, not Friday |
| Middle School CS | Loops (new content) | **Quiz is Friday**, if statements only, not loops |
| Yearbook | Aperture explainer + quick shoot | **No check-in this week**, next is Week 6 |

## Two things to bring

- **Video & Sound:** an actual past BPA Video Production Team (#430) prompt. The handout has the discussion
  structure but not a prompt text, so students read the real thing.
- **Aviation:** last week's flight footage, and a real current METAR pulled from aviationweather.gov.
