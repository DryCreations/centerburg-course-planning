# Week 4 Materials (Wed Sep 9 to Fri Sep 11)

**Three day week.** Labor Day Monday, professional development Tuesday. Everything for the week is in here.

## How this folder is structured

```
week-4-materials/
    INDEX.md                     <- you are here
    SLIDE-PROMPTS/               <- START HERE, one file per day, all five classes
        1-WEDNESDAY-slides.md
        2-THURSDAY-slides.md
        3-FRIDAY-slides.md
    1-design-techniques/
    2-video-and-sound/
    3-aviation-uas/
    4-middle-school-cs/          <- tile map guide + quiz-bank.csv for Friday
    5-yearbook/
    program/week-4-daily-log.md  <- the week at a glance
    grading-and-categories.md
```

## Using the slide prompts

Every block in a SLIDE-PROMPTS file is **one prompt for one slide.** Paste it into Google Slides AI to
generate that slide. These are prompts, not finished slides.

Every deck follows the same skeleton: **As You Come In, Standards + Today, content, Do Now, Turn and Talk,
If You Finish Early, Before You Leave.**

**One focus per class per day.** Anything that does not finish carries into next week rather than being rushed.

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Wed** | Portfolio catch-up | Read a real BPA prompt, pre-production | **Full prep day** | **Tile maps:** maze, walls, collision | Aperture + shoot |
| **Thu** | UX vs UI, user journey | Pick idea, shot list | **FLIGHT DAY** | **Variables:** count items, win condition | Work time |
| **Fri** | Start wireframes + retake | Start storyboards + retake | Footage debrief | **QUIZ**, then maze work | Aperture pair due |

## Things to bring

- **Wed, Video & Sound:** an actual past BPA Video Production Team (#430) prompt. The handout has the
  discussion structure but no prompt text, so students read the real thing.
- **Wed, Aviation:** last week's flight footage, and a real current METAR from aviationweather.gov.
- **Thu, Aviation:** charged battery, the case, cleared card, flight logs. Rain-out backup is the Week 3
  Gimkit bank.
- **Fri, MS CS:** the quiz built from `4-middle-school-cs/quiz-bank.csv`, cut from 30 questions to your best 20.

## Middle School CS this week

Loops are dropped; **tile maps** replace them. Students start a **brand new project** and build the Maze
Collector: draw a maze, mark walls, move with collision (Wed), then count collected items with a variable and
an if (Thu). The guide is `4-middle-school-cs/handouts/tilemap-maze-guide.md`.

The Friday quiz still covers **if statements and everything before, not tile maps.**

## Retake policy (DT and V&S, Friday)

Optional, independent, taken during work time. The **retake score replaces the original**. One time only.

## Carrying into next week

DT wireframes, V&S storyboards, the MS CS Maze Collector lab, and loops (still to be taught).
