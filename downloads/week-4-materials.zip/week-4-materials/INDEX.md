# Week 4 Materials (Tue Sep 8 to Fri Sep 11)

Four day week, Labor Day Monday off. Everything for the whole week is in here.

## How this folder is structured

```
week-4-materials/
    INDEX.md                     <- you are here
    SLIDE-PROMPTS/               <- START HERE, one file per day, all five classes
        1-TUESDAY-slides.md
        2-WEDNESDAY-slides.md
        3-THURSDAY-slides.md
        4-FRIDAY-slides.md
    1-design-techniques/         <- outline, project, vocab, teacher-notes, handouts
    2-video-and-sound/
    3-aviation-uas/
    4-middle-school-cs/          <- also holds quiz-bank.csv for Friday
    5-yearbook/
    program/week-4-daily-log.md  <- the week at a glance
    grading-and-categories.md    <- gradebook categories and weights
```

## Using the slide prompts

Every block in a SLIDE-PROMPTS file is **one prompt for one slide.** Paste it into Google Slides AI to
generate that slide. These are prompts, not finished slides.

Every deck follows the same skeleton, so no class has dead air:

1. **As You Come In** (what to open, what to do immediately)
2. **Standards + Today** (the standard, the agenda)
3. **Content slides** (one idea each)
4. **Do Now** (the work, before any breakout)
5. **Turn and Talk / Partner Check** (a partner or group prompt)
6. **If You Finish Early** (a numbered list so fast finishers never idle)
7. **Before You Leave** (what is due, what is next)

Two deliberate exceptions: Aviation on Thursday swaps the partner slide for "While You Are Not Flying" and "If
Weather Scrubs It," and Middle School CS on Friday has no partner slide because the room is silent for the quiz.

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Tue** | Portfolio checklist, menu restructure, post + describe poster | Read a real BPA prompt, intro pre-production | Footage review, real METAR, new roles | Loops intro | Aperture + quick shoot |
| **Wed** | UX vs UI, user journey map | Pick idea, write shot list | Finalize plan, preflight, weather | An if inside a loop | Work time |
| **Thu** | Wireframe every page | Storyboard every shot | **FLIGHT DAY** | Build Loop It | Work time |
| **Fri** | Finish wireframes + optional retake | Turn in the plan + optional retake | Footage review, debrief | **QUIZ**, then work time | Aperture pair due |

## Things to bring

- **Tue, Video & Sound:** an actual past BPA Video Production Team (#430) prompt. The handout has the
  discussion structure but no prompt text, so students read the real thing.
- **Tue, Aviation:** last week's flight footage, and a real current METAR from aviationweather.gov.
- **Thu, Aviation:** charged battery, the case, cleared card, flight logs. Rain-out backup is the Week 3
  Gimkit bank.
- **Fri, MS CS:** the quiz built from `4-middle-school-cs/quiz-bank.csv`, cut from 30 questions to your best 20.

## Retake policy (DT and V&S, Friday)

Optional, independent, taken during work time. The **retake score replaces the original**. One time only,
because it was the first quiz of the year.
