# Week 4 Materials: Wed Sep 9 to Fri Sep 11

**Three day week.** Labor Day Monday, professional development Tuesday.

---

## Start here

`SLIDE-PROMPTS/` has one file per day, all five classes in each. Every block is one prompt for one slide,
written to paste into Google Slides AI. `program/week-4-daily-log.md` is the week at a glance.

| Class | Wed | Thu | Fri |
|-------|-----|-----|-----|
| Design Techniques | 11 | 9 | 6 |
| Video & Sound | 9 | 5 | 5 |
| Aviation UAS | 9 | 2 | 4 |
| Middle School CS | 10 | 5 | 4 |
| Yearbook | 8 | 1 | 1 |

---

## FRIDAY: build two quizzes

**Both banks are 30 questions, cut to 20. No coupled sets, no images required. Every question stands alone,
so delete any ten and what is left is still a valid quiz.** Both Forms shuffle, so CSV order does not matter.

### Aviation: `3-aviation-uas/quiz-bank.csv`

**Build it and go.** Awareness level by design, 20 of the 30 are straight recall.

Covers what a METAR is and its **units** (knots for wind, statute miles for visibility, feet AGL for clouds,
Celsius for temperature); yaw, pitch and roll; the Mode 2 stick layout, including what happens when you push
the right stick right versus the left stick right, and how to arc around a subject; the **flight limits**
(400 ft AGL, 3 SM visibility, 500 below and 2,000 horizontal from clouds, 100 mph, VLOS, the 0.55 lb
registration threshold); and **Part 107 versus TRUST, including why the Part 107 certificate exists**,
through two applied cases. Breakdown in `3-aviation-uas/quiz.md`.

> **No raw METAR decoding.** They only started reading the coded text this week, which is too recent to
> assess. They have been on the graphical interface until now, so the quiz tests what a METAR is, what units
> the values come in, and what the limits are. Nothing asks them to decode `27012G22KT` or `OVC007`. That
> material is held for the next quiz.

### Middle School CS: `4-middle-school-cs/quiz-bank.csv`

**30 text questions. Run it straight through the Apps Script and you have a complete quiz with nothing to
insert by hand.**

Covers Weeks 1 to 3: if and if/else, comparisons including the `>` versus `≥` boundary, AND and OR, chain
order, remainder for "every Nth", variables and counters, sprites and events, sequence, position and
velocity, overlap and score, and debugging.

**Screenshot questions are a separate file:** `4-middle-school-cs/quiz-screenshot-questions.csv`, 12
questions keyed to `handouts/quiz-screenshot-blocks.md`. Add them to the Form **only if you have prep time**,
making each image by pasting the snippet into MakeCode's JavaScript tab, switching to **Blocks**, and
screenshotting. **Clear the editor between each.** They are ordered easiest to hardest, so add as many as you
get to and stop. **Number 10 is the one to prioritize**, it is the exact bug from Thursday's live build.

> **No JavaScript appears anywhere a student sees.** They code in blocks, so they are assessed in blocks.

**Neither quiz covers this week.** No tile maps or collision for CS, nothing past last Friday for Aviation.

### Also: open the DT and V&S retakes on Classroom at the bell.

---

## Friday's shape, class by class

**Design Techniques and Video & Sound** both run the same way: **ten minutes of new content, maximum**, then
students choose to work quietly or take the retake. **The room stays silent until the last retake is
submitted.** Both have a slide saying exactly that, and both have a handout with every step written out, so a
student who is working never has to ask a question out loud while someone is testing.

- DT: demo the interaction, then `1-design-techniques/handouts/friday-make-it-click.md`. The bar for done is
  one click that makes the screen respond. Play becomes pause, or a button changes screens. Either counts.
- V&S: show what a storyboard panel looks like, then they draw one per shot.

**Middle School CS:** quiz, then back to the maze quietly while others finish.

**Aviation:** quiz, then **the first person in each group to finish pulls that group's footage and submits it
to Classroom**, immediately, without waiting for their group. Nothing gets watched until it is submitted.
Then debrief as a group.

**Yearbook:** one slide. Finish the aperture pair (due today) or work the spread, new book or old book.
Grade check-ins while they work.

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Wed** | Portfolio catch-up, restructure the menu | Read a BPA prompt, intro preproduction, brainstorm | METAR scavenger hunt | Tile maps: maze, walls, collision | Aperture explainer, work time |
| **Thu** | UX/UI vocab, into Figma, build the player screen | Script / storyboard / shot list | **FLIGHT DAY** | Bell ringer, then build the counter and win live | Aperture pair or spreads |
| **Fri** | Make it click, or retake | Storyboards, or retake | **QUIZ**, footage, debrief | **QUIZ**, then maze work | Aperture pair due |

---

## Folders

```
INDEX.md                     this file
SLIDE-PROMPTS/               one file per day, all five classes
1-design-techniques/         figma-intro-build.md (Thu), friday-make-it-click.md (Fri)
2-video-and-sound/           thu-preproduction-terms.md
3-aviation-uas/              quiz-bank.csv (30 Q), quiz.md
4-middle-school-cs/          quiz-bank.csv (30 Q text), quiz-screenshot-questions.csv (12), quiz-screenshot-blocks.md
5-yearbook/
program/week-4-daily-log.md
grading-and-categories.md
```

`outline.md`, `project.md`, `vocab.md`, and `handouts/` are **student-facing.** `teacher-notes.md`,
`quiz.md`, and `quiz-screenshot-blocks.md` are **teacher-only.**

---

## Carrying into next week

- **DT:** the Redesign Project. Material is ready in `1-design-techniques/handouts/thu-teardown-and-setup.md`
- **V&S:** storyboards, then into production
- **MS CS:** the Maze Collector lab, plus loops still to be taught
- **Aviation:** anything the debrief surfaces
