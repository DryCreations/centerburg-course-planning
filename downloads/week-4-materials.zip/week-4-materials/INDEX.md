# Week 4 Materials: Wed Sep 9 to Fri Sep 11

**Three day week.** Labor Day Monday, professional development Tuesday.

---

## Start here

`SLIDE-PROMPTS/` has one file per day, all five classes in each. Every block is one prompt for one slide,
written to paste into Google Slides AI. `program/week-4-daily-log.md` is the week at a glance.

**Slide counts are deliberately lean.** A class doing one thing gets one slide.

| Class | Wed | Thu | Fri |
|-------|-----|-----|-----|
| Design Techniques | 11 | 9 | 6 |
| Video & Sound | 9 | 5 | 5 |
| Aviation UAS | 9 | 2 | 4 |
| Middle School CS | 10 | 5 | 4 |
| Yearbook | 8 | 1 | 1 |

---

## FRIDAY: do these before class

### 1. Build the Middle School CS quiz (this is the long one)

**20 questions: 10 text, then 10 block-reading with screenshots.** Instructions in
`4-middle-school-cs/quiz.md`.

1. Cut `4-middle-school-cs/quiz-bank.csv` (34 questions) to 20, keeping the `[SCREENSHOT]` rows **last**
2. Paste into the quiz spreadsheet tab, run the Apps Script
3. **Insert the block screenshots by hand.** The Apps Script does not place images.

Images come from `4-middle-school-cs/handouts/quiz-screenshot-blocks.md`: paste each snippet into MakeCode's
**JavaScript** tab, switch to **Blocks**, screenshot. **Clear the editor between each one.**

The 12 snippets are **ordered easiest to hardest**, so if you run out of prep time, cut from the bottom and
delete those questions from the Form. **Keep number 10**, it is the exact bug from Thursday's live build.

> **No JavaScript appears anywhere a student sees.** They code in blocks, so they are assessed in blocks. The
> paste step is only how you build the blocks fast. There is a translation table at the end of the handout
> (`==` becomes `=`, `&&` becomes `and`, `%` becomes "remainder of") to check against if you reword anything.

### 2. Build the Aviation quiz

`3-aviation-uas/quiz-bank.csv`, 40 questions, cut to the best 20. Keep the `AV-S1` scenario set together
(four questions off one METAR ending in a go/no-go call).

### 3. Open both retakes

DT and V&S, on Classroom, open at the bell.

---

## Friday's shape, class by class

**Design Techniques and Video & Sound** both run the same way: **ten minutes of new content, maximum**, then
students choose to work quietly or take the retake. **The room stays silent until the last retake is
submitted.** Both have a slide saying exactly that, and both have a handout with every step written out, so a
student who is working never has to ask a question out loud while someone is testing.

- DT: demo the interaction, then `1-design-techniques/handouts/friday-make-it-click.md`. The bar for done is
  one click that makes the screen respond. Play becomes pause, or a button changes screens. Either counts.
- V&S: show what a storyboard panel looks like, then they draw one per shot.

**Middle School CS:** quiz, then back to the maze quietly while others finish.

**Aviation:** quiz, then **the first person in each group to finish pulls that group's footage and submits it
to Classroom**, immediately, without waiting for their group. Nothing gets watched until it is submitted.
Then debrief as a group: did the shot match the plan, heading versus pointing, what would you change, what
went right.

**Yearbook:** one slide. Finish the aperture pair (due today) or work the spread, new book or old book.
Grade check-ins while they work.

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Wed** | Portfolio catch-up, restructure the menu | Read a BPA prompt, intro preproduction, brainstorm | METAR scavenger hunt | Tile maps: maze, walls, collision | Aperture explainer, work time |
| **Thu** | UX/UI vocab, into Figma, build the player screen | Script / storyboard / shot list | **FLIGHT DAY** | Bell ringer, then build the counter and win live | Aperture pair or spreads |
| **Fri** | Make it click, or retake | Storyboards, or retake | **QUIZ**, footage, debrief | **QUIZ**, then maze work | Aperture pair due |

---

## Folders

```
INDEX.md                     this file
SLIDE-PROMPTS/               one file per day, all five classes
1-design-techniques/         figma-intro-build.md (Thu), friday-make-it-click.md (Fri)
2-video-and-sound/           thu-preproduction-terms.md
3-aviation-uas/              quiz-bank.csv, quiz.md
4-middle-school-cs/          quiz-bank.csv, quiz.md, quiz-screenshot-blocks.md
5-yearbook/
program/week-4-daily-log.md
grading-and-categories.md
```

`outline.md`, `project.md`, `vocab.md`, and `handouts/` are **student-facing.** `teacher-notes.md`,
`quiz.md`, and `quiz-screenshot-blocks.md` are **teacher-only.**

---

## Carrying into next week

- **DT:** the Redesign Project, using the tool they just learned. Material is written and ready in
  `1-design-techniques/handouts/thu-teardown-and-setup.md`
- **V&S:** storyboards, then into production
- **MS CS:** the Maze Collector lab, plus loops still to be taught
- **Aviation:** anything the debrief surfaces
