# Week 4 Materials: Wed Sep 9 to Fri Sep 11

**Three day week.** Labor Day Monday, professional development Tuesday.

---

## Start here

`SLIDE-PROMPTS/` has one file per day, all five classes in each. Every block is one prompt for one slide,
written to paste into Google Slides AI.

- `1-WEDNESDAY-slides.md`
- `2-THURSDAY-slides.md`
- `3-FRIDAY-slides.md`

`program/week-4-daily-log.md` is the week at a glance plus what changed and why.

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Wed** | Portfolio catch-up, restructure the menu | Read a BPA prompt, intro preproduction, brainstorm | METAR scavenger hunt on aviationweather.gov | Tile maps: maze, walls, collision | Aperture explainer, work time |
| **Thu** | UX vs UI, pick a broken screen, tear it down | Script / storyboard / shot list, then write yours | **FLIGHT DAY** | Bell ringer, then build the counter and win live | Work time, cameras or spreads |
| **Fri** | Wireframe the fix, build in Figma, + retake | Storyboards + retake | **QUIZ**, then footage debrief | **QUIZ**, then maze work | Aperture pair due |

---

## Thursday at a glance

- **Design Techniques:** new project. Students pick a real app or website screen that frustrates them and tear
  it down on paper: what the person came to do, where the journey breaks, five annotations in **design
  language** (there is an "instead of / write" table for this). **Figma setup is the last 10 minutes only:**
  sign in with Google, skip the tour, make one named phone frame. Handout:
  `1-design-techniques/handouts/thu-teardown-and-setup.md`
- **Video & Sound:** the three preproduction documents and how they differ, script vs storyboard vs shot list,
  including why the shot list is in shooting order rather than story order. Then they write both. Handout:
  `2-video-and-sound/handouts/thu-preproduction-terms.md`
- **Aviation:** **one check slide** stays on the board as they come in (weather, limits, go/no-go, roles, card
  and battery). Slide 2 warns them the quiz is tomorrow and names what it covers. Then fly.
- **Middle School CS:** a five-question bell ringer in the exact shape of tomorrow's quiz
  (`4-middle-school-cs/handouts/bell-ringer-thu.md`), then **build the counter and the win live on the board**,
  including deliberately breaking the win with a wrong number so they see the most common bug happen. Script:
  `4-middle-school-cs/handouts/thu-live-build-script.md`
- **Yearbook:** two slides, then break out. Cameras or spreads, their choice.

---

## Friday has three assessments

- **DT and V&S:** optional independent **retake** of last week's quiz during work time. The retake score
  **replaces** the original, one time only. Nothing else Friday is deadline-locked, so stepping out costs them
  nothing.
- **Aviation:** **first quiz of the year.** 40 questions in `3-aviation-uas/quiz-bank.csv`, cut to the best 20.
  Keep the `AV-S1` scenario set together (four questions off one METAR ending in a go/no-go call).
- **MS CS:** **first quiz.** 30 questions in `4-middle-school-cs/quiz-bank.csv`, cut to 20. **If statements
  and everything before. NOT tile maps.**

---

## Bring / set up

| Day | What |
|-----|------|
| Wed | Fill in your home-field identifier at the top of the METAR scavenger hunt (KCMH or KOSU are reliable) |
| Thu | Aviation: the case, a charged battery, a cleared card, flight logs. DT: nothing, it is a paper day until the last 10 minutes |
| Fri | Both quizzes built and posted. DT: Figma already working from Thursday |

**Figma note:** free Starter accounts are enough (unlimited drafts, real frames, real prototyping). Do not
make Thursday depend on Figma for Education, that verification can take days. Apply in the background.

---

## Folders

```
INDEX.md                     this file
SLIDE-PROMPTS/               one file per day, all five classes
1-design-techniques/         outline, project, vocab, teacher-notes, handouts
2-video-and-sound/
3-aviation-uas/              + quiz-bank.csv, quiz.md
4-middle-school-cs/          + quiz-bank.csv, quiz.md
5-yearbook/
program/week-4-daily-log.md
grading-and-categories.md
```

`outline.md`, `project.md`, `vocab.md`, and `handouts/` are **student-facing.** `teacher-notes.md` and
`quiz.md` are **teacher-only.**

---

## Carrying into next week

- **DT:** finish the Figma screen, connect a two-frame clickable prototype, write the before and after
  paragraph, post the pairing to the portfolio under Unit 1.1
- **V&S:** storyboards, then into production
- **MS CS:** the Maze Collector lab, plus loops still to be taught
- **Aviation:** footage critique, and the flight if weather scrubbed Thursday
