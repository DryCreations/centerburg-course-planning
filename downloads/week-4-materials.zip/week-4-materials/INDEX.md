# Week 4 Materials: Wed Sep 9 to Fri Sep 11

**Three day week.** Labor Day Monday, professional development Tuesday.

---

## Start here

`SLIDE-PROMPTS/` has one file per day, all five classes in each. Every block is one prompt for one slide,
written to paste into Google Slides AI. `program/week-4-daily-log.md` is the week at a glance.

| Class | Wed | Thu | Fri |
|-------|-----|-----|-----|
| Design Techniques | 11 | 9 | 6 |
| Video & Sound | 9 | 5 | 5 |
| Aviation UAS | 9 | 2 | 4 |
| Middle School CS | 10 | 5 | 4 |
| Yearbook | 8 | 1 | 1 |

---

## FRIDAY: build two quizzes

### Aviation: `3-aviation-uas/quiz-bank.csv`, 92 questions, cut to 20

**No images. Build it and go.** Awareness-level by design: 46 of the 92 are straight recall, and the bank is over four times the length of the quiz so you can delete freely.

Covers what a METAR is and **the unit for every field** (knots, statute miles, Celsius, feet AGL, inches of
mercury); yaw, pitch, and roll; the Mode 2 stick layout and what the drone does for each input, including
arcing around a subject; the legal limits (400 ft AGL, 3 SM, cloud clearance, 100 mph, VLOS, the 0.55 lb
registration threshold); and Part 107 versus TRUST. Also the Week 2 controller day (throttle, hover, home
point, RTH, lost link, center is stop), the four forces individually, the FAA UAS Facility Map and NOTAMs,
preflight and battery safety, and the Part 107 course modules (night operations, flying over people, one
aircraft at a time, 24 month recurrency). Full breakdown and a suggested cut in `3-aviation-uas/quiz.md`.

`AV-S1` is a four-question set off one real METAR, ending in a go/no-go call. **Keep all four together** if
you use it.

### Middle School CS: `4-middle-school-cs/quiz-bank.csv`, 60 questions, cut to 20

**10 text, then 10 block-reading with screenshots**, screenshots grouped last so images go in one pass.

Beyond if statements, the text half now also covers sprites and events, sequence, position and velocity,
overlap and score, lives and game over, and debugging, all from Weeks 1 to 3. **Nothing on either quiz covers
this week.**

1. Cut to 20, keeping the `[SCREENSHOT]` rows last
2. Paste into the quiz spreadsheet tab, run the Apps Script
3. **Insert the block screenshots by hand.** The Apps Script does not place images.

Images come from `4-middle-school-cs/handouts/quiz-screenshot-blocks.md`: paste each snippet into MakeCode's
**JavaScript** tab, switch to **Blocks**, screenshot. **Clear the editor between each one.** The 12 snippets
are **ordered easiest to hardest**, so cut from the bottom if time runs out. **Keep number 10**, it is the
exact bug from Thursday's live build.

> **Out of time entirely?** `4-middle-school-cs/quiz-bank-text-only.csv` is the same 48 text questions with
> every screenshot row stripped. Run it straight through the Apps Script and you have a complete, valid quiz
> with **nothing to insert.**

> **No JavaScript appears anywhere a student sees.** They code in blocks, so they are assessed in blocks. The
> handout ends with a translation table (`==` becomes `=`, `&&` becomes `and`, `%` becomes "remainder of").

### Also: open the DT and V&S retakes on Classroom at the bell.

---

## Friday's shape, class by class

**Design Techniques and Video & Sound** both run the same way: **ten minutes of new content, maximum**, then
students choose to work quietly or take the retake. **The room stays silent until the last retake is
submitted.** Both have a slide saying exactly that, and both have a handout with every step written out, so a
student who is working never has to ask a question out loud while someone is testing.

- DT: demo the interaction, then `1-design-techniques/handouts/friday-make-it-click.md`. The bar for done is
  one click that makes the screen respond. Play becomes pause, or a button changes screens. Either counts.
- V&S: show what a storyboard panel looks like, then they draw one per shot.

**Middle School CS:** quiz, then back to the maze quietly while others finish.

**Aviation:** quiz, then **the first person in each group to finish pulls that group's footage and submits it
to Classroom**, immediately, without waiting for their group. Nothing gets watched until it is submitted.
Then debrief as a group.

**Yearbook:** one slide. Finish the aperture pair (due today) or work the spread, new book or old book.
Grade check-ins while they work.

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Wed** | Portfolio catch-up, restructure the menu | Read a BPA prompt, intro preproduction, brainstorm | METAR scavenger hunt | Tile maps: maze, walls, collision | Aperture explainer, work time |
| **Thu** | UX/UI vocab, into Figma, build the player screen | Script / storyboard / shot list | **FLIGHT DAY** | Bell ringer, then build the counter and win live | Aperture pair or spreads |
| **Fri** | Make it click, or retake | Storyboards, or retake | **QUIZ**, footage, debrief | **QUIZ**, then maze work | Aperture pair due |

---

## Folders

```
INDEX.md                     this file
SLIDE-PROMPTS/               one file per day, all five classes
1-design-techniques/         figma-intro-build.md (Thu), friday-make-it-click.md (Fri)
2-video-and-sound/           thu-preproduction-terms.md
3-aviation-uas/              quiz-bank.csv (92 Q), quiz.md
4-middle-school-cs/          quiz-bank.csv (60 Q), quiz-bank-text-only.csv (48 Q), quiz-screenshot-blocks.md
5-yearbook/
program/week-4-daily-log.md
grading-and-categories.md
```

`outline.md`, `project.md`, `vocab.md`, and `handouts/` are **student-facing.** `teacher-notes.md`,
`quiz.md`, and `quiz-screenshot-blocks.md` are **teacher-only.**

---

## Carrying into next week

- **DT:** the Redesign Project. Material is ready in `1-design-techniques/handouts/thu-teardown-and-setup.md`
- **V&S:** storyboards, then into production
- **MS CS:** the Maze Collector lab, plus loops still to be taught
- **Aviation:** anything the debrief surfaces
