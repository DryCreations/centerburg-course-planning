# Week 9 Materials: Mon Oct 12 to Fri Oct 16

**Last week of the quarter.** No large new units. Open `POST-THIS.md` for what to post Monday.

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | **Color grading** | Screen, **submit v1**, meet the footage | Hunt: gusts, low cloud. ODOT | Build | Keep working |
| **Tue** | Moods: **neutral + mood 1** | Watch clips, **storyboard** | Hunt: rain, storms, fog. ODOT | Build, check-ins | Keep working |
| **Wed** | **Mood 2** | **Storyboard approved**, cut | Hunt: TAF, TFR, sneaky one. ODOT | Build | Keep working |
| **Thu** | **Defend, portfolio**, submit missing | **Cut**, submit missing | **Check KCMH, every reason. Fly if it passes** | All six in | Keep working |
| **Fri** | **QUIZ** | **QUIZ**, then cut | Finish, ODOT, submit missing | **Project due** | **Check-in due** |

---

## Design Techniques: Color Grading, then Three Moods

**Monday: color grading, taught properly.** Color Grading or Split Toning, four named looks, keep one,
**saturation 5 to 15.** Check which panel your Camera Raw has.

**Tuesday to Thursday: Three Moods.** Neutral, then two moods, then a written defense. **Color grading in
at least one mood, and at least four of last week's tools.** **Thursday all three go on the portfolio**
with a short description. **A photo they took is preferred**, from the Week 7 shoot; last week's class
photos are the backup. Due Thursday.

## Video & Sound: Screen, Submit, Then the Bridge Scene

**Monday:** volunteers screen edits, everyone submits version 1, then meet the new footage. **Rest of the
week:** watch every clip, storyboard (no CapCut until it is approved), then cut. **Next week:** music,
title, credits, and color, with the color lesson together Monday Oct 19. **Due Fri Oct 23, Q2
gradebook.** Rubric is `handouts/bridge-rubric.md`. Download the footage and run the CapCut check first:
both are in `2-video-and-sound/teacher-notes.md`.

## Aviation: The No-Go Hunt

**Weeks of good local weather have trained them to say "it's fine, let's go."** So they hunt **real
reports, on aviationweather.gov and tfr.faa.gov**, for reasons to cancel: gusts, visibility under 3
miles, cloud too low (the **500 foot rule**), thunderstorms, precipitation, fog, freezing, a TAF that turns
bad, and TFRs. **Hunt in the red and purple dots**; Alaska and the Pacific Northwest if the lower 48 are
green. **Thursday they check every reason on the real KCMH report** and fly only if all of them pass.

**Tour the GFA map on the projector Monday** before they start, and click through it yourself first. What
counts as correct, where each category usually turns up in October, and **backup reports** for anything
truly missing are in `3-aviation-uas/teacher-notes.md`.

## Middle School CS: Build It

Build week from their approved plan, with grade check-ins. **Due Friday.** The project plan with the six
requirements is in `still-in-use/`.

## Yearbook

Keep working. **Week 9 check-in due Friday.**

---

## Still to do

- **DT and V&S Friday quizzes**, on Weeks 7 and 8. Scope approved, banks to build
- **Tuesday to Friday slides**, as the week goes

## Carried into next quarter

DT typography (Unit 1.3), V&S audio (Unit 1.3), Aviation preflight (Unit 2.2), and BPA event selection.

---

## Folders

```
INDEX.md, POST-THIS.md
SLIDE-PROMPTS/          Monday
1-design-techniques/    outline, handouts/color-grading.md (MON),
                        handouts/mood-project.md (TUE-THU), mood-TEACHER.md
2-video-and-sound/      outline, teacher-notes.md (footage, CapCut check),
                        handouts/bridge-scene.md, handouts/bridge-rubric.md
3-aviation-uas/         outline, teacher-notes.md (what counts, backups),
                        handouts/no-go-hunt.md
4-middle-school-cs/     outline
5-yearbook/             (nothing new)
still-in-use/           MS CS project plan, aviation orbit drill
program/                week-9-daily-log.md
```
