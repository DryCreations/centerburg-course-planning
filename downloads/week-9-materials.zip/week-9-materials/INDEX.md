# Week 9 Materials: Mon Oct 12 to Fri Oct 16

**Last week of the quarter.** No large new units. Open `POST-THIS.md` for what to post.

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | **Shot photos outside**, offloaded, tried color grading | **Screen** finished edits, **submit v1**, meet the bridge scene | **Mission briefings** start | **Build** the first piece | Keep working |
| **Tue** | Finish learning grading if needed, then **Three Moods: neutral and mood 1** | Watch every clip, **storyboard**, cut | Missions: research, emails | Build. One-on-one check-ins | Keep working |
| **Wed** | **Mood 2** | **Cut** | Missions: finish research and emails | Build | Keep working |
| **Thu** | **Portfolio.** Submit missing | **Cut.** Submit missing | **Fly if it is nice.** Rain: keep working | All six requirements in | Keep working |
| **Fri** | **QUIZ**, then finish. **Three Moods due** | **QUIZ**, then cut. **Whole scene cut** | Finish, submit missing | **Project due** | **Week 9 check-in due** |

---

## Design Techniques: Color Grading, then Three Moods

**Monday they shot photos outside** and tried color grading. **Tuesday to Thursday: Three Moods**, using
Monday's photos. Color Grading was cut to one question and one photo, due Monday. Students still learning the tools
finish that first. **Three Moods due Friday, after the quiz.**

## Video & Sound: Screen, Submit, Then the Bridge Scene

**Monday:** volunteers screen edits, everyone submits version 1, then meet the new footage. **Rest of the
week:** watch every clip, storyboard (no CapCut until it is approved), then cut. **Next week:** music,
title, credits, and color, with the color lesson together Monday Oct 19. **Due Fri Oct 23, Q2
gradebook.** Rubric is `handouts/bridge-rubric.md`. Download the footage and run the CapCut check first:
both are in `2-video-and-sound/teacher-notes.md`.

## Aviation: Mission Briefings

**Four missions** with a client, date, time and coordinates. Students research airspace, TFRs, METARs and
TAFs, decide whether each flight is allowed, and draft an email to the client. Monday to Wednesday;
Thursday fly, or keep working if it rains. **Your worksheet is not in this bundle.** Things to watch for
are in `3-aviation-uas/teacher-notes.md`.

## Middle School CS: Build It

Build week from their approved plan, with grade check-ins. **Due Friday.** The project plan with the six
requirements is in `still-in-use/`.

## Yearbook

Keep working. **Week 9 check-in due Friday.**

---

## Still to do

- **Thursday and Friday slides**, as the week goes
- **Quizzes are built:** whole quarter, 20 questions each, `quiz-bank.csv` and `quiz.md` in the DT and
  V&S folders. **Gimkit reviews:** `gimkit-review.csv` in the same folders

## Carried into next quarter

DT typography (Unit 1.3), V&S audio (Unit 1.3), Aviation preflight (Unit 2.2), and BPA event selection.

---

## Folders

```
INDEX.md, POST-THIS.md
SLIDE-PROMPTS/          Monday, Tuesday, Wednesday
1-design-techniques/    outline, handouts/color-grading.md (MON),
                        handouts/mood-project.md (TUE-THU), mood-TEACHER.md,
                        quiz.md, quiz-bank.csv, gimkit-review.csv
2-video-and-sound/      outline, teacher-notes.md (footage, CapCut check),
                        handouts/bridge-scene.md, handouts/bridge-rubric.md,
                        quiz.md, quiz-bank.csv, gimkit-review.csv
3-aviation-uas/         outline, teacher-notes.md (things to watch for)
4-middle-school-cs/     outline
5-yearbook/             (nothing new)
still-in-use/           MS CS project plan, aviation orbit drill
program/                week-9-daily-log.md
```
