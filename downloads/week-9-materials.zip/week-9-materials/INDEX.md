# Week 9 Materials: Mon Oct 12 to Fri Oct 16

**Last week of the quarter.** No large new units. Open `POST-THIS.md` for what to post Monday.

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | Three Moods: **neutral** | **Lower third** | Report 1, then ODOT | Build | Keep working |
| **Tue** | **Mood 1** | **Animated title** | Report 2, then ODOT | Build, check-ins | Keep working |
| **Wed** | **Mood 2** | **Keyframed text** | Report 3, then ODOT | Build | Keep working |
| **Thu** | **Defend it**, submit missing | **Export v2**, submit missing | Report 4, **real METAR, fly if go** | All six in | Keep working |
| **Fri** | **QUIZ** | **QUIZ** | Finish, ODOT, submit missing | **Project due** | **Check-in due** |

---

## Design Techniques: Three Moods

**One photo from last week, three versions:** neutral and correct, then two moods, then a written
defense. **No new photos to source**: they reuse the cityscape, the portrait or a color photo, reset to
defaults. The mood table now uses HSL and color grading, and there is a fifth option, **one color only.**
Due Thursday, since Friday is the quiz.

## Video & Sound: Titles and Motion

**Version 2 of the edit they turned in Friday.** Four rules for text (read it twice, never touching the
edge, stands out from the picture, two fonts at most). Then a **lower third**, an **In and Out animated
title**, and **custom keyframed text: move in, hold, move out.** Export Thursday as `LastName_Edit_v2`.

## Aviation: Watch a Front Come Through

**Four practice METARs from KCMH, one a day, telling one story: a cold front arrives, passes and
leaves.** Monday's TAF forecasts the wind shift; Tuesday has a thunderstorm and falling pressure;
Wednesday has a northwest wind, a dew point crash and rising pressure; Thursday is calm high pressure.
Every day ends in a go or no-go with the deciding number, then ODOT Module 3. **Pull the real KCMH METAR
on the projector each day**, and **Thursday's real METAR decides whether they fly.** Answer key in
`3-aviation-uas/teacher-notes.md`.

## Middle School CS: Build It

Build week from their approved plan, with grade check-ins. **Due Friday.** The project plan with the six
requirements is in `still-in-use/`.

## Yearbook

Keep working. **Week 9 check-in due Friday.**

---

## Still to do

- **DT and V&S Friday quizzes**, on Weeks 7 and 8. Scope first, then banks
- **Tuesday to Friday slides**, as the week goes

## Carried into next quarter

DT typography (Unit 1.3), V&S audio (Unit 1.3), Aviation preflight (Unit 2.2), and BPA event selection.

---

## Folders

```
INDEX.md, POST-THIS.md
SLIDE-PROMPTS/          Monday
1-design-techniques/    outline, handouts/mood-project.md, mood-TEACHER.md
2-video-and-sound/      outline, handouts/titles-and-motion.md
3-aviation-uas/         outline, teacher-notes.md (THE KEY),
                        handouts/watch-a-front.md
4-middle-school-cs/     outline
5-yearbook/             (nothing new)
still-in-use/           MS CS project plan, aviation orbit drill
program/                week-9-daily-log.md
```
