# Color Grading

**Design Techniques | Due Monday**

Color grading adds one color to the bright parts of a photo and another color to the dark parts. You
will use it in the Three Moods project.

## Standards

**7.9.6** Edit photographs (e.g., color corrections, cropping, enhancements).
**7.2.7** Select colors based on color theory and psychology.

---

## Steps (7.9.6)

1. Pick a photo. One you took Monday is best. Week 7 photos or last week's class photos also work
2. Fix it first: white balance and tone, like last week
3. Scroll below HSL. Your Camera Raw has one of these:
   - **Color Grading:** three color wheels for Shadows, Midtones, and Highlights
   - **Split Toning:** Hue and Saturation sliders for Highlights and Shadows
4. Keep **Saturation between 5 and 15.** Higher than that looks fake

## Try all four looks (7.2.7)

- **Teal and orange:** orange highlights, teal shadows
- **Golden hour:** gold highlights, warm brown shadows
- **Cold:** neutral highlights, blue shadows
- **Faded film:** pale yellow highlights, soft green shadows

Keep the one that fits your photo best. Export it as `LastName_Grade_01`.

---

## Question

**1.** Which look did you keep? Write the hue and saturation numbers for the highlights and the shadows.

## Graded on

`LastName_Grade_01` and your answer. Then move straight into Three Moods.
