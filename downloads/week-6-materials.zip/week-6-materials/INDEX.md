# Week 6 Materials: Mon Sep 21 to Fri Sep 25

---

## Start here

**`POST-THIS.md`** lists what goes to each Classroom, in priority order, with a two item short list for
Monday.

**`SLIDE-PROMPTS/1-MONDAY-slides.md`** has all five classes for Monday, one prompt per slide, with board
versions for running without a projector.

**Career-tech classes open with standards**, written out in full, meant to stay on the board.

---

## Monday: two quizzes to build this morning

| Class | Bank | Cut to |
|-------|------|--------|
| **Video & Sound** | `2-video-and-sound/quiz-bank.csv`, 62 | 20 |
| **Design Techniques** | `1-design-techniques/quiz-bank.csv`, 42 | 20 |

Both plain CSV, no images, nothing coupled. `option_a` is always correct, so let the script shuffle. Each has
a suggested cut in its `quiz.md`.

**Then:** post `5-yearbook/project.md`, so the two week photo clock starts today.

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | **QUIZ**, then build | **QUIZ**, then new group plans | Symbol review, read an area | Finish Star Catcher | **Post the assignment** |
| **Tue** | Labs: Selection + Input | Production | Plan a flight from the chart | Showcase, submit | Shoot |
| **Wed** | Connect both ways | Production | Work time: charts or ODOT | **Digital footprint** | Shoot |
| **Thu** | Partner test, fixes | Production | **FLIGHT: box pattern** | **Who collects it** | Shoot |
| **Fri** | Write-up, post, **project due** | Production | **QUIZ** | **Your footprint** | Shoot |

---

## Three quizzes, two of them today

| Class | When | Bank | Cut to | Mix |
|-------|------|------|--------|-----|
| Video & Sound | **Monday** | 62 | 20 | Camera, preproduction, plus the new transitions and framing reading |
| Design Techniques | **Monday** | 42 | 20 | Half Week 3 typography and hierarchy, half this unit's UX/UI |
| Aviation UAS | **Friday** | 62 | 20 | Charts, airspace, Part 107 and ODOT Module 1, plus carried-forward weather |

All plain CSV, no images, nothing coupled. `option_a` is always correct, so let the script shuffle. Each has
a `quiz.md` with a suggested cut.

---

## Calls made without confirmation

Each is a small change if wrong.

- **V&S quiz stays Monday**, as promised. Moving it twice right after a reset about following through would
  undercut the reset.
- **MS CS finishes Star Catcher Mon and Tue, then pivots to digital citizenship** Wed to Fri, mostly
  unplugged. IC is a strand skipped entirely, it needs no setup, and it is a real change of pace after four
  programming concepts in two weeks.
- **DT quiz is half carried forward, half new**, and now runs Monday alongside V&S.
- **Aviation flies a fixed four-point box pattern** Thursday: same altitude, same order, five second holds,
  right stick only. Reproducible and comparable pilot to pilot.
- **Yearbook runs two weeks**, due Fri Oct 2, 20 usable frames from 2+ events, all-day checkout returned
  after 9th period.

---

## Notes per class

### Design Techniques

**Quiz Monday, project due Friday.** Nothing on the quiz depends on this week's labs, verified against the
bank: everything covered was taught by last Friday.

**Wednesday is the real project deadline**: everything connected both directions, because Thursday is for
fixing, not building.

The Selection lab slides to Tuesday alongside Input if the quiz eats Monday. It is deliberately the **frame
method**, nine connections across three frames. Say why the tedium is worth it: that is exactly what
components with variants exist to solve.

### Video & Sound

Quiz Monday, then production. **Clear groups out loud, by name, when they earn location privileges**, which
is one full period run correctly against the checklist on `week-5/handouts/reset-and-replan.md`.

Watch whether pairs and trios actually fix the passenger problem, and push back on unrealistic schedules
Monday rather than Thursday.

### Aviation UAS

**Sectionals get three more days** because the exit tickets say it has not landed and it feeds both the quiz
and the WebXam.

Monday moves from single symbols to **reading a whole area**. The last question of the Do Now is the point:
could I fly at this spot, to what altitude, and what would I need first?

Thursday is `handouts/box-pattern-flight.md`. **Stopping is the skill**, not moving. The preflight gate is
unchanged and a no-go is a real outcome.

**Say every day: ODOT Module 1 is due Thursday night and it is on Friday's quiz.**

### Middle School CS

Finish and show the game, then three unplugged days on digital footprint.
`handouts/digital-footprint.md` carries all three.

**Discussion first, writing second.** Do not turn it into a worksheet, and do not make it a scare session.
The interesting version is how the system actually works, which is Day 2: any one data point is boring, all
of them together are not.

**Do not ask students to share their Day 3 audit.** That one is theirs.

### Yearbook

Two weeks, due Fri Oct 2. **The all-day checkout is what makes it work**, so say so explicitly or everyone
defaults to the class period and shoots the same hallway.

Check the sign-out log midway through week 6, not at the end of week 7.

---

## Folders

```
INDEX.md                     this file
POST-THIS.md                 what to post, in priority order
SLIDE-PROMPTS/               Monday, all five classes
1-design-techniques/         outline, quiz-bank.csv (42), quiz.md, teacher-notes
2-video-and-sound/           outline, quiz-bank.csv (62), quiz.md, teacher-notes
3-aviation-uas/              outline, quiz-bank.csv (62), quiz.md, box-pattern-flight.md
4-middle-school-cs/          outline, digital-footprint.md, teacher-notes
5-yearbook/                  project.md, outline, teacher-notes
program/week-6-daily-log.md
grading-and-categories.md
```

`outline.md`, `project.md`, and `handouts/` are **student-facing.** `teacher-notes.md` and `quiz.md` are
**teacher-only.**

> **Week 5 materials still apply**: the DT project and labs, the V&S reset and equipment procedure, the
> Aviation chart handouts, and the MS CS Star Catcher lab are all in the Week 5 zip and still in use.
