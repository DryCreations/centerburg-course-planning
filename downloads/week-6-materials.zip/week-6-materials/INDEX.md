# Week 6 Materials: Mon Sep 21 to Fri Sep 25

---

## Start here

**`POST-THIS.md`** lists what goes to each Classroom, in priority order, with a two item short list for
Monday.

**`SLIDE-PROMPTS/`** has all five classes for each day, one prompt per slide, with board versions for
running without a projector. `1-MONDAY-slides.md` and `2-TUESDAY-slides.md` are in.

**Career-tech classes open with standards**, written out in full, meant to stay on the board.

---

## Tuesday Sep 22: what is new

| Class | Tuesday |
|-------|---------|
| **DT** | Ten minutes to make files runnable, then **peer review** in pairs, then build. New: `1-design-techniques/handouts/peer-review.md`, post it |
| **V&S** | **Filming restarts, in this room**, on a three-slot sign-up board. New: `2-video-and-sound/handouts/filming-signup.md`, post it |
| **Aviation** | **Coordinate bell ringer**: a lat/long, found on SkyVector, name the class you are standing in plus floor and ceiling. Then chart work. Teacher reference: `3-aviation-uas/handouts/coordinate-bell-ringers.md`, do not post |
| **MS CS** | Bell ringer on nested loops, then Day 2 of Wave Defender. Teacher reference: `4-middle-school-cs/handouts/bell-ringers.md`, do not post |
| **Yearbook** | Work time, no instruction |

> **Verify the Aviation coordinates on SkyVector before you use them.** The candidates in the handout are
> flagged and were not confirmed from here.

---

## Monday: two quizzes to build this morning

| Class | Bank | Cut to |
|-------|------|--------|
| **Video & Sound** | `2-video-and-sound/quiz-bank.csv`, 62 | 20 |
| **Design Techniques** | `1-design-techniques/quiz-bank.csv`, 42 | 20 |

Both plain CSV, no images, nothing coupled. `option_a` is always correct, so let the script shuffle. Each has
a suggested cut in its `quiz.md`.

**Then:** post `5-yearbook/project.md`, so the two week photo clock starts today.

---

## The week

| Day | DT | V&S | Aviation | MS CS | Yearbook |
|-----|----|-----|----------|-------|----------|
| **Mon** | **QUIZ**, then build | **QUIZ**, then new group plans | Symbol review, read an area | **New game:** ship + shooting | **Post the assignment** |
| **Tue** | **Peer review**, then Input | **Filming in this room**, by sign-up | Coordinate bell ringer, then charts | **Waves** via nested loops | Shoot |
| **Wed** | Connect both ways | Production | Work time: charts or ODOT | Hits, misses, ending | Shoot |
| **Thu** | Partner test, fixes | Production | **FLIGHT: box pattern** | Extensions, showcase | Shoot |
| **Fri** | Write-up, post, **project due** | Production | **QUIZ** | **QUIZ** | Shoot |

---

## Four quizzes, two of them today

| Class | When | Bank | Cut to | Mix |
|-------|------|------|--------|-----|
| Video & Sound | **Monday** | 62 | 20 | Camera, preproduction, plus the new transitions and framing reading |
| Design Techniques | **Monday** | 42 | 20 | Half Week 3 typography and hierarchy, half this unit's UX/UI |
| Aviation UAS | **Friday** | 62 | 20 | Charts, airspace, Part 107 and ODOT Module 1, plus carried-forward weather |
| Middle School CS | **Friday** | 39 | 20 | Loops, nested loops, modulo, conditionals, variables, debugging |

All plain CSV, no images, nothing coupled. `option_a` is always correct, so let the script shuffle. Each has
a `quiz.md` with a suggested cut.

---

## Calls made without confirmation

Each is a small change if wrong.

- **V&S quiz stays Monday**, as promised. Moving it twice right after a reset about following through would
  undercut the reset.
- **MS CS builds a new game in a new genre**: Wave Defender, a shooter. **One new block all week**, so the
  load is a new application rather than new theory. Quiz Friday.
- **DT quiz is half carried forward, half new**, and now runs Monday alongside V&S.
- **Aviation flies a fixed four-point box pattern** Thursday: same altitude, same order, five second holds,
  right stick only. Reproducible and comparable pilot to pilot.
- **Yearbook runs two weeks**, due Fri Oct 2, 20 usable frames from 2+ events, all-day checkout returned
  after 9th period.

---

## Notes per class

### Design Techniques

**Quiz Monday, project due Friday.** Nothing on the quiz depends on this week's labs, verified against the
bank: everything covered was taught by last Friday.

**Wednesday is the real project deadline**: everything connected both directions, because Thursday is for
fixing, not building.

The Selection lab slides to Tuesday alongside Input if the quiz eats Monday. It is deliberately the **frame
method**, nine connections across three frames. Say why the tedium is worth it: that is exactly what
components with variants exist to solve.

### Video & Sound

Quiz Monday, then production. **Clear groups out loud, by name, when they earn location privileges**, which
is one full period run correctly against the checklist on `week-5/handouts/reset-and-replan.md`.

Watch whether pairs and trios actually fix the passenger problem, and push back on unrealistic schedules
Monday rather than Thursday.

### Aviation UAS

**Sectionals get three more days** because the exit tickets say it has not landed and it feeds both the quiz
and the WebXam.

Monday moves from single symbols to **reading a whole area**. The last question of the Do Now is the point:
could I fly at this spot, to what altitude, and what would I need first?

Thursday is `handouts/box-pattern-flight.md`. **Stopping is the skill**, not moving. The preflight gate is
unchanged and a no-go is a real outcome.

**Say every day: ODOT Module 1 is due Thursday night and it is on Friday's quiz.**

### Middle School CS

**A new game, deliberately light on new concepts.** They have built a maze and a catcher, where things move
and you touch them. A shooter is structurally different: you act on the world.

**One new block all week:** the projectile. Everything else is `if`, `for index`, `forever`, `remainder`,
variables, and overlap.

**Tuesday is the week.** Build it up in order in front of them: one meteor, then a row with `for index`, then
a block with a `for` inside a `for`. Stop and count out loud: three rows of six, **eighteen sprites from six
blocks.** That is nested loops made visible, and it is the payoff for the hardest idea from last week.

**Trace the nested loop aloud before they build it:** the inner loop runs completely, start to finish, every
single time the outer loop goes around once. That sentence is the concept and it is on Friday's quiz.

**Two bugs will eat Wednesday**, both good ones: one shot clearing a whole column (the projectile was not
destroyed, only the enemy), and the game crawling (nothing is cleaned up).

**Negative vy is up**, which is not intuitive. If shots fall instead of rising, that is the sign.

### Yearbook

Two weeks, due Fri Oct 2. **The all-day checkout is what makes it work**, so say so explicitly or everyone
defaults to the class period and shoots the same hallway.

Check the sign-out log midway through week 6, not at the end of week 7.

---

## Folders

```
INDEX.md                     this file
POST-THIS.md                 what to post, in priority order
SLIDE-PROMPTS/               Monday and Tuesday, all five classes
1-design-techniques/         outline, quiz-bank.csv (42), quiz.md, teacher-notes,
                             handouts/peer-review.md
2-video-and-sound/           outline, quiz-bank.csv (62), quiz.md, teacher-notes,
                             handouts/filming-signup.md
3-aviation-uas/              outline, quiz-bank.csv (62), quiz.md, teacher-notes,
                             handouts/box-pattern-flight.md,
                             handouts/coordinate-bell-ringers.md (teacher only)
4-middle-school-cs/          outline, project, quiz-bank.csv (39), quiz.md,
                             teacher-notes, handouts/wave-defender-lab.md,
                             handouts/bell-ringers.md (teacher only)
5-yearbook/                  project.md, outline, teacher-notes
program/week-6-daily-log.md
grading-and-categories.md
```

`outline.md`, `project.md`, and `handouts/` are **student-facing.** `teacher-notes.md` and `quiz.md` are
**teacher-only.** Two exceptions, both marked above: `coordinate-bell-ringers.md` and `bell-ringers.md`
hold answers and go on the board, not in Classroom.

> **Week 5 materials still apply**: the DT project and labs, the V&S reset and equipment procedure, the
> Aviation chart handouts, and the MS CS Star Catcher lab are all in the Week 5 zip and still in use.
